"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { Bookmark, BookOpen, FileText, Video, Map, ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"

interface BookmarkItem {
  id: string
  itemType: "NOTE" | "PDF" | "VIDEO" | "ROADMAP"
  itemId: string
  createdAt: string
  note?: {
    id: string
    title: string
    description: string
    category: string
    tags: string[]
  }
  pdf?: {
    id: string
    title: string
    description: string
    category: string
    tags: string[]
    fileSize: string
  }
  video?: {
    id: string
    title: string
    description: string
    category: string
    tags: string[]
    duration: string
    thumbnailUrl: string
  }
  roadmap?: {
    id: string
    title: string
    description: string
    category: string
    difficulty: string
  }
}

export default function BookmarksPage() {
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchBookmarks = async () => {
      try {
        const response = await fetch("/api/bookmarks")
        if (!response.ok) {
          throw new Error("Failed to fetch bookmarks")
        }
        const data = await response.json()
        setBookmarks(data)
      } catch (error) {
        console.error("Error fetching bookmarks:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchBookmarks()
  }, [])

  const getItemDetails = (bookmark: BookmarkItem) => {
    switch (bookmark.itemType) {
      case "NOTE":
        return bookmark.note
      case "PDF":
        return bookmark.pdf
      case "VIDEO":
        return bookmark.video
      case "ROADMAP":
        return bookmark.roadmap
      default:
        return null
    }
  }

  const getItemIcon = (type: string) => {
    switch (type) {
      case "NOTE":
        return BookOpen
      case "PDF":
        return FileText
      case "VIDEO":
        return Video
      case "ROADMAP":
        return Map
      default:
        return Bookmark
    }
  }

  const getItemLink = (bookmark: BookmarkItem) => {
    const item = getItemDetails(bookmark)
    if (!item) return "#"

    switch (bookmark.itemType) {
      case "NOTE":
        return `/notes/${item.id}`
      case "PDF":
        return `/pdfs/${item.id}`
      case "VIDEO":
        return `/videos/${item.id}`
      case "ROADMAP":
        return `/roadmaps/${item.id}`
      default:
        return "#"
    }
  }

  const noteBookmarks = bookmarks.filter((bookmark) => bookmark.itemType === "NOTE")
  const pdfBookmarks = bookmarks.filter((bookmark) => bookmark.itemType === "PDF")
  const videoBookmarks = bookmarks.filter((bookmark) => bookmark.itemType === "VIDEO")
  const roadmapBookmarks = bookmarks.filter((bookmark) => bookmark.itemType === "ROADMAP")

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Your Bookmarks</h1>
          <p className="text-muted-foreground">Access your saved content</p>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-4">
          <TabsTrigger value="all">All Bookmarks</TabsTrigger>
          <TabsTrigger value="notes">Notes</TabsTrigger>
          <TabsTrigger value="pdfs">PDFs</TabsTrigger>
          <TabsTrigger value="videos">Videos</TabsTrigger>
          <TabsTrigger value="roadmaps">Roadmaps</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 6 }).map((_, index) => (
                <Card key={index}>
                  <CardHeader>
                    <Skeleton className="h-6 w-12 mb-2" />
                    <Skeleton className="h-6 w-full" />
                    <Skeleton className="h-4 w-full mt-2" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-4 w-3/4" />
                  </CardContent>
                  <CardFooter>
                    <Skeleton className="h-9 w-full" />
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : bookmarks.length === 0 ? (
            <Card>
              <CardHeader>
                <CardTitle>No bookmarks yet</CardTitle>
                <CardDescription>
                  You haven&apos;t bookmarked any content yet. Browse our resources and bookmark items you want to save
                  for later.
                </CardDescription>
              </CardHeader>
              <CardFooter>
                <Button asChild>
                  <Link href="/dashboard">
                    Browse Content
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {bookmarks.map((bookmark, index) => {
                const item = getItemDetails(bookmark)
                if (!item) return null

                const Icon = getItemIcon(bookmark.itemType)
                const link = getItemLink(bookmark)

                return (
                  <motion.div
                    key={bookmark.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="h-full hover:bg-secondary/50 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div className="rounded-lg p-2 bg-primary/10 text-primary">
                            <Icon className="h-4 w-4" />
                          </div>
                          <Badge variant="outline">{bookmark.itemType}</Badge>
                        </div>
                        <CardTitle className="mt-2 text-lg">{item.title}</CardTitle>
                        <CardDescription>{item.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="flex flex-wrap gap-2">
                          {item.tags &&
                            Array.isArray(item.tags) &&
                            item.tags.map((tag) => (
                              <Badge key={tag} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          <Badge variant="secondary" className="text-xs">
                            {item.category}
                          </Badge>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between items-center">
                        <span className="text-xs text-muted-foreground">
                          Bookmarked on {new Date(bookmark.createdAt).toLocaleDateString()}
                        </span>
                        <Button variant="ghost" size="sm" asChild>
                          <Link href={link}>
                            View
                            <ArrowRight className="ml-2 h-3 w-3" />
                          </Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="notes">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 3 }).map((_, index) => (
                <Card key={index}>
                  <CardHeader>
                    <Skeleton className="h-6 w-12 mb-2" />
                    <Skeleton className="h-6 w-full" />
                    <Skeleton className="h-4 w-full mt-2" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-4 w-3/4" />
                  </CardContent>
                  <CardFooter>
                    <Skeleton className="h-9 w-full" />
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : noteBookmarks.length === 0 ? (
            <Card>
              <CardHeader>
                <CardTitle>No note bookmarks</CardTitle>
                <CardDescription>You haven&apos;t bookmarked any notes yet.</CardDescription>
              </CardHeader>
              <CardFooter>
                <Button asChild>
                  <Link href="/notes">
                    Browse Notes
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {noteBookmarks.map((bookmark, index) => {
                const note = bookmark.note
                if (!note) return null

                return (
                  <motion.div
                    key={bookmark.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="h-full hover:bg-secondary/50 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div className="rounded-lg p-2 bg-primary/10 text-primary">
                            <BookOpen className="h-4 w-4" />
                          </div>
                          <Badge variant="outline">{note.category}</Badge>
                        </div>
                        <CardTitle className="mt-2 text-lg">{note.title}</CardTitle>
                        <CardDescription>{note.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="flex flex-wrap gap-2">
                          {note.tags &&
                            Array.isArray(note.tags) &&
                            note.tags.map((tag) => (
                              <Badge key={tag} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button variant="ghost" size="sm" className="w-full" asChild>
                          <Link href={`/notes/${note.id}`}>
                            View Note
                            <ArrowRight className="ml-2 h-3 w-3" />
                          </Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          )}
        </TabsContent>

        {/* Similar TabsContent for PDFs, Videos, and Roadmaps */}
        <TabsContent value="pdfs">
          {/* PDF bookmarks content */}
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 3 }).map((_, index) => (
                <Card key={index}>
                  <CardHeader>
                    <Skeleton className="h-6 w-12 mb-2" />
                    <Skeleton className="h-6 w-full" />
                    <Skeleton className="h-4 w-full mt-2" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-4 w-3/4" />
                  </CardContent>
                  <CardFooter>
                    <Skeleton className="h-9 w-full" />
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : pdfBookmarks.length === 0 ? (
            <Card>
              <CardHeader>
                <CardTitle>No PDF bookmarks</CardTitle>
                <CardDescription>You haven&apos;t bookmarked any PDFs yet.</CardDescription>
              </CardHeader>
              <CardFooter>
                <Button asChild>
                  <Link href="/pdfs">
                    Browse PDFs
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {pdfBookmarks.map((bookmark, index) => {
                const pdf = bookmark.pdf
                if (!pdf) return null

                return (
                  <motion.div
                    key={bookmark.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="h-full hover:bg-secondary/50 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div className="rounded-lg p-2 bg-primary/10 text-primary">
                            <FileText className="h-4 w-4" />
                          </div>
                          <Badge variant="outline">{pdf.category}</Badge>
                        </div>
                        <CardTitle className="mt-2 text-lg">{pdf.title}</CardTitle>
                        <CardDescription>{pdf.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="flex flex-wrap gap-2 mb-2">
                          {pdf.tags &&
                            Array.isArray(pdf.tags) &&
                            pdf.tags.map((tag) => (
                              <Badge key={tag} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                        </div>
                        <div className="text-sm text-muted-foreground">Size: {pdf.fileSize}</div>
                      </CardContent>
                      <CardFooter>
                        <Button variant="ghost" size="sm" className="w-full" asChild>
                          <Link href={`/pdfs/${pdf.id}`}>
                            View PDF
                            <ArrowRight className="ml-2 h-3 w-3" />
                          </Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="videos">
          {/* Video bookmarks content */}
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 3 }).map((_, index) => (
                <Card key={index}>
                  <CardHeader>
                    <Skeleton className="h-32 w-full mb-2 rounded-lg" />
                    <Skeleton className="h-6 w-full" />
                    <Skeleton className="h-4 w-full mt-2" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-4 w-3/4" />
                  </CardContent>
                  <CardFooter>
                    <Skeleton className="h-9 w-full" />
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : videoBookmarks.length === 0 ? (
            <Card>
              <CardHeader>
                <CardTitle>No video bookmarks</CardTitle>
                <CardDescription>You haven&apos;t bookmarked any videos yet.</CardDescription>
              </CardHeader>
              <CardFooter>
                <Button asChild>
                  <Link href="/videos">
                    Browse Videos
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {videoBookmarks.map((bookmark, index) => {
                const video = bookmark.video
                if (!video) return null

                return (
                  <motion.div
                    key={bookmark.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="h-full hover:bg-secondary/50 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="relative rounded-lg overflow-hidden mb-3 aspect-video">
                          <img
                            src={video.thumbnailUrl || "/placeholder.svg?height=180&width=320"}
                            alt={video.title}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                            {video.duration}
                          </div>
                        </div>
                        <div className="flex justify-between items-start">
                          <Badge variant="outline">{video.category}</Badge>
                        </div>
                        <CardTitle className="mt-2 text-lg">{video.title}</CardTitle>
                        <CardDescription>{video.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="flex flex-wrap gap-2">
                          {video.tags &&
                            Array.isArray(video.tags) &&
                            video.tags.map((tag) => (
                              <Badge key={tag} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button variant="ghost" size="sm" className="w-full" asChild>
                          <Link href={`/videos/${video.id}`}>
                            Watch Video
                            <ArrowRight className="ml-2 h-3 w-3" />
                          </Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="roadmaps">
          {/* Roadmap bookmarks content */}
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 3 }).map((_, index) => (
                <Card key={index}>
                  <CardHeader>
                    <Skeleton className="h-6 w-12 mb-2" />
                    <Skeleton className="h-6 w-full" />
                    <Skeleton className="h-4 w-full mt-2" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-4 w-3/4" />
                  </CardContent>
                  <CardFooter>
                    <Skeleton className="h-9 w-full" />
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : roadmapBookmarks.length === 0 ? (
            <Card>
              <CardHeader>
                <CardTitle>No roadmap bookmarks</CardTitle>
                <CardDescription>You haven&apos;t bookmarked any roadmaps yet.</CardDescription>
              </CardHeader>
              <CardFooter>
                <Button asChild>
                  <Link href="/roadmaps">
                    Browse Roadmaps
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {roadmapBookmarks.map((bookmark, index) => {
                const roadmap = bookmark.roadmap
                if (!roadmap) return null

                return (
                  <motion.div
                    key={bookmark.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="h-full hover:bg-secondary/50 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div className="rounded-lg p-2 bg-primary/10 text-primary">
                            <Map className="h-4 w-4" />
                          </div>
                          <Badge variant="outline">{roadmap.category}</Badge>
                        </div>
                        <CardTitle className="mt-2 text-lg">{roadmap.title}</CardTitle>
                        <CardDescription>{roadmap.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="text-sm text-muted-foreground">Difficulty: {roadmap.difficulty}</div>
                      </CardContent>
                      <CardFooter>
                        <Button variant="ghost" size="sm" className="w-full" asChild>
                          <Link href={`/roadmaps/${roadmap.id}`}>
                            View Roadmap
                            <ArrowRight className="ml-2 h-3 w-3" />
                          </Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
