"use client"

import Link from "next/link"
import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { motion } from "framer-motion"
import {
  User,
  Mail,
  Calendar,
  Award,
  Clock,
  BookOpen,
  FileText,
  Video,
  Map,
  Bot,
  Users,
  ArrowRight,
  Github,
  Twitter,
  Linkedin,
  Shield,
  Flame,
  Zap,
  BarChart,
  Bell,
  Key,
  Lock,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { AnimeRank } from "@/components/anime-rank"

export default function Profile() {
  const { data: session } = useSession()
  const [userStats, setUserStats] = useState({
    notes: 24,
    pdfs: 18,
    videos: 32,
    roadmaps: 3,
    aiChats: 47,
    communityPosts: 12,
  })
  const [streakData, setStreakData] = useState({
    currentStreak: 7,
    longestStreak: 14,
    totalXP: 1250,
    level: 5,
    nextLevelXP: 1600,
  })
  const [isAdmin, setIsAdmin] = useState(false)

  useEffect(() => {
    // Check if user is admin
    if (session?.user?.role === "ADMIN") {
      setIsAdmin(true)
    }

    // In a real app, fetch user stats and streak data from API
  }, [session])

  const achievements = [
    { name: "React Rookie", description: "Completed React basics", date: "2 weeks ago", icon: Award },
    { name: "CSS Master", description: "Finished advanced CSS course", date: "1 month ago", icon: Award },
    { name: "Git Pro", description: "Completed Git & GitHub essentials", date: "2 months ago", icon: Award },
    { name: "JavaScript Explorer", description: "Completed 10 JS exercises", date: "3 months ago", icon: Award },
  ]

  const recentActivities = [
    { title: "Completed JavaScript Basics", time: "2 hours ago", type: "course" },
    { title: "Earned 'React Rookie' Badge", time: "Yesterday", type: "achievement" },
    { title: "Asked question in Community", time: "2 days ago", type: "community" },
    { title: "Started Python Roadmap", time: "1 week ago", type: "roadmap" },
    { title: "Saved 'Advanced CSS' PDF", time: "1 week ago", type: "pdf" },
    { title: "Watched 'Intro to TypeScript' video", time: "2 weeks ago", type: "video" },
  ]

  // Generate streak calendar (last 7 days)
  const generateStreakCalendar = () => {
    const calendar = []
    const today = new Date()

    for (let i = 6; i >= 0; i--) {
      const date = new Date(today)
      date.setDate(date.getDate() - i)

      // Mock data - in a real app, fetch this from API
      const hasStreak = i <= streakData.currentStreak

      calendar.push({
        date,
        hasStreak,
        xp: hasStreak ? Math.floor(Math.random() * 100) + 50 : 0,
      })
    }

    return calendar
  }

  const streakCalendar = generateStreakCalendar()

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Profile</h1>
          <p className="text-muted-foreground">Manage your account and view your progress</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button>
            Edit Profile
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="md:col-span-1"
        >
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-center">
                <Avatar className="h-24 w-24">
                  <AvatarImage src={session?.user?.image || "/placeholder.svg?height=96&width=96"} />
                  <AvatarFallback>{session?.user?.name?.charAt(0) || "U"}</AvatarFallback>
                </Avatar>
              </div>
              <CardTitle className="text-center mt-4">{session?.user?.name || "User"}</CardTitle>
              <CardDescription className="text-center flex items-center justify-center gap-1">
                {isAdmin ? (
                  <>
                    <Shield className="h-4 w-4 text-primary" />
                    <span>Administrator</span>
                  </>
                ) : (
                  <>
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span>Student</span>
                  </>
                )}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <User className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">@{session?.user?.name?.toLowerCase().replace(/\s+/g, "") || "username"}</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">{session?.user?.email || "user@example.com"}</span>
              </div>
              <div className="flex items-center gap-3">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Joined April 2023</span>
              </div>

              {/* Streak and XP information */}
              <div className="pt-4 border-t">
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center gap-2">
                    <Flame className="h-5 w-5 text-orange-500" />
                    <span className="font-medium">Current Streak</span>
                  </div>
                  <span className="font-bold">{streakData.currentStreak} days</span>
                </div>
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center gap-2">
                    <Award className="h-5 w-5 text-yellow-500" />
                    <span className="font-medium">Longest Streak</span>
                  </div>
                  <span className="font-bold">{streakData.longestStreak} days</span>
                </div>
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-purple-500" />
                    <span className="font-medium">Total XP</span>
                  </div>
                  <span className="font-bold">{streakData.totalXP.toLocaleString()} XP</span>
                </div>

                <div className="mt-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Level {streakData.level}</span>
                    <span>Level {streakData.level + 1}</span>
                  </div>
                  <Progress value={(streakData.totalXP / streakData.nextLevelXP) * 100} className="h-2" />
                  <p className="text-xs text-center mt-1 text-muted-foreground">
                    {streakData.nextLevelXP - streakData.totalXP} XP to next level
                  </p>
                </div>
              </div>

              <div className="flex justify-center gap-4 mt-4">
                <Button variant="outline" size="icon">
                  <Github className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon">
                  <Twitter className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="icon">
                  <Linkedin className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="md:col-span-2"
        >
          <Card>
            <CardHeader>
              <CardTitle>Learning Progress</CardTitle>
              <CardDescription>Your journey so far</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Overall Progress</span>
                  <span className="font-medium">65%</span>
                </div>
                <Progress value={65} className="h-2" />
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="flex flex-col items-center p-3 rounded-lg bg-secondary/50">
                  <div className="rounded-full p-2 bg-primary/10 text-primary mb-2">
                    <BookOpen className="h-5 w-5" />
                  </div>
                  <span className="text-2xl font-bold">{userStats.notes}</span>
                  <span className="text-xs text-muted-foreground">Notes Created</span>
                </div>
                <div className="flex flex-col items-center p-3 rounded-lg bg-secondary/50">
                  <div className="rounded-full p-2 bg-primary/10 text-primary mb-2">
                    <FileText className="h-5 w-5" />
                  </div>
                  <span className="text-2xl font-bold">{userStats.pdfs}</span>
                  <span className="text-xs text-muted-foreground">PDFs Saved</span>
                </div>
                <div className="flex flex-col items-center p-3 rounded-lg bg-secondary/50">
                  <div className="rounded-full p-2 bg-primary/10 text-primary mb-2">
                    <Video className="h-5 w-5" />
                  </div>
                  <span className="text-2xl font-bold">{userStats.videos}</span>
                  <span className="text-xs text-muted-foreground">Videos Watched</span>
                </div>
                <div className="flex flex-col items-center p-3 rounded-lg bg-secondary/50">
                  <div className="rounded-full p-2 bg-primary/10 text-primary mb-2">
                    <Map className="h-5 w-5" />
                  </div>
                  <span className="text-2xl font-bold">{userStats.roadmaps}</span>
                  <span className="text-xs text-muted-foreground">Roadmaps Started</span>
                </div>
                <div className="flex flex-col items-center p-3 rounded-lg bg-secondary/50">
                  <div className="rounded-full p-2 bg-primary/10 text-primary mb-2">
                    <Bot className="h-5 w-5" />
                  </div>
                  <span className="text-2xl font-bold">{userStats.aiChats}</span>
                  <span className="text-xs text-muted-foreground">AI Mentor Chats</span>
                </div>
                <div className="flex flex-col items-center p-3 rounded-lg bg-secondary/50">
                  <div className="rounded-full p-2 bg-primary/10 text-primary mb-2">
                    <Users className="h-5 w-5" />
                  </div>
                  <span className="text-2xl font-bold">{userStats.communityPosts}</span>
                  <span className="text-xs text-muted-foreground">Community Posts</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Streak Calendar */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
        className="mb-8"
      >
        <Card>
          <CardHeader>
            <CardTitle>Daily Streak</CardTitle>
            <CardDescription>Your learning consistency</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-2">
              {streakCalendar.map((day, index) => (
                <div key={index} className="flex flex-col items-center">
                  <div className="text-xs text-muted-foreground mb-1">
                    {day.date.toLocaleDateString("en-US", { weekday: "short" })}
                  </div>
                  <div
                    className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                      day.hasStreak
                        ? "bg-primary/20 text-primary border border-primary/50"
                        : "bg-secondary border border-border"
                    }`}
                  >
                    <div className="flex flex-col items-center">
                      <span className="text-sm font-medium">{day.date.getDate()}</span>
                      {day.hasStreak && <span className="text-xs">{day.xp} XP</span>}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex justify-center mt-4">
              <Badge variant="outline" className="flex items-center gap-1">
                <Flame className="h-4 w-4 text-orange-500" />
                <span>{streakData.currentStreak} day streak! Keep it up!</span>
              </Badge>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <Tabs defaultValue="achievements">
        <TabsList className="mb-4">
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="activity">Recent Activity</TabsTrigger>
          {isAdmin && <TabsTrigger value="admin">Admin Tools</TabsTrigger>}
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="anime-rank">Anime Rank</TabsTrigger>
        </TabsList>

        <TabsContent value="achievements">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
            <Card>
              <CardHeader>
                <CardTitle>Your Achievements</CardTitle>
                <CardDescription>Badges and milestones you've earned</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {achievements.map((achievement, index) => (
                    <div key={index} className="flex items-start gap-4 p-4 rounded-lg bg-secondary/50">
                      <div className="rounded-full p-2 bg-amber-500/10 text-amber-500">
                        <achievement.icon className="h-5 w-5" />
                      </div>
                      <div>
                        <h3 className="font-medium">{achievement.name}</h3>
                        <p className="text-sm text-muted-foreground">{achievement.description}</p>
                        <p className="text-xs text-muted-foreground mt-1">Earned {achievement.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="ghost" className="w-full" asChild>
                  <Link href="/profile/achievements">
                    View All Achievements
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        </TabsContent>

        <TabsContent value="activity">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Your latest actions and progress</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivities.map((activity, index) => (
                    <div key={index} className="flex items-start gap-4">
                      <div className="rounded-full p-2 bg-secondary">
                        {activity.type === "course" && <BookOpen className="h-4 w-4" />}
                        {activity.type === "achievement" && <Award className="h-4 w-4" />}
                        {activity.type === "community" && <Users className="h-4 w-4" />}
                        {activity.type === "roadmap" && <Map className="h-4 w-4" />}
                        {activity.type === "pdf" && <FileText className="h-4 w-4" />}
                        {activity.type === "video" && <Video className="h-4 w-4" />}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{activity.title}</p>
                        <p className="text-xs text-muted-foreground flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {activity.time}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="ghost" className="w-full" asChild>
                  <Link href="/profile/activity">
                    View All Activity
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        </TabsContent>

        {isAdmin && (
          <TabsContent value="admin">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
              <Card>
                <CardHeader>
                  <CardTitle>Admin Tools</CardTitle>
                  <CardDescription>Manage the platform</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Button className="justify-start" asChild>
                      <Link href="/admin">
                        <Shield className="mr-2 h-4 w-4" />
                        Admin Dashboard
                      </Link>
                    </Button>
                    <Button className="justify-start" asChild>
                      <Link href="/admin/users">
                        <Users className="mr-2 h-4 w-4" />
                        Manage Users
                      </Link>
                    </Button>
                    <Button className="justify-start" asChild>
                      <Link href="/admin/content">
                        <FileText className="mr-2 h-4 w-4" />
                        Manage Content
                      </Link>
                    </Button>
                    <Button className="justify-start" asChild>
                      <Link href="/admin/analytics">
                        <BarChart className="mr-2 h-4 w-4" />
                        View Analytics
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        )}

        <TabsContent value="settings">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
            <Card>
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
                <CardDescription>Manage your account preferences</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Button className="justify-start w-full" variant="outline" asChild>
                    <Link href="/profile/settings/account">
                      <User className="mr-2 h-4 w-4" />
                      Account Information
                    </Link>
                  </Button>
                  <Button className="justify-start w-full" variant="outline" asChild>
                    <Link href="/profile/settings/notifications">
                      <Bell className="mr-2 h-4 w-4" />
                      Notification Preferences
                    </Link>
                  </Button>
                  <Button className="justify-start w-full" variant="outline" asChild>
                    <Link href="/profile/settings/privacy">
                      <Lock className="mr-2 h-4 w-4" />
                      Privacy Settings
                    </Link>
                  </Button>
                  <Button className="justify-start w-full" variant="outline" asChild>
                    <Link href="/profile/settings/password">
                      <Key className="mr-2 h-4 w-4" />
                      Change Password
                    </Link>
                  </Button>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="destructive" className="w-full">
                  Sign Out
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        </TabsContent>

        <TabsContent value="anime-rank">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
            <Card>
              <CardHeader>
                <CardTitle>Anime Rank</CardTitle>
                <CardDescription>Your anime ranking</CardDescription>
              </CardHeader>
              <CardContent>
                <AnimeRank />
              </CardContent>
            </Card>
          </motion.div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
