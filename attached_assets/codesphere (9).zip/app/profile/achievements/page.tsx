"use client"

import { motion } from "framer-motion"
import { ArrowLeft, Trophy, Calendar, Code, Users, Clock, FileCode, Award, Zap } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

export default function AchievementsPage() {
  const achievements = [
    {
      id: 1,
      title: "React Rookie",
      description: "Completed your first React component",
      date: "2023-07-10",
      icon: Trophy,
      color: "text-amber-500",
      xp: 50,
      earned: true,
    },
    {
      id: 2,
      title: "Consistent Learner",
      description: "Maintained a 7-day learning streak",
      date: "2023-07-12",
      icon: Calendar,
      color: "text-blue-500",
      xp: 100,
      earned: true,
    },
    {
      id: 3,
      title: "Quiz Master",
      description: "Scored 100% on JavaScript Fundamentals quiz",
      date: "2023-07-08",
      icon: Code,
      color: "text-green-500",
      xp: 75,
      earned: true,
    },
    {
      id: 4,
      title: "Code Contributor",
      description: "Shared your first code snippet with the community",
      date: "2023-07-05",
      icon: Users,
      color: "text-purple-500",
      xp: 50,
      earned: true,
    },
    {
      id: 5,
      title: "Fast Learner",
      description: "Completed 3 courses in the first month",
      date: "2023-06-30",
      icon: Clock,
      color: "text-orange-500",
      xp: 150,
      earned: true,
    },
    {
      id: 6,
      title: "Problem Solver",
      description: "Solved 10 coding challenges",
      date: "2023-06-25",
      icon: FileCode,
      color: "text-red-500",
      xp: 200,
      earned: true,
    },
    {
      id: 7,
      title: "JavaScript Master",
      description: "Complete all JavaScript courses",
      date: null,
      icon: Code,
      color: "text-yellow-500",
      xp: 300,
      earned: false,
      progress: 75,
    },
    {
      id: 8,
      title: "Community Leader",
      description: "Get 100 likes on community posts",
      date: null,
      icon: Users,
      color: "text-pink-500",
      xp: 250,
      earned: false,
      progress: 45,
    },
    {
      id: 9,
      title: "Speed Demon",
      description: "Complete a course in under 24 hours",
      date: null,
      icon: Zap,
      color: "text-cyan-500",
      xp: 500,
      earned: false,
      progress: 0,
    },
  ]

  const earnedAchievements = achievements.filter((a) => a.earned)
  const upcomingAchievements = achievements.filter((a) => !a.earned)
  const totalXP = earnedAchievements.reduce((sum, achievement) => sum + achievement.xp, 0)

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex items-center gap-4 mb-8">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/profile">
            <ArrowLeft className="h-5 w-5" />
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Achievements</h1>
          <p className="text-muted-foreground">Your badges and milestones</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Total Achievements</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{earnedAchievements.length}</div>
            <p className="text-sm text-muted-foreground">out of {achievements.length}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Total XP Earned</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{totalXP.toLocaleString()}</div>
            <p className="text-sm text-muted-foreground">experience points</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Completion Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {Math.round((earnedAchievements.length / achievements.length) * 100)}%
            </div>
            <Progress value={(earnedAchievements.length / achievements.length) * 100} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      <div className="space-y-8">
        <div>
          <h2 className="text-2xl font-bold mb-4">Earned Achievements</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {earnedAchievements.map((achievement, index) => (
              <motion.div
                key={achievement.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Card className="h-full">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className={`rounded-lg p-2 ${achievement.color} bg-opacity-10`}>
                        <achievement.icon className={`h-5 w-5 ${achievement.color}`} />
                      </div>
                      <Badge variant="secondary">+{achievement.xp} XP</Badge>
                    </div>
                    <CardTitle className="mt-2">{achievement.title}</CardTitle>
                    <CardDescription>{achievement.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Award className="h-4 w-4" />
                      <span>Earned on {new Date(achievement.date!).toLocaleDateString()}</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-bold mb-4">Upcoming Achievements</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {upcomingAchievements.map((achievement, index) => (
              <motion.div
                key={achievement.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Card className="h-full opacity-75">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="rounded-lg p-2 bg-muted">
                        <achievement.icon className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <Badge variant="outline">+{achievement.xp} XP</Badge>
                    </div>
                    <CardTitle className="mt-2">{achievement.title}</CardTitle>
                    <CardDescription>{achievement.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {achievement.progress !== undefined && achievement.progress > 0 && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span>{achievement.progress}%</span>
                        </div>
                        <Progress value={achievement.progress} />
                      </div>
                    )}
                    {achievement.progress === 0 && <p className="text-sm text-muted-foreground">Not started</p>}
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
