"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Play, Save, RotateCcw, Check, Clock, Trophy, Users, MessageSquare } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"

export default function ChallengeDetail({ params }: { params: { challengeId: string } }) {
  const [code, setCode] = useState(`// Write your solution here
function solution(input) {
  // Your code here
  return input;
}

// Example usage
console.log(solution("test"));
`)
  const [output, setOutput] = useState("")
  const [isRunning, setIsRunning] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [isCompleted, setIsCompleted] = useState(false)
  const [activeTab, setActiveTab] = useState("instructions")
  const { toast } = useToast()

  // Mock challenge data - in a real app, fetch this from an API
  const challenge = {
    id: params.challengeId,
    title: "Build a Todo App with React",
    description: "Create a simple todo application with React hooks",
    category: "React",
    difficulty: "Beginner",
    estimatedTime: "2 hours",
    completionRate: 78,
    participants: 1245,
    instructions: `
# Todo App Challenge

In this challenge, you'll build a simple Todo application using React hooks.

## Requirements:

1. Create a form to add new todos
2. Display a list of todos
3. Allow marking todos as completed
4. Allow deleting todos
5. Add filtering options (All, Active, Completed)

## Tips:

- Use useState to manage the todos array
- Each todo should have: id, text, and completed status
- Use conditional rendering for the filters

## Bonus:

- Add local storage to persist todos
- Add edit functionality
- Add drag and drop to reorder todos
    `,
    tests: [
      {
        name: "Should add a new todo",
        code: `test("Should add a new todo", () => {
  const { result } = renderHook(() => useTodos());
  act(() => {
    result.current.addTodo("Test todo");
  });
  expect(result.current.todos.length).toBe(1);
  expect(result.current.todos[0].text).toBe("Test todo");
});`,
      },
      {
        name: "Should mark a todo as completed",
        code: `test("Should mark a todo as completed", () => {
  const { result } = renderHook(() => useTodos());
  act(() => {
    result.current.addTodo("Test todo");
    result.current.toggleTodo(result.current.todos[0].id);
  });
  expect(result.current.todos[0].completed).toBe(true);
});`,
      },
      {
        name: "Should delete a todo",
        code: `test("Should delete a todo", () => {
  const { result } = renderHook(() => useTodos());
  act(() => {
    result.current.addTodo("Test todo");
    result.current.deleteTodo(result.current.todos[0].id);
  });
  expect(result.current.todos.length).toBe(0);
});`,
      },
    ],
    hints: [
      "Start by defining your state: const [todos, setTodos] = useState([])",
      "Create functions for adding, toggling, and deleting todos",
      "Use the map function to render the list of todos",
      "Use the filter function for filtering todos",
    ],
    solution: `import { useState } from 'react';

function TodoApp() {
  const [todos, setTodos] = useState([]);
  const [text, setText] = useState('');
  const [filter, setFilter] = useState('all');

  const addTodo = () => {
    if (text.trim()) {
      setTodos([...todos, { id: Date.now(), text, completed: false }]);
      setText('');
    }
  };

  const toggleTodo = (id) => {
    setTodos(
      todos.map((todo) =>
        todo.id === id ? { ...todo, completed: !todo.completed } : todo
      )
    );
  };

  const deleteTodo = (id) => {
    setTodos(todos.filter((todo) => todo.id !== id));
  };

  const filteredTodos = todos.filter((todo) => {
    if (filter === 'active') return !todo.completed;
    if (filter === 'completed') return todo.completed;
    return true;
  });

  return (
    <div>
      <h1>Todo App</h1>
      <div>
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Add a todo"
        />
        <button onClick={addTodo}>Add</button>
      </div>
      <div>
        <button onClick={() => setFilter('all')}>All</button>
        <button onClick={() => setFilter('active')}>Active</button>
        <button onClick={() => setFilter('completed')}>Completed</button>
      </div>
      <ul>
        {filteredTodos.map((todo) => (
          <li key={todo.id}>
            <input
              type="checkbox"
              checked={todo.completed}
              onChange={() => toggleTodo(todo.id)}
            />
            <span
              style={{
                textDecoration: todo.completed ? 'line-through' : 'none',
              }}
            >
              {todo.text}
            </span>
            <button onClick={() => deleteTodo(todo.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TodoApp;`,
  }

  const runCode = () => {
    setIsRunning(true)
    setOutput("")

    // Simulate code execution
    setTimeout(() => {
      try {
        // In a real app, you would use a sandboxed environment to run the code
        // For now, we'll just simulate output
        setOutput("Output:\nAdded todo: Test todo\nMarked todo as completed\nDeleted todo\n\nAll tests passed!")
        setIsRunning(false)
      } catch (error) {
        setOutput(`Error: ${error}`)
        setIsRunning(false)
      }
    }, 1500)
  }

  const saveCode = () => {
    setIsSaving(true)

    // Simulate saving
    setTimeout(() => {
      setIsSaving(false)
      toast({
        title: "Progress saved",
        description: "Your code has been saved successfully",
      })
    }, 1000)
  }

  const resetCode = () => {
    setCode(`// Write your solution here
function solution(input) {
  // Your code here
  return input;
}

// Example usage
console.log(solution("test"));`)
    toast({
      title: "Code reset",
      description: "Your code has been reset to the initial state",
    })
  }

  const submitSolution = () => {
    setIsRunning(true)

    // Simulate submission and verification
    setTimeout(() => {
      setIsRunning(false)
      setIsCompleted(true)
      toast({
        title: "Challenge completed!",
        description: "Congratulations! You've successfully completed this challenge.",
      })
    }, 2000)
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner":
        return "bg-green-500/10 text-green-500"
      case "Intermediate":
        return "bg-yellow-500/10 text-yellow-500"
      case "Advanced":
        return "bg-red-500/10 text-red-500"
      default:
        return "bg-primary/10 text-primary"
    }
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/challenges">
              <ArrowLeft className="h-4 w-4" />
              <span className="sr-only">Back to challenges</span>
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{challenge.title}</h1>
            <p className="text-muted-foreground">{challenge.description}</p>
          </div>
        </div>
        <div className="mt-4 md:mt-0 flex items-center gap-2">
          <Badge variant="secondary" className={getDifficultyColor(challenge.difficulty)}>
            {challenge.difficulty}
          </Badge>
          <Badge variant="secondary" className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {challenge.estimatedTime}
          </Badge>
          <Badge variant="secondary" className="flex items-center gap-1">
            <Trophy className="h-3 w-3" />
            {challenge.participants.toLocaleString()} participants
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <Card className="h-full">
            <CardHeader>
              <CardTitle>Challenge Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="w-full">
                  <TabsTrigger value="instructions" className="flex-1">
                    Instructions
                  </TabsTrigger>
                  <TabsTrigger value="tests" className="flex-1">
                    Tests
                  </TabsTrigger>
                  <TabsTrigger value="hints" className="flex-1">
                    Hints
                  </TabsTrigger>
                </TabsList>
                <TabsContent value="instructions" className="mt-4">
                  <div className="prose dark:prose-invert max-w-none">
                    <div dangerouslySetInnerHTML={{ __html: challenge.instructions }} />
                  </div>
                </TabsContent>
                <TabsContent value="tests" className="mt-4">
                  <div className="space-y-4">
                    {challenge.tests.map((test, index) => (
                      <div key={index} className="space-y-2">
                        <h3 className="text-sm font-medium flex items-center gap-2">
                          <Check className="h-4 w-4 text-green-500" />
                          {test.name}
                        </h3>
                        <pre className="bg-secondary p-2 rounded-md text-xs overflow-x-auto">{test.code}</pre>
                      </div>
                    ))}
                  </div>
                </TabsContent>
                <TabsContent value="hints" className="mt-4">
                  <div className="space-y-2">
                    {challenge.hints.map((hint, index) => (
                      <div key={index} className="p-2 bg-secondary rounded-md">
                        <p className="text-sm">
                          <span className="font-bold">Hint {index + 1}:</span> {hint}
                        </p>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>

              <Separator />

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Your Progress</h3>
                <Progress value={isCompleted ? 100 : 25} className="h-2" />
                <p className="text-xs text-muted-foreground text-center">
                  {isCompleted ? "Completed!" : "In progress..."}
                </p>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Community</h3>
                <div className="flex justify-between">
                  <Button variant="outline" size="sm" className="w-[48%]">
                    <Users className="mr-2 h-4 w-4" />
                    Leaderboard
                  </Button>
                  <Button variant="outline" size="sm" className="w-[48%]">
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Discussion
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Code Editor</CardTitle>
              <CardDescription>Write your solution below</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative h-[400px] rounded-md border">
                <textarea
                  className="absolute inset-0 font-mono p-4 resize-none w-full h-full bg-secondary/50 focus:outline-none"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={resetCode}>
                  <RotateCcw className="mr-2 h-4 w-4" />
                  Reset
                </Button>
                <Button variant="outline" size="sm" onClick={saveCode} disabled={isSaving}>
                  <Save className="mr-2 h-4 w-4" />
                  {isSaving ? "Saving..." : "Save"}
                </Button>
              </div>
              <div className="flex gap-2">
                <Button size="sm" onClick={runCode} disabled={isRunning}>
                  <Play className="mr-2 h-4 w-4" />
                  {isRunning ? "Running..." : "Run Code"}
                </Button>
                <Button
                  size="sm"
                  variant="default"
                  className="bg-green-600 hover:bg-green-700"
                  onClick={submitSolution}
                  disabled={isRunning || isCompleted}
                >
                  <Check className="mr-2 h-4 w-4" />
                  {isCompleted ? "Completed" : isRunning ? "Submitting..." : "Submit Solution"}
                </Button>
              </div>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Output</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-black text-white font-mono p-4 rounded-md h-[200px] overflow-auto">
                {isRunning ? (
                  <div className="flex items-center justify-center h-full">
                    <div className="h-6 w-6 animate-spin rounded-full border-2 border-white border-t-transparent" />
                  </div>
                ) : output ? (
                  <pre className="whitespace-pre-wrap">{output}</pre>
                ) : (
                  <div className="text-gray-500 h-full flex items-center justify-center">
                    Run your code to see output here
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
