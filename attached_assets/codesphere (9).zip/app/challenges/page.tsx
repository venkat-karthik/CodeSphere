"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Search, Filter, Code, ArrowRight, Clock, Trophy, Star } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"

export default function Challenges() {
  const [searchQuery, setSearchQuery] = useState("")

  const categories = ["All", "JavaScript", "React", "Node.js", "CSS", "HTML", "TypeScript", "Python"]

  const challenges = [
    {
      id: 1,
      title: "Build a Todo App with React",
      description: "Create a simple todo application with React hooks",
      category: "React",
      difficulty: "Beginner",
      estimatedTime: "2 hours",
      completionRate: 78,
      stars: 4.7,
      participants: 1245,
    },
    {
      id: 2,
      title: "Create a REST API with Express",
      description: "Build a RESTful API with Express and MongoDB",
      category: "Node.js",
      difficulty: "Intermediate",
      estimatedTime: "3 hours",
      completionRate: 65,
      stars: 4.5,
      participants: 987,
    },
    {
      id: 3,
      title: "Implement a Sorting Algorithm",
      description: "Code and optimize different sorting algorithms in JavaScript",
      category: "JavaScript",
      difficulty: "Advanced",
      estimatedTime: "4 hours",
      completionRate: 42,
      stars: 4.8,
      participants: 756,
    },
    {
      id: 4,
      title: "Build a Responsive Landing Page",
      description: "Create a responsive landing page using CSS Grid and Flexbox",
      category: "CSS",
      difficulty: "Beginner",
      estimatedTime: "2.5 hours",
      completionRate: 85,
      stars: 4.3,
      participants: 1532,
    },
    {
      id: 5,
      title: "Create a TypeScript Library",
      description: "Build and publish a TypeScript library with proper typing",
      category: "TypeScript",
      difficulty: "Advanced",
      estimatedTime: "5 hours",
      completionRate: 38,
      stars: 4.9,
      participants: 543,
    },
    {
      id: 6,
      title: "Build a Python Web Scraper",
      description: "Create a web scraper to extract data from websites",
      category: "Python",
      difficulty: "Intermediate",
      estimatedTime: "3.5 hours",
      completionRate: 58,
      stars: 4.6,
      participants: 876,
    },
  ]

  const filteredChallenges = challenges.filter(
    (challenge) =>
      challenge.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      challenge.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner":
        return "bg-green-500/10 text-green-500"
      case "Intermediate":
        return "bg-yellow-500/10 text-yellow-500"
      case "Advanced":
        return "bg-red-500/10 text-red-500"
      default:
        return "bg-primary/10 text-primary"
    }
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Coding Challenges</h1>
          <p className="text-muted-foreground">Test your skills with interactive coding exercises</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button>
            Create Challenge
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search challenges..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Select defaultValue="newest">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest First</SelectItem>
              <SelectItem value="popular">Most Popular</SelectItem>
              <SelectItem value="completion">Highest Completion</SelectItem>
              <SelectItem value="difficulty">Difficulty</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-4 flex flex-wrap h-auto">
          {categories.map((category) => (
            <TabsTrigger key={category} value={category === "All" ? "all" : category.toLowerCase()}>
              {category}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredChallenges.map((challenge, index) => (
              <motion.div
                key={challenge.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Card className="h-full hover:bg-secondary/50 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="rounded-lg p-2 bg-primary/10 text-primary">
                        <Code className="h-4 w-4" />
                      </div>
                      <Badge variant="outline">{challenge.category}</Badge>
                    </div>
                    <CardTitle className="mt-2 text-lg">{challenge.title}</CardTitle>
                    <CardDescription>{challenge.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="secondary" className={getDifficultyColor(challenge.difficulty)}>
                        {challenge.difficulty}
                      </Badge>
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {challenge.estimatedTime}
                      </Badge>
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <Trophy className="h-3 w-3" />
                        {challenge.participants.toLocaleString()} participants
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs">
                        <span>Completion Rate</span>
                        <span>{challenge.completionRate}%</span>
                      </div>
                      <Progress value={challenge.completionRate} className="h-1" />
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between items-center">
                    <div className="flex items-center gap-1">
                      <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                      <span className="text-xs">{challenge.stars} / 5</span>
                    </div>
                    <Button variant="ghost" size="sm">
                      Start Challenge
                      <ArrowRight className="ml-2 h-3 w-3" />
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {categories.slice(1).map((category) => (
          <TabsContent key={category} value={category.toLowerCase()}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredChallenges
                .filter((challenge) => challenge.category === category)
                .map((challenge, index) => (
                  <motion.div
                    key={challenge.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="h-full hover:bg-secondary/50 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div className="rounded-lg p-2 bg-primary/10 text-primary">
                            <Code className="h-4 w-4" />
                          </div>
                          <Badge variant="outline">{challenge.category}</Badge>
                        </div>
                        <CardTitle className="mt-2 text-lg">{challenge.title}</CardTitle>
                        <CardDescription>{challenge.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="flex flex-wrap gap-2 mb-3">
                          <Badge variant="secondary" className={getDifficultyColor(challenge.difficulty)}>
                            {challenge.difficulty}
                          </Badge>
                          <Badge variant="secondary" className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {challenge.estimatedTime}
                          </Badge>
                          <Badge variant="secondary" className="flex items-center gap-1">
                            <Trophy className="h-3 w-3" />
                            {challenge.participants.toLocaleString()} participants
                          </Badge>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-xs">
                            <span>Completion Rate</span>
                            <span>{challenge.completionRate}%</span>
                          </div>
                          <Progress value={challenge.completionRate} className="h-1" />
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between items-center">
                        <div className="flex items-center gap-1">
                          <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                          <span className="text-xs">{challenge.stars} / 5</span>
                        </div>
                        <Button variant="ghost" size="sm">
                          Start Challenge
                          <ArrowRight className="ml-2 h-3 w-3" />
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
