"use client"

import { useState } from "react"
import Link from "next/link"
import { Search, Edit, Trash, Plus, Filter } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function AdminVideos() {
  const [searchQuery, setSearchQuery] = useState("")
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [selectedVideo, setSelectedVideo] = useState<any>(null)

  // Mock data - in a real app, this would come from an API call
  const videos = [
    {
      id: 1,
      title: "JavaScript Crash Course for Beginners",
      category: "JavaScript",
      duration: "45:22",
      views: 12450,
      createdAt: "2 months ago",
    },
    {
      id: 2,
      title: "React Hooks Deep Dive",
      category: "React",
      duration: "32:15",
      views: 8765,
      createdAt: "3 weeks ago",
    },
    {
      id: 3,
      title: "CSS Grid and Flexbox Tutorial",
      category: "CSS",
      duration: "28:47",
      views: 6543,
      createdAt: "1 month ago",
    },
    {
      id: 4,
      title: "Building a REST API with Node.js",
      category: "Node.js",
      duration: "54:18",
      views: 5432,
      createdAt: "2 weeks ago",
    },
    {
      id: 5,
      title: "TypeScript for React Developers",
      category: "TypeScript",
      duration: "38:29",
      views: 4321,
      createdAt: "1 week ago",
    },
    {
      id: 6,
      title: "HTML5 Semantic Elements Explained",
      category: "HTML",
      duration: "22:36",
      views: 3210,
      createdAt: "3 months ago",
    },
  ]

  const filteredVideos = videos.filter((video) => video.title.toLowerCase().includes(searchQuery.toLowerCase()))

  const handleDelete = (video: any) => {
    setSelectedVideo(video)
    setDeleteDialogOpen(true)
  }

  const confirmDelete = () => {
    // In a real app, this would make an API call to delete the video
    console.log("Deleting video:", selectedVideo)
    setDeleteDialogOpen(false)
    // Then refetch the videos
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Manage Videos</h1>
          <p className="text-muted-foreground">Add, edit, or delete video tutorials</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button asChild>
            <Link href="/admin/videos/new">
              <Plus className="mr-2 h-4 w-4" />
              Add New Video
            </Link>
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search videos..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Select defaultValue="all">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="javascript">JavaScript</SelectItem>
              <SelectItem value="react">React</SelectItem>
              <SelectItem value="css">CSS</SelectItem>
              <SelectItem value="html">HTML</SelectItem>
              <SelectItem value="typescript">TypeScript</SelectItem>
              <SelectItem value="nodejs">Node.js</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Video Library</CardTitle>
          <CardDescription>Manage your video content</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Views</TableHead>
                <TableHead>Added</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredVideos.map((video) => (
                <TableRow key={video.id}>
                  <TableCell className="font-medium">{video.title}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{video.category}</Badge>
                  </TableCell>
                  <TableCell>{video.duration}</TableCell>
                  <TableCell>{video.views.toLocaleString()}</TableCell>
                  <TableCell>{video.createdAt}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon" asChild>
                        <Link href={`/admin/videos/${video.id}`}>
                          <Edit className="h-4 w-4" />
                          <span className="sr-only">Edit</span>
                        </Link>
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDelete(video)}>
                        <Trash className="h-4 w-4" />
                        <span className="sr-only">Delete</span>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete the video &quot;{selectedVideo?.title}&quot;? This action cannot be
              undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={confirmDelete}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
