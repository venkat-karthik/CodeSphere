"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { ArrowLeft, Save, Trash, Upload } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function EditVideo({ params }: { params: { videoId: string } }) {
  const router = useRouter()
  const { videoId } = params
  const isNew = videoId === "new"

  // Mock data for editing - in a real app, fetch this from an API
  const [video, setVideo] = useState({
    title: "",
    description: "",
    category: "",
    tags: "",
    videoUrl: "",
    thumbnailUrl: "",
    duration: "",
  })

  useEffect(() => {
    if (!isNew) {
      // In a real app, fetch the video data
      // For now, we'll use mock data
      setVideo({
        title: "JavaScript Crash Course for Beginners",
        description: "Learn JavaScript basics in this comprehensive crash course for beginners",
        category: "JavaScript",
        tags: "beginner,fundamentals",
        videoUrl: "https://example.com/video.mp4",
        thumbnailUrl: "/placeholder.svg?height=180&width=320",
        duration: "45:22",
      })
    }
  }, [isNew, videoId])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setVideo((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setVideo((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, this would make an API call to save the video
    console.log("Saving video:", video)
    router.push("/admin/videos")
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex items-center mb-8">
        <Button variant="ghost" size="icon" onClick={() => router.back()} className="mr-4">
          <ArrowLeft className="h-4 w-4" />
          <span className="sr-only">Back</span>
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{isNew ? "Add New Video" : "Edit Video"}</h1>
          <p className="text-muted-foreground">{isNew ? "Upload a new video tutorial" : "Update video details"}</p>
        </div>
      </div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Video Details</CardTitle>
                  <CardDescription>Basic information about the video</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Title</Label>
                    <Input
                      id="title"
                      name="title"
                      value={video.title}
                      onChange={handleChange}
                      placeholder="Enter video title"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      name="description"
                      value={video.description}
                      onChange={handleChange}
                      placeholder="Enter video description"
                      rows={4}
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="category">Category</Label>
                      <Select value={video.category} onValueChange={(value) => handleSelectChange("category", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="JavaScript">JavaScript</SelectItem>
                          <SelectItem value="React">React</SelectItem>
                          <SelectItem value="Node.js">Node.js</SelectItem>
                          <SelectItem value="CSS">CSS</SelectItem>
                          <SelectItem value="HTML">HTML</SelectItem>
                          <SelectItem value="TypeScript">TypeScript</SelectItem>
                          <SelectItem value="Python">Python</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="tags">Tags (comma separated)</Label>
                      <Input
                        id="tags"
                        name="tags"
                        value={video.tags}
                        onChange={handleChange}
                        placeholder="beginner,javascript,tutorial"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Video Content</CardTitle>
                  <CardDescription>Upload or link to your video content</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="videoUrl">Video URL</Label>
                    <Input
                      id="videoUrl"
                      name="videoUrl"
                      value={video.videoUrl}
                      onChange={handleChange}
                      placeholder="https://example.com/video.mp4 or YouTube embed URL"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Or Upload Video File</Label>
                    <div className="border-2 border-dashed rounded-lg p-6 text-center">
                      <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground mb-2">
                        Drag and drop a video file, or click to browse
                      </p>
                      <Button variant="outline" size="sm">
                        Choose File
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="duration">Duration (MM:SS)</Label>
                    <Input
                      id="duration"
                      name="duration"
                      value={video.duration}
                      onChange={handleChange}
                      placeholder="45:30"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Thumbnail</CardTitle>
                  <CardDescription>Video preview image</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="thumbnailUrl">Thumbnail URL</Label>
                    <Input
                      id="thumbnailUrl"
                      name="thumbnailUrl"
                      value={video.thumbnailUrl}
                      onChange={handleChange}
                      placeholder="https://example.com/thumbnail.jpg"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Or Upload Thumbnail</Label>
                    <div className="border-2 border-dashed rounded-lg p-6 text-center">
                      <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground mb-2">Drag and drop an image, or click to browse</p>
                      <Button variant="outline" size="sm">
                        Choose File
                      </Button>
                    </div>
                  </div>
                  {video.thumbnailUrl && (
                    <div className="mt-4">
                      <Label>Preview</Label>
                      <div className="mt-2 rounded-lg overflow-hidden">
                        <img
                          src={video.thumbnailUrl || "/placeholder.svg"}
                          alt="Thumbnail preview"
                          className="w-full h-auto"
                        />
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button className="w-full" type="submit">
                    <Save className="mr-2 h-4 w-4" />
                    {isNew ? "Create Video" : "Save Changes"}
                  </Button>
                  {!isNew && (
                    <Button variant="destructive" className="w-full" type="button">
                      <Trash className="mr-2 h-4 w-4" />
                      Delete Video
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    className="w-full"
                    type="button"
                    onClick={() => router.push("/admin/videos")}
                  >
                    Cancel
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </form>
      </motion.div>
    </div>
  )
}
