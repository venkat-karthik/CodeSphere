"use client"

import { useState } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { ArrowLeft, BarChart, Users, Video, FileText, BookOpen, Map, Download } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function AdminAnalytics() {
  const [timeRange, setTimeRange] = useState("7d")

  // Mock data - in a real app, this would come from an API call
  const userStats = {
    totalUsers: 1245,
    activeToday: 328,
    newThisWeek: 87,
    averageSessionTime: "18 minutes",
  }

  const contentStats = {
    totalContent: 567,
    totalViews: 24680,
    completionRate: "68%",
    mostPopularCategory: "JavaScript",
  }

  const engagementData = [
    { day: "Mon", users: 245, content: 156 },
    { day: "Tue", users: 267, content: 178 },
    { day: "Wed", users: 302, content: 198 },
    { day: "Thu", users: 289, content: 167 },
    { day: "Fri", users: 310, content: 203 },
    { day: "Sat", users: 198, content: 176 },
    { day: "Sun", users: 220, content: 153 },
  ]

  const topContent = [
    {
      title: "JavaScript Crash Course",
      type: "Video",
      views: 1245,
      completions: 876,
      rating: 4.8,
    },
    {
      title: "React Hooks Deep Dive",
      type: "Note",
      views: 987,
      completions: 654,
      rating: 4.7,
    },
    {
      title: "CSS Grid Layout Guide",
      type: "PDF",
      views: 876,
      completions: 543,
      rating: 4.6,
    },
    {
      title: "Frontend Developer Roadmap",
      type: "Roadmap",
      views: 765,
      completions: 432,
      rating: 4.9,
    },
    {
      title: "Node.js API Development",
      type: "Video",
      views: 654,
      completions: 321,
      rating: 4.5,
    },
  ]

  const userActivity = [
    { name: "John Doe", activity: "Completed JavaScript Basics", time: "2 hours ago" },
    { name: "Jane Smith", activity: "Started React Roadmap", time: "4 hours ago" },
    { name: "Alex Johnson", activity: "Downloaded CSS Grid PDF", time: "Yesterday" },
    { name: "Sarah Wilson", activity: "Asked AI Mentor a question", time: "Yesterday" },
    { name: "Michael Brown", activity: "Posted in Community", time: "2 days ago" },
  ]

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex items-center mb-8">
        <Button variant="ghost" size="icon" asChild className="mr-4">
          <Link href="/admin">
            <ArrowLeft className="h-4 w-4" />
            <span className="sr-only">Back</span>
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Analytics Dashboard</h1>
          <p className="text-muted-foreground">Monitor platform usage and user engagement</p>
        </div>
      </div>

      <div className="flex justify-end mb-6">
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select time range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="24h">Last 24 Hours</SelectItem>
            <SelectItem value="7d">Last 7 Days</SelectItem>
            <SelectItem value="30d">Last 30 Days</SelectItem>
            <SelectItem value="90d">Last 90 Days</SelectItem>
            <SelectItem value="1y">Last Year</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Total Users</CardDescription>
              <CardTitle className="text-3xl">{userStats.totalUsers.toLocaleString()}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xs text-muted-foreground">
                <span className="text-green-500">+{userStats.newThisWeek}</span> new this week
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
        >
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Active Today</CardDescription>
              <CardTitle className="text-3xl">{userStats.activeToday.toLocaleString()}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xs text-muted-foreground">
                {Math.round((userStats.activeToday / userStats.totalUsers) * 100)}% of total users
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
        >
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Total Content</CardDescription>
              <CardTitle className="text-3xl">{contentStats.totalContent.toLocaleString()}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xs text-muted-foreground">{contentStats.completionRate} completion rate</div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.3 }}
        >
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Total Views</CardDescription>
              <CardTitle className="text-3xl">{contentStats.totalViews.toLocaleString()}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xs text-muted-foreground">Most popular: {contentStats.mostPopularCategory}</div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <Tabs defaultValue="overview" className="mb-8">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="content">Content</TabsTrigger>
          <TabsTrigger value="engagement">Engagement</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>User Engagement</CardTitle>
                <CardDescription>Daily active users and content interactions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80 flex items-center justify-center">
                  <div className="w-full h-full flex flex-col justify-end">
                    <div className="flex h-64">
                      {engagementData.map((data, index) => (
                        <div key={index} className="flex-1 flex flex-col justify-end items-center gap-2">
                          <div className="w-full flex flex-col items-center gap-1">
                            <div
                              className="w-5/6 bg-primary/20 rounded-t-sm"
                              style={{ height: `${(data.users / 310) * 100}%` }}
                            ></div>
                            <div
                              className="w-5/6 bg-primary rounded-t-sm"
                              style={{ height: `${(data.content / 203) * 100}%` }}
                            ></div>
                          </div>
                          <span className="text-xs text-muted-foreground">{data.day}</span>
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-center gap-6 mt-4">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-primary/20 rounded-sm"></div>
                        <span className="text-xs">Users</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-primary rounded-sm"></div>
                        <span className="text-xs">Content Views</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top Content</CardTitle>
                <CardDescription>Most viewed and completed content</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {topContent.map((content, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-start gap-3">
                        <div className="rounded-full p-2 bg-secondary">
                          {content.type === "Video" && <Video className="h-4 w-4" />}
                          {content.type === "Note" && <BookOpen className="h-4 w-4" />}
                          {content.type === "PDF" && <FileText className="h-4 w-4" />}
                          {content.type === "Roadmap" && <Map className="h-4 w-4" />}
                        </div>
                        <div>
                          <p className="text-sm font-medium">{content.title}</p>
                          <p className="text-xs text-muted-foreground">
                            {content.views.toLocaleString()} views • {content.completions.toLocaleString()} completions
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-sm font-medium">{content.rating}</span>
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                          fill="currentColor"
                          className="w-4 h-4 text-yellow-500"
                        >
                          <path
                            fillRule="evenodd"
                            d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z"
                            clipRule="evenodd"
                          />
                        </svg>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  View All Content Analytics
                </Button>
              </CardFooter>
            </Card>
          </div>

          <div className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent User Activity</CardTitle>
                <CardDescription>Latest actions across the platform</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {userActivity.map((activity, index) => (
                    <div key={index} className="flex items-start gap-4">
                      <div className="rounded-full p-2 bg-secondary">
                        <Users className="h-4 w-4" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{activity.name}</p>
                        <p className="text-sm">{activity.activity}</p>
                        <p className="text-xs text-muted-foreground">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  View All Activity
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="users">
          <Card>
            <CardHeader>
              <CardTitle>User Analytics</CardTitle>
              <CardDescription>Detailed user statistics and demographics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                <div>
                  <h3 className="text-lg font-medium mb-4">User Growth</h3>
                  <div className="h-64 flex items-end">
                    {/* Placeholder for user growth chart */}
                    <div className="w-full h-full bg-secondary/20 rounded-md flex items-center justify-center">
                      <BarChart className="h-12 w-12 text-muted-foreground" />
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">User Demographics</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium">Experience Level</h4>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Beginner</span>
                          <span>45%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div className="bg-primary h-2 rounded-full" style={{ width: "45%" }}></div>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Intermediate</span>
                          <span>35%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div className="bg-primary h-2 rounded-full" style={{ width: "35%" }}></div>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Advanced</span>
                          <span>20%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div className="bg-primary h-2 rounded-full" style={{ width: "20%" }}></div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <h4 className="text-sm font-medium">Learning Goals</h4>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Frontend Development</span>
                          <span>60%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div className="bg-primary h-2 rounded-full" style={{ width: "60%" }}></div>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Backend Development</span>
                          <span>25%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div className="bg-primary h-2 rounded-full" style={{ width: "25%" }}></div>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Full Stack</span>
                          <span>15%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div className="bg-primary h-2 rounded-full" style={{ width: "15%" }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">
                <Download className="mr-2 h-4 w-4" />
                Export User Report
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="content">
          <Card>
            <CardHeader>
              <CardTitle>Content Analytics</CardTitle>
              <CardDescription>Performance metrics for all content types</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                <div>
                  <h3 className="text-lg font-medium mb-4">Content by Type</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="p-4 bg-secondary/20 rounded-lg text-center">
                      <Video className="h-8 w-8 mx-auto mb-2 text-primary" />
                      <p className="text-2xl font-bold">124</p>
                      <p className="text-sm text-muted-foreground">Videos</p>
                    </div>
                    <div className="p-4 bg-secondary/20 rounded-lg text-center">
                      <BookOpen className="h-8 w-8 mx-auto mb-2 text-primary" />
                      <p className="text-2xl font-bold">215</p>
                      <p className="text-sm text-muted-foreground">Notes</p>
                    </div>
                    <div className="p-4 bg-secondary/20 rounded-lg text-center">
                      <FileText className="h-8 w-8 mx-auto mb-2 text-primary" />
                      <p className="text-2xl font-bold">87</p>
                      <p className="text-sm text-muted-foreground">PDFs</p>
                    </div>
                    <div className="p-4 bg-secondary/20 rounded-lg text-center">
                      <Map className="h-8 w-8 mx-auto mb-2 text-primary" />
                      <p className="text-2xl font-bold">32</p>
                      <p className="text-sm text-muted-foreground">Roadmaps</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">Content Engagement</h3>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium">Average Completion Rate</h4>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Videos</span>
                          <span>72%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div className="bg-primary h-2 rounded-full" style={{ width: "72%" }}></div>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Notes</span>
                          <span>85%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div className="bg-primary h-2 rounded-full" style={{ width: "85%" }}></div>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>PDFs</span>
                          <span>64%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div className="bg-primary h-2 rounded-full" style={{ width: "64%" }}></div>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>Roadmaps</span>
                          <span>48%</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-2">
                          <div className="bg-primary h-2 rounded-full" style={{ width: "48%" }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">
                <Download className="mr-2 h-4 w-4" />
                Export Content Report
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="engagement">
          <Card>
            <CardHeader>
              <CardTitle>Engagement Metrics</CardTitle>
              <CardDescription>User interaction and retention statistics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                <div>
                  <h3 className="text-lg font-medium mb-4">Daily Active Users</h3>
                  <div className="h-64 flex items-end">
                    {/* Placeholder for DAU chart */}
                    <div className="w-full h-full bg-secondary/20 rounded-md flex items-center justify-center">
                      <BarChart className="h-12 w-12 text-muted-foreground" />
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">Retention Metrics</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="p-4 bg-secondary/20 rounded-lg text-center">
                      <p className="text-2xl font-bold">78%</p>
                      <p className="text-sm text-muted-foreground">7-Day Retention</p>
                    </div>
                    <div className="p-4 bg-secondary/20 rounded-lg text-center">
                      <p className="text-2xl font-bold">65%</p>
                      <p className="text-sm text-muted-foreground">30-Day Retention</p>
                    </div>
                    <div className="p-4 bg-secondary/20 rounded-lg text-center">
                      <p className="text-2xl font-bold">42%</p>
                      <p className="text-sm text-muted-foreground">90-Day Retention</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-4">Feature Usage</h3>
                  <div className="space-y-2">
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>Video Playback</span>
                        <span>86%</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "86%" }}></div>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>PDF Downloads</span>
                        <span>72%</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "72%" }}></div>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>AI Mentor</span>
                        <span>64%</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "64%" }}></div>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>Community</span>
                        <span>58%</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "58%" }}></div>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>Bookmarks</span>
                        <span>45%</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: "45%" }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">
                <Download className="mr-2 h-4 w-4" />
                Export Engagement Report
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
