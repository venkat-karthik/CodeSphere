"use client"

import { useState } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { ArrowLeft, Calendar, Clock, BookOpen, FileText, Video, Map, Users, Award, Bookmark } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function UserActivity({ params }: { params: { userId: string } }) {
  const { userId } = params
  const [timeRange, setTimeRange] = useState("7d")

  // Mock data - in a real app, this would come from an API call
  const user = {
    id: userId,
    name: "John Doe",
    email: "john.doe@example.com",
    role: "USER",
    joinedAt: "April 15, 2023",
    lastActive: "2 hours ago",
    avatar: "/placeholder.svg?height=96&width=96",
  }

  const userStats = {
    totalXP: 1250,
    level: 5,
    streak: 7,
    completedContent: 42,
    bookmarks: 18,
    communityPosts: 8,
  }

  const recentActivities = [
    { title: "Completed JavaScript Basics", time: "2 hours ago", type: "course" },
    { title: "Earned 'React Rookie' Badge", time: "Yesterday", type: "achievement" },
    { title: "Asked question in Community", time: "2 days ago", type: "community" },
    { title: "Started Python Roadmap", time: "1 week ago", type: "roadmap" },
    { title: "Saved 'Advanced CSS' PDF", time: "1 week ago", type: "pdf" },
    { title: "Watched 'Intro to TypeScript' video", time: "2 weeks ago", type: "video" },
    { title: "Completed CSS Grid Layout", time: "2 weeks ago", type: "course" },
    { title: "Bookmarked 'Node.js API Development'", time: "3 weeks ago", type: "bookmark" },
    { title: "Replied to a community post", time: "3 weeks ago", type: "community" },
    { title: "Earned 'CSS Master' Badge", time: "1 month ago", type: "achievement" },
  ]

  const achievements = [
    { name: "React Rookie", description: "Completed React basics", date: "2 weeks ago", icon: Award },
    { name: "CSS Master", description: "Finished advanced CSS course", date: "1 month ago", icon: Award },
    { name: "Git Pro", description: "Completed Git & GitHub essentials", date: "2 months ago", icon: Award },
    { name: "JavaScript Explorer", description: "Completed 10 JS exercises", date: "3 months ago", icon: Award },
  ]

  const contentProgress = [
    { title: "JavaScript Fundamentals", type: "course", progress: 100, completedAt: "2 days ago" },
    { title: "React Hooks Deep Dive", type: "video", progress: 75, completedAt: null },
    { title: "CSS Grid Layout", type: "note", progress: 100, completedAt: "2 weeks ago" },
    { title: "Frontend Developer Roadmap", type: "roadmap", progress: 45, completedAt: null },
    { title: "TypeScript for React Developers", type: "pdf", progress: 60, completedAt: null },
  ]

  // Generate streak calendar (last 7 days)
  const generateStreakCalendar = () => {
    const calendar = []
    const today = new Date()

    for (let i = 6; i >= 0; i--) {
      const date = new Date(today)
      date.setDate(date.getDate() - i)

      // Mock data - in a real app, fetch this from API
      const hasStreak = i <= userStats.streak

      calendar.push({
        date,
        hasStreak,
        xp: hasStreak ? Math.floor(Math.random() * 100) + 50 : 0,
      })
    }

    return calendar
  }

  const streakCalendar = generateStreakCalendar()

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex items-center mb-8">
        <Button variant="ghost" size="icon" asChild className="mr-4">
          <Link href="/admin/users">
            <ArrowLeft className="h-4 w-4" />
            <span className="sr-only">Back</span>
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">User Activity</h1>
          <p className="text-muted-foreground">Detailed activity for {user.name}</p>
        </div>
      </div>

      <div className="flex justify-end mb-6">
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select time range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="24h">Last 24 Hours</SelectItem>
            <SelectItem value="7d">Last 7 Days</SelectItem>
            <SelectItem value="30d">Last 30 Days</SelectItem>
            <SelectItem value="90d">Last 90 Days</SelectItem>
            <SelectItem value="all">All Time</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="md:col-span-1"
        >
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-center">
                <Avatar className="h-24 w-24">
                  <AvatarImage src={user.avatar || "/placeholder.svg"} />
                  <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                </Avatar>
              </div>
              <CardTitle className="text-center mt-4">{user.name}</CardTitle>
              <CardDescription className="text-center">{user.email}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Joined {user.joinedAt}</span>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Last active {user.lastActive}</span>
              </div>

              <div className="pt-4 border-t">
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col items-center p-3 rounded-lg bg-secondary/50">
                    <span className="text-2xl font-bold">{userStats.level}</span>
                    <span className="text-xs text-muted-foreground">Level</span>
                  </div>
                  <div className="flex flex-col items-center p-3 rounded-lg bg-secondary/50">
                    <span className="text-2xl font-bold">{userStats.totalXP}</span>
                    <span className="text-xs text-muted-foreground">Total XP</span>
                  </div>
                  <div className="flex flex-col items-center p-3 rounded-lg bg-secondary/50">
                    <span className="text-2xl font-bold">{userStats.streak}</span>
                    <span className="text-xs text-muted-foreground">Day Streak</span>
                  </div>
                  <div className="flex flex-col items-center p-3 rounded-lg bg-secondary/50">
                    <span className="text-2xl font-bold">{userStats.completedContent}</span>
                    <span className="text-xs text-muted-foreground">Completed</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="md:col-span-2"
        >
          <Card>
            <CardHeader>
              <CardTitle>Streak Calendar</CardTitle>
              <CardDescription>User's learning consistency</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-2">
                {streakCalendar.map((day, index) => (
                  <div key={index} className="flex flex-col items-center">
                    <div className="text-xs text-muted-foreground mb-1">
                      {day.date.toLocaleDateString("en-US", { weekday: "short" })}
                    </div>
                    <div
                      className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                        day.hasStreak
                          ? "bg-primary/20 text-primary border border-primary/50"
                          : "bg-secondary border border-border"
                      }`}
                    >
                      <div className="flex flex-col items-center">
                        <span className="text-sm font-medium">{day.date.getDate()}</span>
                        {day.hasStreak && <span className="text-xs">{day.xp} XP</span>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex justify-center mt-4">
                <Badge variant="outline" className="flex items-center gap-1">
                  <Award className="h-4 w-4 text-primary" />
                  <span>{userStats.streak} day streak</span>
                </Badge>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <Tabs defaultValue="activity" className="mb-8">
        <TabsList>
          <TabsTrigger value="activity">Recent Activity</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="progress">Content Progress</TabsTrigger>
        </TabsList>

        <TabsContent value="activity">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>User's latest actions on the platform</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                    className="flex items-start gap-4"
                  >
                    <div className="rounded-full p-2 bg-secondary">
                      {activity.type === "course" && <BookOpen className="h-4 w-4" />}
                      {activity.type === "achievement" && <Award className="h-4 w-4" />}
                      {activity.type === "community" && <Users className="h-4 w-4" />}
                      {activity.type === "roadmap" && <Map className="h-4 w-4" />}
                      {activity.type === "pdf" && <FileText className="h-4 w-4" />}
                      {activity.type === "video" && <Video className="h-4 w-4" />}
                      {activity.type === "bookmark" && <Bookmark className="h-4 w-4" />}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{activity.title}</p>
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {activity.time}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="achievements">
          <Card>
            <CardHeader>
              <CardTitle>Achievements</CardTitle>
              <CardDescription>Badges and milestones earned</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {achievements.map((achievement, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="flex items-start gap-4 p-4 rounded-lg bg-secondary/50"
                  >
                    <div className="rounded-full p-2 bg-amber-500/10 text-amber-500">
                      <achievement.icon className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-medium">{achievement.name}</h3>
                      <p className="text-sm text-muted-foreground">{achievement.description}</p>
                      <p className="text-xs text-muted-foreground mt-1">Earned {achievement.date}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="progress">
          <Card>
            <CardHeader>
              <CardTitle>Content Progress</CardTitle>
              <CardDescription>User's progress through learning materials</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {contentProgress.map((content, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="space-y-2"
                  >
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        {content.type === "course" && <BookOpen className="h-4 w-4 text-primary" />}
                        {content.type === "video" && <Video className="h-4 w-4 text-primary" />}
                        {content.type === "note" && <BookOpen className="h-4 w-4 text-primary" />}
                        {content.type === "roadmap" && <Map className="h-4 w-4 text-primary" />}
                        {content.type === "pdf" && <FileText className="h-4 w-4 text-primary" />}
                        <span className="font-medium">{content.title}</span>
                      </div>
                      <Badge variant={content.progress === 100 ? "default" : "outline"}>{content.progress}%</Badge>
                    </div>
                    <div className="w-full bg-secondary rounded-full h-2">
                      <div className="bg-primary h-2 rounded-full" style={{ width: `${content.progress}%` }}></div>
                    </div>
                    {content.completedAt && (
                      <p className="text-xs text-muted-foreground">Completed {content.completedAt}</p>
                    )}
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end">
        <Button variant="outline" asChild>
          <Link href={`/admin/users/${userId}`}>Edit User</Link>
        </Button>
      </div>
    </div>
  )
}
