"use client"
import Link from "next/link"
import { motion } from "framer-motion"
import { BookOpen, FileText, Video, Map, Users, BarChart, ArrowRight, Plus } from "lucide-react"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function AdminDashboard() {
  const adminModules = [
    {
      title: "Manage Notes",
      description: "Add, edit, or delete learning materials",
      icon: BookOpen,
      href: "/admin/notes",
      color: "bg-blue-500/10 text-blue-500",
    },
    {
      title: "Manage PDFs",
      description: "Upload, organize, or remove PDF documents",
      icon: FileText,
      href: "/admin/pdfs",
      color: "bg-red-500/10 text-red-500",
    },
    {
      title: "Manage Videos",
      description: "Add, update, or delete video tutorials",
      icon: Video,
      href: "/admin/videos",
      color: "bg-purple-500/10 text-purple-500",
    },
    {
      title: "Manage Roadmaps",
      description: "Create or modify learning paths",
      icon: Map,
      href: "/admin/roadmaps",
      color: "bg-green-500/10 text-green-500",
    },
    {
      title: "User Management",
      description: "View and manage user accounts",
      icon: Users,
      href: "/admin/users",
      color: "bg-amber-500/10 text-amber-500",
    },
    {
      title: "Analytics",
      description: "View platform usage and user statistics",
      icon: BarChart,
      href: "/admin/analytics",
      color: "bg-pink-500/10 text-pink-500",
    },
  ]

  const recentStats = [
    { label: "Total Users", value: 1245 },
    { label: "Active Today", value: 328 },
    { label: "Content Items", value: 567 },
    { label: "Completed Items", value: 12450 },
  ]

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
          <p className="text-muted-foreground">Manage content and monitor platform activity</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {recentStats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card>
              <CardHeader className="pb-2">
                <CardDescription>{stat.label}</CardDescription>
                <CardTitle className="text-3xl">{stat.value.toLocaleString()}</CardTitle>
              </CardHeader>
            </Card>
          </motion.div>
        ))}
      </div>

      <Tabs defaultValue="modules" className="mb-8">
        <TabsList>
          <TabsTrigger value="modules">Admin Modules</TabsTrigger>
          <TabsTrigger value="recent">Recent Activity</TabsTrigger>
        </TabsList>
        <TabsContent value="modules">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
            {adminModules.map((module, index) => (
              <motion.div
                key={module.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Card className="h-full hover:bg-secondary/50 transition-colors">
                  <CardHeader>
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${module.color}`}>
                      <module.icon className="h-6 w-6" />
                    </div>
                    <CardTitle className="mt-4">{module.title}</CardTitle>
                    <CardDescription>{module.description}</CardDescription>
                  </CardHeader>
                  <CardFooter>
                    <Button className="w-full" asChild>
                      <Link href={module.href}>
                        Manage
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="recent">
          <div className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Platform Activity</CardTitle>
                <CardDescription>Latest actions across the platform</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start gap-4">
                    <div className="rounded-full p-2 bg-secondary">
                      <Users className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">New user registered</p>
                      <p className="text-xs text-muted-foreground">2 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="rounded-full p-2 bg-secondary">
                      <Video className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">New video tutorial added</p>
                      <p className="text-xs text-muted-foreground">4 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="rounded-full p-2 bg-secondary">
                      <FileText className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">PDF document updated</p>
                      <p className="text-xs text-muted-foreground">Yesterday</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="rounded-full p-2 bg-secondary">
                      <BookOpen className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">New note created</p>
                      <p className="text-xs text-muted-foreground">2 days ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  View All Activity
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common administrative tasks</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button className="w-full justify-start" variant="outline" asChild>
              <Link href="/admin/notes/new">
                <Plus className="mr-2 h-4 w-4" />
                Add New Note
              </Link>
            </Button>
            <Button className="w-full justify-start" variant="outline" asChild>
              <Link href="/admin/pdfs/new">
                <Plus className="mr-2 h-4 w-4" />
                Upload New PDF
              </Link>
            </Button>
            <Button className="w-full justify-start" variant="outline" asChild>
              <Link href="/admin/videos/new">
                <Plus className="mr-2 h-4 w-4" />
                Add New Video
              </Link>
            </Button>
            <Button className="w-full justify-start" variant="outline" asChild>
              <Link href="/admin/roadmaps/new">
                <Plus className="mr-2 h-4 w-4" />
                Create New Roadmap
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>System Status</CardTitle>
            <CardDescription>Platform health and metrics</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm">Server Status</span>
                <span className="text-sm font-medium text-green-500">Operational</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Database Status</span>
                <span className="text-sm font-medium text-green-500">Operational</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Storage Usage</span>
                <span className="text-sm font-medium">42% (4.2/10GB)</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">API Requests (24h)</span>
                <span className="text-sm font-medium">12,450</span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              View Detailed Metrics
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
