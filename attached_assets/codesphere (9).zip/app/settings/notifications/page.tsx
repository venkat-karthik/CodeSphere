"use client"

import { useState } from "react"
import { Bell, Mail } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"

export default function NotificationsSettings() {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)

  const [emailNotifications, setEmailNotifications] = useState({
    newMessages: true,
    newClasses: true,
    newRoadmaps: false,
    newChallenges: true,
    weeklyDigest: true,
  })

  const [pushNotifications, setPushNotifications] = useState({
    newMessages: true,
    newClasses: true,
    newRoadmaps: true,
    newChallenges: true,
    weeklyDigest: false,
  })

  const saveSettings = async () => {
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    toast({
      title: "Settings saved",
      description: "Your notification preferences have been updated.",
    })

    setIsLoading(false)
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Notification Settings</h1>
      </div>

      <Tabs defaultValue="email" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="email">Email</TabsTrigger>
          <TabsTrigger value="push">Push</TabsTrigger>
        </TabsList>

        <TabsContent value="email" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                Email Notifications
              </CardTitle>
              <CardDescription>Configure which email notifications you want to receive</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">New Messages</h4>
                  <p className="text-sm text-muted-foreground">Receive emails when someone sends you a message</p>
                </div>
                <Switch
                  checked={emailNotifications.newMessages}
                  onCheckedChange={(checked) => setEmailNotifications({ ...emailNotifications, newMessages: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">New Classes</h4>
                  <p className="text-sm text-muted-foreground">Get notified when new classes are available</p>
                </div>
                <Switch
                  checked={emailNotifications.newClasses}
                  onCheckedChange={(checked) => setEmailNotifications({ ...emailNotifications, newClasses: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">New Roadmaps</h4>
                  <p className="text-sm text-muted-foreground">Get notified when new learning roadmaps are published</p>
                </div>
                <Switch
                  checked={emailNotifications.newRoadmaps}
                  onCheckedChange={(checked) => setEmailNotifications({ ...emailNotifications, newRoadmaps: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">New Challenges</h4>
                  <p className="text-sm text-muted-foreground">Get notified when new coding challenges are available</p>
                </div>
                <Switch
                  checked={emailNotifications.newChallenges}
                  onCheckedChange={(checked) =>
                    setEmailNotifications({ ...emailNotifications, newChallenges: checked })
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">Weekly Digest</h4>
                  <p className="text-sm text-muted-foreground">
                    Receive a weekly summary of your progress and new content
                  </p>
                </div>
                <Switch
                  checked={emailNotifications.weeklyDigest}
                  onCheckedChange={(checked) => setEmailNotifications({ ...emailNotifications, weeklyDigest: checked })}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="push" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Push Notifications
              </CardTitle>
              <CardDescription>Configure which push notifications you want to receive</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">New Messages</h4>
                  <p className="text-sm text-muted-foreground">
                    Receive push notifications when someone sends you a message
                  </p>
                </div>
                <Switch
                  checked={pushNotifications.newMessages}
                  onCheckedChange={(checked) => setPushNotifications({ ...pushNotifications, newMessages: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">New Classes</h4>
                  <p className="text-sm text-muted-foreground">Get notified when new classes are available</p>
                </div>
                <Switch
                  checked={pushNotifications.newClasses}
                  onCheckedChange={(checked) => setPushNotifications({ ...pushNotifications, newClasses: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">New Roadmaps</h4>
                  <p className="text-sm text-muted-foreground">Get notified when new learning roadmaps are published</p>
                </div>
                <Switch
                  checked={pushNotifications.newRoadmaps}
                  onCheckedChange={(checked) => setPushNotifications({ ...pushNotifications, newRoadmaps: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">New Challenges</h4>
                  <p className="text-sm text-muted-foreground">Get notified when new coding challenges are available</p>
                </div>
                <Switch
                  checked={pushNotifications.newChallenges}
                  onCheckedChange={(checked) => setPushNotifications({ ...pushNotifications, newChallenges: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <h4 className="font-medium">Weekly Digest</h4>
                  <p className="text-sm text-muted-foreground">
                    Receive a weekly summary of your progress and new content
                  </p>
                </div>
                <Switch
                  checked={pushNotifications.weeklyDigest}
                  onCheckedChange={(checked) => setPushNotifications({ ...pushNotifications, weeklyDigest: checked })}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end">
        <Button onClick={saveSettings} disabled={isLoading}>
          {isLoading ? "Saving..." : "Save Changes"}
        </Button>
      </div>
    </div>
  )
}
