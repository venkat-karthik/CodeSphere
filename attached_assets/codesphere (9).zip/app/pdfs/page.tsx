"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Search, Filter, Plus, FileText, Clock, Calendar, Download } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FileViewer } from "@/components/file-viewer"

export default function PDFs() {
  const [searchQuery, setSearchQuery] = useState("")

  const categories = ["All", "JavaScript", "React", "CSS", "HTML", "TypeScript", "Node.js", "Python"]

  const pdfs = [
    {
      id: 1,
      title: "JavaScript: The Complete Guide",
      description: "Comprehensive guide to JavaScript from basics to advanced concepts",
      category: "JavaScript",
      date: "2023-05-15",
      author: "John Doe",
      fileUrl: "/placeholder.svg?height=500&width=800",
      fileSize: "5.2 MB",
      downloads: 1245,
    },
    {
      id: 2,
      title: "React Patterns and Best Practices",
      description: "Learn the most effective patterns for building React applications",
      category: "React",
      date: "2023-04-22",
      author: "Jane Smith",
      fileUrl: "/placeholder.svg?height=500&width=800",
      fileSize: "4.5 MB",
      downloads: 987,
    },
    {
      id: 3,
      title: "CSS: The Missing Manual",
      description: "Everything you need to know about modern CSS techniques",
      category: "CSS",
      date: "2023-03-10",
      author: "David Chen",
      fileUrl: "/placeholder.svg?height=500&width=800",
      fileSize: "6.8 MB",
      downloads: 756,
    },
    {
      id: 4,
      title: "HTML5 for Professionals",
      description: "Advanced HTML5 techniques for modern web development",
      category: "HTML",
      date: "2023-02-05",
      author: "Emily Rodriguez",
      fileUrl: "/placeholder.svg?height=500&width=800",
      fileSize: "3.0 MB",
      downloads: 632,
    },
    {
      id: 5,
      title: "TypeScript Handbook",
      description: "Official TypeScript handbook with examples and best practices",
      category: "TypeScript",
      date: "2023-01-20",
      author: "Microsoft",
      fileUrl: "/placeholder.svg?height=500&width=800",
      fileSize: "4.5 MB",
      downloads: 543,
    },
    {
      id: 6,
      title: "Node.js Design Patterns",
      description: "Advanced design patterns for Node.js applications",
      category: "Node.js",
      date: "2022-12-10",
      author: "Michael Park",
      fileUrl: "/placeholder.svg?height=500&width=800",
      fileSize: "7.0 MB",
      downloads: 421,
    },
  ]

  const filteredPDFs = pdfs.filter(
    (pdf) =>
      pdf.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pdf.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pdf.author.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">PDF Resources</h1>
          <p className="text-muted-foreground">Browse and download educational documents</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button>
            Upload PDF
            <Plus className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search PDFs..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Select defaultValue="newest">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest First</SelectItem>
              <SelectItem value="oldest">Oldest First</SelectItem>
              <SelectItem value="popular">Most Downloaded</SelectItem>
              <SelectItem value="a-z">A-Z</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-4 flex flex-wrap h-auto">
          {categories.map((category) => (
            <TabsTrigger key={category} value={category === "All" ? "all" : category.toLowerCase()}>
              {category}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPDFs.map((pdf, index) => (
              <motion.div
                key={pdf.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Card className="h-full hover:bg-secondary/50 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="rounded-lg p-2 bg-primary/10 text-primary">
                        <FileText className="h-4 w-4" />
                      </div>
                      <Badge variant="outline">{pdf.category}</Badge>
                    </div>
                    <CardTitle className="mt-2">{pdf.title}</CardTitle>
                    <CardDescription>{pdf.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="flex flex-col gap-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span>Published: {formatDate(pdf.date)}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>Author: {pdf.author}</span>
                      </div>
                      <div className="flex justify-between text-sm text-muted-foreground mt-2">
                        <span>{pdf.fileSize}</span>
                        <span>{pdf.downloads} downloads</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <FileViewer fileUrl={pdf.fileUrl} fileName={pdf.title} fileType="pdf" fileSize={pdf.fileSize} />
                    <Button variant="outline" size="sm" className="flex items-center gap-1">
                      <Download className="h-4 w-4" />
                      <span>Download</span>
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {categories.slice(1).map((category) => (
          <TabsContent key={category} value={category.toLowerCase()}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPDFs
                .filter((pdf) => pdf.category === category)
                .map((pdf, index) => (
                  <motion.div
                    key={pdf.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="h-full hover:bg-secondary/50 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div className="rounded-lg p-2 bg-primary/10 text-primary">
                            <FileText className="h-4 w-4" />
                          </div>
                          <Badge variant="outline">{pdf.category}</Badge>
                        </div>
                        <CardTitle className="mt-2">{pdf.title}</CardTitle>
                        <CardDescription>{pdf.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="flex flex-col gap-2 text-sm">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span>Published: {formatDate(pdf.date)}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span>Author: {pdf.author}</span>
                          </div>
                          <div className="flex justify-between text-sm text-muted-foreground mt-2">
                            <span>{pdf.fileSize}</span>
                            <span>{pdf.downloads} downloads</span>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between">
                        <FileViewer fileUrl={pdf.fileUrl} fileName={pdf.title} fileType="pdf" fileSize={pdf.fileSize} />
                        <Button variant="outline" size="sm" className="flex items-center gap-1">
                          <Download className="h-4 w-4" />
                          <span>Download</span>
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
