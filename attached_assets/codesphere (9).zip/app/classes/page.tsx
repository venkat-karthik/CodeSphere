"use client"

import { useState } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { Search, Filter, Plus, Calendar, Clock, Users, ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useSession } from "next-auth/react"

export default function ClassesPage() {
  const { data: session } = useSession()
  const [searchQuery, setSearchQuery] = useState("")

  const categories = ["All", "Web Development", "Mobile Development", "Data Science", "DevOps", "Design", "Blockchain"]

  const classes = [
    {
      id: "1",
      title: "Introduction to JavaScript",
      description: "Learn the basics of JavaScript programming language",
      instructor: "Sarah Johnson",
      date: "2023-06-15",
      time: "10:00 AM",
      duration: "1 hour",
      level: "Beginner",
      category: "Web Development",
      enrolled: 24,
      maxCapacity: 30,
      image: "/placeholder.svg?height=150&width=300",
    },
    {
      id: "2",
      title: "Advanced React Patterns",
      description: "Master advanced React patterns and performance optimization",
      instructor: "Michael Chen",
      date: "2023-06-16",
      time: "2:00 PM",
      duration: "1.5 hours",
      level: "Advanced",
      category: "Web Development",
      enrolled: 18,
      maxCapacity: 25,
      image: "/placeholder.svg?height=150&width=300",
    },
    {
      id: "3",
      title: "Introduction to Machine Learning",
      description: "Understand the basics of machine learning algorithms",
      instructor: "Emily Rodriguez",
      date: "2023-06-17",
      time: "11:00 AM",
      duration: "2 hours",
      level: "Intermediate",
      category: "Data Science",
      enrolled: 32,
      maxCapacity: 40,
      image: "/placeholder.svg?height=150&width=300",
    },
    {
      id: "4",
      title: "Mobile App Design Principles",
      description: "Learn essential design principles for mobile applications",
      instructor: "David Kim",
      date: "2023-06-18",
      time: "1:00 PM",
      duration: "1 hour",
      level: "Beginner",
      category: "Design",
      enrolled: 15,
      maxCapacity: 30,
      image: "/placeholder.svg?height=150&width=300",
    },
    {
      id: "5",
      title: "Docker and Kubernetes Fundamentals",
      description: "Get started with containerization and orchestration",
      instructor: "Alex Johnson",
      date: "2023-06-19",
      time: "3:00 PM",
      duration: "2 hours",
      level: "Intermediate",
      category: "DevOps",
      enrolled: 20,
      maxCapacity: 25,
      image: "/placeholder.svg?height=150&width=300",
    },
    {
      id: "6",
      title: "Blockchain Development with Solidity",
      description: "Build decentralized applications on Ethereum",
      instructor: "Jessica Wang",
      date: "2023-06-20",
      time: "4:00 PM",
      duration: "1.5 hours",
      level: "Advanced",
      category: "Blockchain",
      enrolled: 12,
      maxCapacity: 20,
      image: "/placeholder.svg?height=150&width=300",
    },
  ]

  const filteredClasses = classes.filter(
    (cls) =>
      cls.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cls.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cls.instructor.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const isTeacher = session?.user?.role === "teacher" || session?.user?.role === "admin"

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Online Classes</h1>
          <p className="text-muted-foreground">Join live coding sessions with expert instructors</p>
        </div>
        {isTeacher && (
          <div className="mt-4 md:mt-0">
            <Button asChild>
              <Link href="/classes/create">
                <Plus className="mr-2 h-4 w-4" />
                Create Class
              </Link>
            </Button>
          </div>
        )}
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search classes..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Select defaultValue="upcoming">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="upcoming">Upcoming</SelectItem>
              <SelectItem value="popular">Most Popular</SelectItem>
              <SelectItem value="beginner">Beginner Friendly</SelectItem>
              <SelectItem value="advanced">Advanced</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-4 flex flex-wrap h-auto">
          {categories.map((category) => (
            <TabsTrigger
              key={category}
              value={category === "All" ? "all" : category.toLowerCase().replace(/\s+/g, "-")}
            >
              {category}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredClasses.map((cls, index) => (
              <motion.div
                key={cls.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Card className="h-full hover:bg-secondary/50 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="relative rounded-lg overflow-hidden aspect-video mb-3">
                      <img
                        src={cls.image || "/placeholder.svg"}
                        alt={cls.title}
                        className="object-cover w-full h-full"
                      />
                      <Badge className="absolute top-2 right-2">{cls.level}</Badge>
                    </div>
                    <CardTitle className="line-clamp-1">{cls.title}</CardTitle>
                    <CardDescription className="line-clamp-2">{cls.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="flex flex-col gap-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span>{cls.date}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>
                          {cls.time} ({cls.duration})
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <span>
                          {cls.enrolled}/{cls.maxCapacity} enrolled
                        </span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <div className="text-sm">
                      <span className="text-muted-foreground">Instructor:</span> {cls.instructor}
                    </div>
                    <Button variant="ghost" size="sm" asChild>
                      <Link href={`/classes/${cls.id}`}>
                        View Details
                        <ArrowRight className="ml-2 h-3 w-3" />
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {categories.slice(1).map((category) => (
          <TabsContent key={category} value={category.toLowerCase().replace(/\s+/g, "-")}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredClasses
                .filter((cls) => cls.category === category)
                .map((cls, index) => (
                  <motion.div
                    key={cls.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="h-full hover:bg-secondary/50 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="relative rounded-lg overflow-hidden aspect-video mb-3">
                          <img
                            src={cls.image || "/placeholder.svg"}
                            alt={cls.title}
                            className="object-cover w-full h-full"
                          />
                          <Badge className="absolute top-2 right-2">{cls.level}</Badge>
                        </div>
                        <CardTitle className="line-clamp-1">{cls.title}</CardTitle>
                        <CardDescription className="line-clamp-2">{cls.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="flex flex-col gap-2 text-sm">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span>{cls.date}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span>
                              {cls.time} ({cls.duration})
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Users className="h-4 w-4 text-muted-foreground" />
                            <span>
                              {cls.enrolled}/{cls.maxCapacity} enrolled
                            </span>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between">
                        <div className="text-sm">
                          <span className="text-muted-foreground">Instructor:</span> {cls.instructor}
                        </div>
                        <Button variant="ghost" size="sm" asChild>
                          <Link href={`/classes/${cls.id}`}>
                            View Details
                            <ArrowRight className="ml-2 h-3 w-3" />
                          </Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
