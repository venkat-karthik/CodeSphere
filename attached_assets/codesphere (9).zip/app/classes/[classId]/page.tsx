"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Calendar, Clock, Users, BookOpen, ArrowLeft, Video } from "lucide-react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Skeleton } from "@/components/ui/skeleton"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"
import { useSession } from "next-auth/react"

// Mock class data
const MOCK_CLASSES = [
  {
    id: "1",
    title: "Introduction to JavaScript",
    description:
      "Learn the basics of JavaScript programming language. This comprehensive course covers variables, data types, functions, control flow, and more. By the end of this course, you will have a solid foundation in JavaScript programming and be ready to tackle more advanced topics.",
    instructor: "Sarah Johnson",
    instructorId: "101",
    instructorBio:
      "Sarah is a senior frontend developer with over 8 years of experience. She specializes in JavaScript and modern frontend frameworks.",
    instructorAvatar: "/placeholder.svg?height=40&width=40",
    date: "2023-06-15",
    time: "10:00 AM",
    duration: "1 hour",
    level: "Beginner",
    category: "Web Development",
    enrolled: 24,
    maxCapacity: 30,
    image: "/placeholder.svg?height=400&width=800",
    tags: ["JavaScript", "Programming", "Web"],
    syllabus: [
      { title: "Introduction to JavaScript", duration: "15 min" },
      { title: "Variables and Data Types", duration: "20 min" },
      { title: "Functions and Scope", duration: "25 min" },
    ],
    requirements: [
      "Basic understanding of HTML and CSS",
      "A computer with a modern web browser",
      "No prior JavaScript knowledge required",
    ],
    students: [
      { id: "201", name: "John Smith", avatar: "/placeholder.svg?height=40&width=40" },
      { id: "202", name: "Emily Brown", avatar: "/placeholder.svg?height=40&width=40" },
      { id: "203", name: "Michael Lee", avatar: "/placeholder.svg?height=40&width=40" },
      { id: "204", name: "Jessica Wang", avatar: "/placeholder.svg?height=40&width=40" },
      { id: "205", name: "David Kim", avatar: "/placeholder.svg?height=40&width=40" },
    ],
  },
  // Other classes...
]

export default function ClassDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { data: session } = useSession()
  const { toast } = useToast()

  const [isLoading, setIsLoading] = useState(true)
  const [classData, setClassData] = useState<any>(null)
  const [isEnrolled, setIsEnrolled] = useState(false)

  useEffect(() => {
    // Simulate API call
    const loadClassData = async () => {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      const foundClass = MOCK_CLASSES.find((c) => c.id === params.classId)

      if (foundClass) {
        setClassData(foundClass)
        // Check if user is enrolled (mock)
        setIsEnrolled(Math.random() > 0.5)
      }

      setIsLoading(false)
    }

    loadClassData()
  }, [params.classId])

  const handleEnroll = async () => {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    setIsEnrolled(true)
    toast({
      title: "Successfully enrolled",
      description: `You have been enrolled in ${classData.title}`,
    })
  }

  const isTeacher = session?.user?.role === "teacher" || session?.user?.role === "admin"
  const isClassTeacher = isTeacher && session?.user?.id === classData?.instructorId

  if (isLoading) {
    return (
      <div className="container mx-auto py-6 space-y-6">
        <div className="flex items-center gap-2">
          <Skeleton className="h-10 w-10" />
          <Skeleton className="h-8 w-48" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Skeleton className="h-[400px] w-full" />

            <div className="space-y-4">
              <Skeleton className="h-10 w-3/4" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-2/3" />
            </div>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
              </CardHeader>
              <CardContent className="space-y-4">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
              </CardContent>
              <CardFooter>
                <Skeleton className="h-10 w-full" />
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-40" />
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  <Skeleton className="h-12 w-12 rounded-full" />
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  if (!classData) {
    return (
      <div className="container mx-auto py-12 text-center">
        <h2 className="text-2xl font-bold">Class not found</h2>
        <p className="text-muted-foreground mt-2">The class you are looking for does not exist or has been removed.</p>
        <Button asChild className="mt-6">
          <Link href="/classes">Back to Classes</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" onClick={() => router.back()}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-bold">Class Details</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <img
            src={classData.image || "/placeholder.svg"}
            alt={classData.title}
            className="w-full h-auto rounded-lg object-cover"
          />

          <div>
            <h1 className="text-3xl font-bold">{classData.title}</h1>
            <div className="flex flex-wrap gap-2 mt-2">
              <Badge>{classData.level}</Badge>
              <Badge variant="outline">{classData.category}</Badge>
              {classData.tags.map((tag: string) => (
                <Badge key={tag} variant="secondary">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>

          <Tabs defaultValue="about">
            <TabsList>
              <TabsTrigger value="about">About</TabsTrigger>
              <TabsTrigger value="syllabus">Syllabus</TabsTrigger>
              <TabsTrigger value="students">Students</TabsTrigger>
            </TabsList>

            <TabsContent value="about" className="space-y-4">
              <div>
                <h3 className="text-xl font-semibold">Description</h3>
                <p className="mt-2">{classData.description}</p>
              </div>

              <div>
                <h3 className="text-xl font-semibold">Requirements</h3>
                <ul className="mt-2 space-y-1 list-disc pl-5">
                  {classData.requirements.map((req: string, index: number) => (
                    <li key={index}>{req}</li>
                  ))}
                </ul>
              </div>
            </TabsContent>

            <TabsContent value="syllabus">
              <div className="space-y-4">
                <h3 className="text-xl font-semibold">Class Syllabus</h3>
                <div className="space-y-2">
                  {classData.syllabus.map((item: any, index: number) => (
                    <Card key={index}>
                      <CardContent className="p-4 flex justify-between items-center">
                        <div className="flex items-center gap-3">
                          <div className="bg-primary/10 text-primary rounded-full w-8 h-8 flex items-center justify-center">
                            {index + 1}
                          </div>
                          <span>{item.title}</span>
                        </div>
                        <Badge variant="outline">{item.duration}</Badge>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="students">
              <div className="space-y-4">
                <h3 className="text-xl font-semibold">Enrolled Students</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {classData.students.map((student: any) => (
                    <Card key={student.id}>
                      <CardContent className="p-4 flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={student.avatar || "/placeholder.svg"} alt={student.name} />
                          <AvatarFallback>{student.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <span>{student.name}</span>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Class Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-muted-foreground" />
                <span>{classData.date}</span>
              </div>

              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-muted-foreground" />
                <span>
                  {classData.time} ({classData.duration})
                </span>
              </div>

              <div className="flex items-center gap-2">
                <Users className="h-5 w-5 text-muted-foreground" />
                <span>
                  {classData.enrolled}/{classData.maxCapacity} enrolled
                </span>
              </div>

              <div className="flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-muted-foreground" />
                <span>{classData.level}</span>
              </div>
            </CardContent>
            <CardFooter>
              {isEnrolled ? (
                <Button className="w-full" asChild>
                  <Link href={`/classes/${classData.id}/meeting`}>
                    <Video className="mr-2 h-4 w-4" />
                    Join Class
                  </Link>
                </Button>
              ) : (
                <Button
                  className="w-full"
                  onClick={handleEnroll}
                  disabled={classData.enrolled >= classData.maxCapacity}
                >
                  {classData.enrolled >= classData.maxCapacity ? "Class Full" : "Enroll Now"}
                </Button>
              )}
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Instructor</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={classData.instructorAvatar || "/placeholder.svg"} alt={classData.instructor} />
                  <AvatarFallback>{classData.instructor.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <h4 className="font-medium">{classData.instructor}</h4>
                  <p className="text-sm text-muted-foreground">{classData.instructorBio}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {isClassTeacher && (
            <Card>
              <CardHeader>
                <CardTitle>Instructor Controls</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="w-full" asChild>
                  <Link href={`/classes/${classData.id}/meeting`}>
                    <Video className="mr-2 h-4 w-4" />
                    Start Class
                  </Link>
                </Button>
                <Button variant="outline" className="w-full">
                  Edit Class Details
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
