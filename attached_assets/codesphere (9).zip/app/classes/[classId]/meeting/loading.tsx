import { Skeleton } from "@/components/ui/skeleton"

export default function MeetingLoading() {
  return (
    <div className="h-screen flex items-center justify-center">
      <Skeleton className="h-[400px] w-[600px]" />
    </div>
  )
}
