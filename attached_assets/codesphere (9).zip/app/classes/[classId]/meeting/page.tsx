"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { VideoMeeting } from "@/components/video-meeting"
import { Skeleton } from "@/components/ui/skeleton"

// Mock class data
const MOCK_CLASSES = [
  {
    id: "1",
    title: "Introduction to JavaScript",
    instructor: {
      id: "101",
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    participants: [
      { id: "201", name: "John Smith", avatar: "/placeholder.svg?height=40&width=40", role: "student" as const },
      { id: "202", name: "Emily Brown", avatar: "/placeholder.svg?height=40&width=40", role: "student" as const },
      { id: "203", name: "Michael Lee", avatar: "/placeholder.svg?height=40&width=40", role: "student" as const },
      { id: "204", name: "Jessica Wang", avatar: "/placeholder.svg?height=40&width=40", role: "student" as const },
      { id: "205", name: "David Kim", avatar: "/placeholder.svg?height=40&width=40", role: "student" as const },
    ],
  },
  // Other classes...
]

export default function MeetingPage() {
  const params = useParams()
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [classData, setClassData] = useState<any>(null)

  useEffect(() => {
    // Simulate API call
    const loadClassData = async () => {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      const foundClass = MOCK_CLASSES.find((c) => c.id === params.classId)

      if (foundClass) {
        setClassData(foundClass)
      }

      setIsLoading(false)
    }

    loadClassData()
  }, [params.classId])

  const handleEndMeeting = () => {
    router.push(`/classes/${params.classId}`)
  }

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <Skeleton className="h-[400px] w-[600px]" />
      </div>
    )
  }

  if (!classData) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold">Class not found</h2>
          <p className="text-muted-foreground mt-2">
            The class you are looking for does not exist or has been removed.
          </p>
        </div>
      </div>
    )
  }

  return (
    <VideoMeeting
      classId={params.classId as string}
      className={classData.title}
      instructor={classData.instructor}
      participants={classData.participants}
      onEndMeeting={handleEndMeeting}
    />
  )
}
