"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Search, Play, ArrowRight, Filter, Clock } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"

export default function Videos() {
  const [searchQuery, setSearchQuery] = useState("")

  const categories = ["All", "JavaScript", "React", "Node.js", "CSS", "HTML", "TypeScript", "Python"]

  const videos = [
    {
      id: 1,
      title: "JavaScript Crash Course for Beginners",
      description: "Learn JavaScript basics in this comprehensive crash course for beginners",
      category: "JavaScript",
      tags: ["beginner", "fundamentals"],
      duration: "45:22",
      views: 12450,
      thumbnail: "/placeholder.svg?height=180&width=320",
      createdAt: "2 months ago",
    },
    {
      id: 2,
      title: "React Hooks Deep Dive",
      description: "Master React hooks with practical examples and advanced patterns",
      category: "React",
      tags: ["intermediate", "hooks"],
      duration: "32:15",
      views: 8765,
      thumbnail: "/placeholder.svg?height=180&width=320",
      createdAt: "3 weeks ago",
    },
    {
      id: 3,
      title: "CSS Grid and Flexbox Tutorial",
      description: "Learn modern CSS layout techniques with detailed examples",
      category: "CSS",
      tags: ["intermediate", "layout"],
      duration: "28:47",
      views: 6543,
      thumbnail: "/placeholder.svg?height=180&width=320",
      createdAt: "1 month ago",
    },
    {
      id: 4,
      title: "Building a REST API with Node.js",
      description: "Step-by-step guide to creating a RESTful API with Node.js and Express",
      category: "Node.js",
      tags: ["advanced", "backend"],
      duration: "54:18",
      views: 5432,
      thumbnail: "/placeholder.svg?height=180&width=320",
      createdAt: "2 weeks ago",
    },
    {
      id: 5,
      title: "TypeScript for React Developers",
      description: "Learn how to use TypeScript with React for type-safe applications",
      category: "TypeScript",
      tags: ["intermediate", "types"],
      duration: "38:29",
      views: 4321,
      thumbnail: "/placeholder.svg?height=180&width=320",
      createdAt: "1 week ago",
    },
    {
      id: 6,
      title: "HTML5 Semantic Elements Explained",
      description: "Understanding semantic HTML for better accessibility and SEO",
      category: "HTML",
      tags: ["beginner", "accessibility"],
      duration: "22:36",
      views: 3210,
      thumbnail: "/placeholder.svg?height=180&width=320",
      createdAt: "3 months ago",
    },
  ]

  const filteredVideos = videos.filter(
    (video) =>
      video.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      video.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Video Tutorials</h1>
          <p className="text-muted-foreground">Watch and learn with our curated video content</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button asChild>
            <Link href="/videos/latest">
              Latest Videos
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search videos..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Select defaultValue="newest">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest First</SelectItem>
              <SelectItem value="oldest">Oldest First</SelectItem>
              <SelectItem value="popular">Most Viewed</SelectItem>
              <SelectItem value="duration">Duration</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-4 flex flex-wrap h-auto">
          {categories.map((category) => (
            <TabsTrigger key={category} value={category === "All" ? "all" : category.toLowerCase()}>
              {category}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredVideos.map((video, index) => (
              <motion.div
                key={video.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Card className="h-full hover:bg-secondary/50 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="relative rounded-lg overflow-hidden mb-3 aspect-video">
                      <img
                        src={video.thumbnail || "/placeholder.svg"}
                        alt={video.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                        <Button size="icon" variant="secondary" className="rounded-full" asChild>
                          <Link href={`/videos/${video.id}`}>
                            <Play className="h-5 w-5" />
                          </Link>
                        </Button>
                      </div>
                      <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        {video.duration}
                      </div>
                    </div>
                    <div className="flex justify-between items-start">
                      <Badge variant="outline">{video.category}</Badge>
                    </div>
                    <CardTitle className="mt-2 text-lg">{video.title}</CardTitle>
                    <CardDescription>{video.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="flex flex-wrap gap-2">
                      {video.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between items-center">
                    <span className="text-xs text-muted-foreground">
                      {video.views.toLocaleString()} views • Added {video.createdAt}
                    </span>
                    <Button variant="ghost" size="sm" asChild>
                      <Link href={`/videos/${video.id}`}>
                        Watch Now
                        <ArrowRight className="ml-2 h-3 w-3" />
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {categories.slice(1).map((category) => (
          <TabsContent key={category} value={category.toLowerCase()}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredVideos
                .filter((video) => video.category === category)
                .map((video, index) => (
                  <motion.div
                    key={video.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="h-full hover:bg-secondary/50 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="relative rounded-lg overflow-hidden mb-3 aspect-video">
                          <img
                            src={video.thumbnail || "/placeholder.svg"}
                            alt={video.title}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                            <Button size="icon" variant="secondary" className="rounded-full" asChild>
                              <Link href={`/videos/${video.id}`}>
                                <Play className="h-5 w-5" />
                              </Link>
                            </Button>
                          </div>
                          <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded flex items-center">
                            <Clock className="h-3 w-3 mr-1" />
                            {video.duration}
                          </div>
                        </div>
                        <div className="flex justify-between items-start">
                          <Badge variant="outline">{video.category}</Badge>
                        </div>
                        <CardTitle className="mt-2 text-lg">{video.title}</CardTitle>
                        <CardDescription>{video.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="flex flex-wrap gap-2">
                          {video.tags.map((tag) => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between items-center">
                        <span className="text-xs text-muted-foreground">
                          {video.views.toLocaleString()} views • Added {video.createdAt}
                        </span>
                        <Button variant="ghost" size="sm" asChild>
                          <Link href={`/videos/${video.id}`}>
                            Watch Now
                            <ArrowRight className="ml-2 h-3 w-3" />
                          </Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
