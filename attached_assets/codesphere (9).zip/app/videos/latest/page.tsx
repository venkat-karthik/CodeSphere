"use client"
import { motion } from "framer-motion"
import { ArrowLeft, Play, Clock } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export default function LatestVideos() {
  const latestVideos = [
    {
      id: 1,
      title: "Next.js 14 App Router Deep Dive",
      description: "Explore the latest features in Next.js 14 App Router",
      category: "React",
      tags: ["nextjs", "app-router", "new"],
      duration: "42:18",
      views: 2340,
      thumbnail: "/placeholder.svg?height=180&width=320",
      createdAt: "2 days ago",
    },
    {
      id: 2,
      title: "TypeScript 5.3 New Features",
      description: "What's new in TypeScript 5.3 and how to use it",
      category: "TypeScript",
      tags: ["typescript", "new-features"],
      duration: "28:45",
      views: 1890,
      thumbnail: "/placeholder.svg?height=180&width=320",
      createdAt: "1 week ago",
    },
    {
      id: 3,
      title: "React Server Components Explained",
      description: "Understanding React Server Components and their benefits",
      category: "React",
      tags: ["react", "server-components"],
      duration: "35:22",
      views: 3210,
      thumbnail: "/placeholder.svg?height=180&width=320",
      createdAt: "1 week ago",
    },
  ]

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex items-center gap-4 mb-8">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/videos">
            <ArrowLeft className="h-5 w-5" />
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Latest Videos</h1>
          <p className="text-muted-foreground">The newest video content on CodeSphere</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {latestVideos.map((video, index) => (
          <motion.div
            key={video.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="h-full hover:bg-secondary/50 transition-colors">
              <CardHeader className="pb-3">
                <div className="relative rounded-lg overflow-hidden mb-3 aspect-video">
                  <img
                    src={video.thumbnail || "/placeholder.svg"}
                    alt={video.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <Button size="icon" variant="secondary" className="rounded-full" asChild>
                      <Link href={`/videos/${video.id}`}>
                        <Play className="h-5 w-5" />
                      </Link>
                    </Button>
                  </div>
                  <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded flex items-center">
                    <Clock className="h-3 w-3 mr-1" />
                    {video.duration}
                  </div>
                  <Badge className="absolute top-2 left-2 bg-red-500 text-white">NEW</Badge>
                </div>
                <div className="flex justify-between items-start">
                  <Badge variant="outline">{video.category}</Badge>
                </div>
                <CardTitle className="mt-2 text-lg">{video.title}</CardTitle>
                <CardDescription>{video.description}</CardDescription>
              </CardHeader>
              <CardContent className="pb-3">
                <div className="flex flex-wrap gap-2">
                  {video.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="flex justify-between items-center">
                <span className="text-xs text-muted-foreground">
                  {video.views.toLocaleString()} views • {video.createdAt}
                </span>
                <Button variant="ghost" size="sm" asChild>
                  <Link href={`/videos/${video.id}`}>Watch Now</Link>
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
