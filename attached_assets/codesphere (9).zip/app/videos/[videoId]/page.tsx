"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { motion } from "framer-motion"
import { ArrowLeft, MessageSquare, ThumbsUp, Share2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { VideoPlayer } from "@/components/video-player"
import { BookmarkButton } from "@/components/bookmark-button"
import { useToast } from "@/hooks/use-toast"

export default function VideoPage({ params }: { params: { videoId: string } }) {
  const router = useRouter()
  const { videoId } = params
  const { toast } = useToast()
  const [progress, setProgress] = useState(0)

  // Mock data - in a real app, fetch this from an API
  const video = {
    id: videoId,
    title: "JavaScript Crash Course for Beginners",
    description:
      "Learn JavaScript basics in this comprehensive crash course for beginners. We'll cover variables, functions, objects, arrays, and more.",
    category: "JavaScript",
    tags: ["beginner", "fundamentals", "javascript"],
    videoUrl: "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4", // Sample video URL
    thumbnailUrl: "/placeholder.svg?height=180&width=320",
    duration: "45:22",
    views: 12450,
    likes: 876,
    comments: 124,
    createdAt: "2 months ago",
    author: {
      name: "John Doe",
      avatar: "/placeholder.svg?height=40&width=40",
      role: "Instructor",
    },
  }

  // Related videos - in a real app, fetch this from an API
  const relatedVideos = [
    {
      id: "2",
      title: "JavaScript ES6 Features",
      description: "Learn about the modern features of JavaScript ES6",
      category: "JavaScript",
      duration: "32:15",
      views: 8765,
      thumbnailUrl: "/placeholder.svg?height=180&width=320",
      createdAt: "3 weeks ago",
    },
    {
      id: "3",
      title: "JavaScript DOM Manipulation",
      description: "Master DOM manipulation with JavaScript",
      category: "JavaScript",
      duration: "28:47",
      views: 6543,
      thumbnailUrl: "/placeholder.svg?height=180&width=320",
      createdAt: "1 month ago",
    },
    {
      id: "4",
      title: "JavaScript Async/Await",
      description: "Understanding asynchronous JavaScript",
      category: "JavaScript",
      duration: "35:18",
      views: 5432,
      thumbnailUrl: "/placeholder.svg?height=180&width=320",
      createdAt: "2 weeks ago",
    },
  ]

  const handleProgress = (newProgress: number) => {
    setProgress(newProgress)

    // In a real app, save progress to the server
    if (newProgress % 5 === 0) {
      // Save every 5%
      console.log("Saving progress:", newProgress)
      // API call to save progress
    }
  }

  const handleComplete = () => {
    toast({
      title: "Video completed!",
      description: "You've earned XP for completing this video.",
    })

    // In a real app, mark as complete and award XP via API call
    console.log("Video completed")
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex items-center mb-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()} className="mr-4">
          <ArrowLeft className="h-4 w-4" />
          <span className="sr-only">Back</span>
        </Button>
        <div>
          <p className="text-sm text-muted-foreground">
            <Link href="/videos" className="hover:underline">
              Videos
            </Link>{" "}
            / {video.category}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
            <VideoPlayer
              src={video.videoUrl}
              poster={video.thumbnailUrl}
              title={video.title}
              onProgress={handleProgress}
              onComplete={handleComplete}
              className="rounded-lg overflow-hidden w-full aspect-video"
            />

            <div className="mt-4">
              <h1 className="text-2xl font-bold">{video.title}</h1>
              <div className="flex flex-wrap items-center gap-2 mt-2 text-sm text-muted-foreground">
                <span>{video.views.toLocaleString()} views</span>
                <span>•</span>
                <span>{video.createdAt}</span>
                <span>•</span>
                <span>{video.duration}</span>
              </div>

              <div className="flex flex-wrap gap-2 mt-4">
                {video.tags.map((tag) => (
                  <Badge key={tag} variant="secondary">
                    {tag}
                  </Badge>
                ))}
              </div>

              <div className="flex flex-wrap justify-between items-center mt-4">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10 mr-3">
                    <AvatarImage src={video.author.avatar || "/placeholder.svg"} />
                    <AvatarFallback>{video.author.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{video.author.name}</p>
                    <p className="text-sm text-muted-foreground">{video.author.role}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 mt-4 sm:mt-0">
                  <Button variant="outline" size="sm">
                    <ThumbsUp className="h-4 w-4 mr-2" />
                    <span>{video.likes}</span>
                  </Button>
                  <Button variant="outline" size="sm">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    <span>{video.comments}</span>
                  </Button>
                  <BookmarkButton itemId={video.id} itemType="VIDEO" variant="outline" size="sm" showText />
                  <Button variant="outline" size="sm">
                    <Share2 className="h-4 w-4 mr-2" />
                    <span>Share</span>
                  </Button>
                </div>
              </div>

              <Separator className="my-6" />

              <div>
                <h2 className="text-xl font-semibold mb-2">Description</h2>
                <p className="text-muted-foreground whitespace-pre-line">{video.description}</p>
              </div>
            </div>
          </motion.div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Related Videos</CardTitle>
              <CardDescription>More videos you might like</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {relatedVideos.map((relatedVideo, index) => (
                <motion.div
                  key={relatedVideo.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  <Link href={`/videos/${relatedVideo.id}`} className="flex gap-3 group">
                    <div className="relative flex-shrink-0 w-24 h-16 rounded-md overflow-hidden">
                      <img
                        src={relatedVideo.thumbnailUrl || "/placeholder.svg"}
                        alt={relatedVideo.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute bottom-1 right-1 bg-black/70 text-white text-xs px-1 rounded">
                        {relatedVideo.duration}
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-sm font-medium line-clamp-2 group-hover:text-primary transition-colors">
                        {relatedVideo.title}
                      </h3>
                      <p className="text-xs text-muted-foreground mt-1">
                        {relatedVideo.views.toLocaleString()} views • {relatedVideo.createdAt}
                      </p>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" asChild>
                <Link href="/videos">View All Videos</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Your Progress</CardTitle>
              <CardDescription>Track your learning journey</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="w-full bg-secondary rounded-full h-2.5">
                  <div className="bg-primary h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
                </div>
                <p className="text-sm text-center">
                  {progress < 100 ? `${Math.round(progress)}% complete` : "Completed! 🎉"}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
