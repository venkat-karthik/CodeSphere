"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Search, MessageSquare, ThumbsUp, Eye, ArrowRight, Filter, Plus } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function Community() {
  const [searchQuery, setSearchQuery] = useState("")

  const categories = ["All", "Questions", "Discussions", "Projects", "Jobs", "Events"]

  const discussions = [
    {
      id: 1,
      title: "How to optimize React performance?",
      content:
        "I'm working on a large React application and noticing some performance issues. What are some best practices for optimizing React performance?",
      author: {
        name: "Jane Smith",
        avatar: "/placeholder.svg?height=40&width=40",
        username: "janesmith",
      },
      category: "Questions",
      tags: ["react", "performance", "optimization"],
      likes: 24,
      replies: 8,
      views: 156,
      createdAt: "2 days ago",
    },
    {
      id: 2,
      title: "Show off your portfolio website!",
      content:
        "Just finished my new portfolio site using Next.js and Tailwind. Would love to see what others have created and get some feedback on mine!",
      author: {
        name: "Alex Johnson",
        avatar: "/placeholder.svg?height=40&width=40",
        username: "alexj",
      },
      category: "Projects",
      tags: ["portfolio", "showcase", "feedback"],
      likes: 42,
      replies: 15,
      views: 230,
      createdAt: "1 week ago",
    },
    {
      id: 3,
      title: "TypeScript vs JavaScript - Is it worth switching?",
      content:
        "I've been using JavaScript for years but keep hearing about TypeScript. For those who've made the switch, what benefits have you seen?",
      author: {
        name: "Michael Brown",
        avatar: "/placeholder.svg?height=40&width=40",
        username: "mikebrown",
      },
      category: "Discussions",
      tags: ["typescript", "javascript", "debate"],
      likes: 56,
      replies: 32,
      views: 412,
      createdAt: "3 days ago",
    },
    {
      id: 4,
      title: "Frontend Developer position at our startup",
      content:
        "We're looking for a frontend developer with React experience to join our remote team. Competitive salary and flexible hours.",
      author: {
        name: "Sarah Wilson",
        avatar: "/placeholder.svg?height=40&width=40",
        username: "sarahw",
      },
      category: "Jobs",
      tags: ["job", "hiring", "remote"],
      likes: 18,
      replies: 7,
      views: 342,
      createdAt: "5 days ago",
    },
    {
      id: 5,
      title: "Virtual Hackathon next month - who's in?",
      content:
        "We're organizing a virtual hackathon focused on building accessibility tools. Great prizes and networking opportunities!",
      author: {
        name: "David Lee",
        avatar: "/placeholder.svg?height=40&width=40",
        username: "davidlee",
      },
      category: "Events",
      tags: ["hackathon", "event", "accessibility"],
      likes: 37,
      replies: 14,
      views: 289,
      createdAt: "1 day ago",
    },
    {
      id: 6,
      title: "Best resources for learning GraphQL?",
      content:
        "I want to learn GraphQL but there are so many resources out there. What books, courses, or tutorials would you recommend?",
      author: {
        name: "Emily Chen",
        avatar: "/placeholder.svg?height=40&width=40",
        username: "emilyc",
      },
      category: "Questions",
      tags: ["graphql", "learning", "resources"],
      likes: 29,
      replies: 12,
      views: 198,
      createdAt: "4 days ago",
    },
  ]

  const filteredDiscussions = discussions.filter(
    (discussion) =>
      discussion.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      discussion.content.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Community</h1>
          <p className="text-muted-foreground">
            Connect with other developers, ask questions, and share your knowledge
          </p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            New Post
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search discussions..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Select defaultValue="newest">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest First</SelectItem>
              <SelectItem value="popular">Most Popular</SelectItem>
              <SelectItem value="active">Most Active</SelectItem>
              <SelectItem value="unanswered">Unanswered</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-4">
          {categories.map((category) => (
            <TabsTrigger key={category} value={category === "All" ? "all" : category.toLowerCase()}>
              {category}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all">
          <div className="space-y-4">
            {filteredDiscussions.map((discussion, index) => (
              <motion.div
                key={discussion.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Card className="hover:bg-secondary/50 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={discussion.author.avatar || "/placeholder.svg"} />
                          <AvatarFallback>{discussion.author.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm font-medium">{discussion.author.name}</p>
                          <p className="text-xs text-muted-foreground">
                            @{discussion.author.username} • {discussion.createdAt}
                          </p>
                        </div>
                      </div>
                      <Badge variant="outline">{discussion.category}</Badge>
                    </div>
                    <CardTitle className="mt-2 text-lg hover:text-primary transition-colors">
                      <a href={`/community/post/${discussion.id}`}>{discussion.title}</a>
                    </CardTitle>
                    <CardDescription className="line-clamp-2">{discussion.content}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="flex flex-wrap gap-2">
                      {discussion.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between items-center">
                    <div className="flex gap-4">
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <ThumbsUp className="h-4 w-4" />
                        <span>{discussion.likes}</span>
                      </div>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <MessageSquare className="h-4 w-4" />
                        <span>{discussion.replies}</span>
                      </div>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Eye className="h-4 w-4" />
                        <span>{discussion.views}</span>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      View Discussion
                      <ArrowRight className="ml-2 h-3 w-3" />
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {categories.slice(1).map((category) => (
          <TabsContent key={category} value={category.toLowerCase()}>
            <div className="space-y-4">
              {filteredDiscussions
                .filter((discussion) => discussion.category === category)
                .map((discussion, index) => (
                  <motion.div
                    key={discussion.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="hover:bg-secondary/50 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarImage src={discussion.author.avatar || "/placeholder.svg"} />
                              <AvatarFallback>{discussion.author.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="text-sm font-medium">{discussion.author.name}</p>
                              <p className="text-xs text-muted-foreground">
                                @{discussion.author.username} • {discussion.createdAt}
                              </p>
                            </div>
                          </div>
                          <Badge variant="outline">{discussion.category}</Badge>
                        </div>
                        <CardTitle className="mt-2 text-lg hover:text-primary transition-colors">
                          <a href={`/community/post/${discussion.id}`}>{discussion.title}</a>
                        </CardTitle>
                        <CardDescription className="line-clamp-2">{discussion.content}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="flex flex-wrap gap-2">
                          {discussion.tags.map((tag) => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between items-center">
                        <div className="flex gap-4">
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            <ThumbsUp className="h-4 w-4" />
                            <span>{discussion.likes}</span>
                          </div>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            <MessageSquare className="h-4 w-4" />
                            <span>{discussion.replies}</span>
                          </div>
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            <Eye className="h-4 w-4" />
                            <span>{discussion.views}</span>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm">
                          View Discussion
                          <ArrowRight className="ml-2 h-3 w-3" />
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
