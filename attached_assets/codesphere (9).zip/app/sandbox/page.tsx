"use client"

import { Input } from "@/components/ui/input"

import { useState } from "react"
import { Play, Save, Code, Download, Upload, Copy, Trash, Layout, LayoutGrid, Maximize, Minimize } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { Separator } from "@/components/ui/separator"
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable"

export default function Sandbox() {
  const [code, setCode] = useState(`// Write your code here
import React, { useState } from 'react';

function App() {
  const [count, setCount] = useState(0);

  return (
    <div className="App">
      <h1>React Counter</h1>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>Increment</button>
      <button onClick={() => setCount(count - 1)}>Decrement</button>
    </div>
  );
}

export default App;`)
  const [output, setOutput] = useState("")
  const [isRunning, setIsRunning] = useState(false)
  const [layout, setLayout] = useState<"split" | "editor" | "preview">("split")
  const [template, setTemplate] = useState("react")
  const [isFullscreen, setIsFullscreen] = useState(false)
  const { toast } = useToast()

  const runCode = () => {
    setIsRunning(true)
    setOutput("")

    // Simulate code execution
    setTimeout(() => {
      setIsRunning(false)
      setOutput("App is running in the preview window")
      toast({
        title: "Code compiled successfully",
        description: "Your code is now running in the preview",
      })
    }, 1500)
  }

  const saveCode = () => {
    toast({
      title: "Code saved",
      description: "Your code has been saved successfully",
    })
  }

  const copyCode = () => {
    navigator.clipboard.writeText(code)
    toast({
      title: "Code copied",
      description: "Your code has been copied to clipboard",
    })
  }

  const clearCode = () => {
    setCode("")
    toast({
      title: "Code cleared",
      description: "Your code editor has been cleared",
    })
  }

  const downloadCode = () => {
    const blob = new Blob([code], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "sandbox-code.js"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast({
      title: "Code downloaded",
      description: "Your code has been downloaded as a file",
    })
  }

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen)
  }

  const templates = {
    react: `// React Template
import React, { useState } from 'react';

function App() {
  const [count, setCount] = useState(0);

  return (
    <div className="App">
      <h1>React Counter</h1>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>Increment</button>
      <button onClick={() => setCount(count - 1)}>Decrement</button>
    </div>
  );
}

export default App;`,
    vue: `// Vue Template
<template>
  <div class="app">
    <h1>Vue Counter</h1>
    <p>Count: {{ count }}</p>
    <button @click="increment">Increment</button>
    <button @click="decrement">Decrement</button>
  </div>
</template>

<script>
export default {
  data() {
    return {
      count: 0
    }
  },
  methods: {
    increment() {
      this.count++
    },
    decrement() {
      this.count--
    }
  }
}
</script>`,
    angular: `// Angular Template
import { Component } from '@angular/core';

@Component({
  selector: 'app-counter',
  template: \`
    <div class="app">
      <h1>Angular Counter</h1>
      <p>Count: {{ count }}</p>
      <button (click)="increment()">Increment</button>
      <button (click)="decrement()">Decrement</button>
    </div>
  \`
})
export class CounterComponent {
  count = 0;

  increment() {
    this.count++;
  }

  decrement() {
    this.count--;
  }
}`,
    html: `<!-- HTML Template -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HTML Counter</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      max-width: 500px;
      margin: 0 auto;
      padding: 20px;
    }
    button {
      margin-right: 10px;
    }
  </style>
</head>
<body>
  <h1>HTML Counter</h1>
  <p>Count: <span id="count">0</span></p>
  <button onclick="increment()">Increment</button>
  <button onclick="decrement()">Decrement</button>

  <script>
    let count = 0;
    const countElement = document.getElementById('count');

    function increment() {
      count++;
      countElement.textContent = count;
    }

    function decrement() {
      count--;
      countElement.textContent = count;
    }
  </script>
</body>
</html>`,
  }

  const handleTemplateChange = (value: string) => {
    setTemplate(value)
    setCode(templates[value as keyof typeof templates])
  }

  return (
    <div className={`container mx-auto py-8 px-4 ${isFullscreen ? "fixed inset-0 z-50 bg-background" : ""}`}>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Code Sandbox</h1>
          <p className="text-muted-foreground">Build and test your code in a safe environment</p>
        </div>
        <div className="mt-4 md:mt-0 flex items-center gap-2">
          <Select value={template} onValueChange={handleTemplateChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select template" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="react">React</SelectItem>
              <SelectItem value="vue">Vue</SelectItem>
              <SelectItem value="angular">Angular</SelectItem>
              <SelectItem value="html">HTML/CSS/JS</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon" onClick={toggleFullscreen}>
            {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      <div className="flex mb-4 gap-2">
        <Button variant={layout === "split" ? "default" : "outline"} size="sm" onClick={() => setLayout("split")}>
          <LayoutGrid className="mr-2 h-4 w-4" />
          Split
        </Button>
        <Button variant={layout === "editor" ? "default" : "outline"} size="sm" onClick={() => setLayout("editor")}>
          <Code className="mr-2 h-4 w-4" />
          Editor
        </Button>
        <Button variant={layout === "preview" ? "default" : "outline"} size="sm" onClick={() => setLayout("preview")}>
          <Layout className="mr-2 h-4 w-4" />
          Preview
        </Button>
        <Separator orientation="vertical" className="mx-2 h-8" />
        <Button variant="outline" size="sm" onClick={runCode} disabled={isRunning}>
          <Play className="mr-2 h-4 w-4" />
          {isRunning ? "Running..." : "Run"}
        </Button>
        <Button variant="outline" size="sm" onClick={saveCode}>
          <Save className="mr-2 h-4 w-4" />
          Save
        </Button>
        <Button variant="outline" size="sm" onClick={copyCode}>
          <Copy className="mr-2 h-4 w-4" />
          Copy
        </Button>
        <Button variant="outline" size="sm" onClick={downloadCode}>
          <Download className="mr-2 h-4 w-4" />
          Download
        </Button>
        <Button variant="outline" size="sm" onClick={clearCode}>
          <Trash className="mr-2 h-4 w-4" />
          Clear
        </Button>
      </div>

      <ResizablePanelGroup direction="horizontal" className="min-h-[600px] rounded-lg border">
        {layout !== "preview" && (
          <ResizablePanel defaultSize={layout === "split" ? 50 : 100}>
            <div className="h-full p-4">
              <Tabs defaultValue="code">
                <TabsList>
                  <TabsTrigger value="code">Code</TabsTrigger>
                  <TabsTrigger value="assets">Assets</TabsTrigger>
                  <TabsTrigger value="packages">Packages</TabsTrigger>
                </TabsList>
                <TabsContent value="code" className="h-full">
                  <div className="relative h-[calc(100%-40px)] rounded-md border mt-4">
                    <textarea
                      className="absolute inset-0 font-mono p-4 resize-none w-full h-full bg-secondary/50 focus:outline-none"
                      value={code}
                      onChange={(e) => setCode(e.target.value)}
                    />
                  </div>
                </TabsContent>
                <TabsContent value="assets">
                  <div className="p-4 h-[calc(100%-40px)] flex flex-col items-center justify-center border rounded-md mt-4">
                    <Upload className="h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-center text-muted-foreground">Drag and drop files here or click to upload</p>
                    <Button variant="outline" className="mt-4">
                      Upload Assets
                    </Button>
                  </div>
                </TabsContent>
                <TabsContent value="packages">
                  <div className="p-4 h-[calc(100%-40px)] border rounded-md mt-4">
                    <div className="flex mb-4">
                      <Input placeholder="Search packages..." className="mr-2" />
                      <Button>Add</Button>
                    </div>
                    <div className="space-y-2">
                      <div className="p-2 border rounded-md flex justify-between items-center">
                        <div>
                          <p className="font-medium">react</p>
                          <p className="text-xs text-muted-foreground">^18.2.0</p>
                        </div>
                        <Button variant="outline" size="sm">
                          Remove
                        </Button>
                      </div>
                      <div className="p-2 border rounded-md flex justify-between items-center">
                        <div>
                          <p className="font-medium">react-dom</p>
                          <p className="text-xs text-muted-foreground">^18.2.0</p>
                        </div>
                        <Button variant="outline" size="sm">
                          Remove
                        </Button>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </ResizablePanel>
        )}

        {layout === "split" && <ResizableHandle />}

        {layout !== "editor" && (
          <ResizablePanel defaultSize={layout === "split" ? 50 : 100}>
            <div className="h-full p-4">
              <Tabs defaultValue="preview">
                <TabsList>
                  <TabsTrigger value="preview">Preview</TabsTrigger>
                  <TabsTrigger value="console">Console</TabsTrigger>
                </TabsList>
                <TabsContent value="preview" className="h-full">
                  <div className="h-[calc(100%-40px)] rounded-md border mt-4 bg-white">
                    {isRunning ? (
                      <div className="flex items-center justify-center h-full">
                        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
                      </div>
                    ) : (
                      <iframe
                        title="preview"
                        className="w-full h-full rounded-md"
                        sandbox="allow-scripts"
                        srcDoc={`
                          <html>
                            <head>
                              <style>
                                body {
                                  font-family: Arial, sans-serif;
                                  max-width: 800px;
                                  margin: 0 auto;
                                  padding: 20px;
                                }
                              </style>
                            </head>
                            <body>
                              <div id="root"></div>
                              <script>
                                // This would be replaced with actual rendering in a real sandbox
                                document.getElementById('root').innerHTML = '<div class="App"><h1>React Counter</h1><p>Count: 0</p><button>Increment</button><button>Decrement</button></div>';
                              </script>
                            </body>
                          </html>
                        `}
                      />
                    )}
                  </div>
                </TabsContent>
                <TabsContent value="console" className="h-full">
                  <div className="h-[calc(100%-40px)] rounded-md border mt-4 bg-black text-white p-4 font-mono overflow-auto">
                    {output ? (
                      <pre>{output}</pre>
                    ) : (
                      <div className="text-gray-500 h-full flex items-center justify-center">
                        Console output will appear here
                      </div>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </ResizablePanel>
        )}
      </ResizablePanelGroup>

      <div className="mt-8">
        <h2 className="text-2xl font-bold tracking-tight mb-4">Tutorials</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Build a Todo App</CardTitle>
              <CardDescription>Learn to build a simple todo app with React</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="aspect-video rounded-md bg-muted mb-4"></div>
              <p className="text-sm text-muted-foreground">
                This tutorial walks you through creating a todo application with React hooks and state management.
              </p>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Start Tutorial</Button>
            </CardFooter>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Weather Dashboard</CardTitle>
              <CardDescription>Create a weather app with API integration</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="aspect-video rounded-md bg-muted mb-4"></div>
              <p className="text-sm text-muted-foreground">
                Learn how to fetch data from a weather API and display it in a beautiful dashboard.
              </p>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Start Tutorial</Button>
            </CardFooter>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Chat Application</CardTitle>
              <CardDescription>Build a real-time chat app with WebSockets</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="aspect-video rounded-md bg-muted mb-4"></div>
              <p className="text-sm text-muted-foreground">
                Create a real-time chat application using WebSockets and modern JavaScript.
              </p>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Start Tutorial</Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
