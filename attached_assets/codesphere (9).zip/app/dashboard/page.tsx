"use client"

import { CardFooter } from "@/components/ui/card"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { motion } from "framer-motion"
import {
  BookOpen,
  FileText,
  Video,
  Map,
  Bot,
  Users,
  ArrowRight,
  Calendar,
  Clock,
  Trophy,
  Eye,
  UserPlus,
  Code,
  FileCode,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/login")
    } else {
      setUser(JSON.parse(userData))
    }
  }, [router])

  const handleSignOut = () => {
    localStorage.removeItem("user")
    router.push("/")
  }

  const featuredCourses = [
    {
      id: 1,
      title: "React Fundamentals",
      description: "Learn the basics of React including components, props, and state",
      progress: 65,
      category: "Frontend",
      image: "/placeholder.svg?height=150&width=300",
    },
    {
      id: 2,
      title: "JavaScript Advanced Concepts",
      description: "Deep dive into closures, prototypes, and asynchronous JavaScript",
      progress: 32,
      category: "JavaScript",
      image: "/placeholder.svg?height=150&width=300",
    },
    {
      id: 3,
      title: "Node.js API Development",
      description: "Build robust APIs with Node.js, Express, and MongoDB",
      progress: 18,
      category: "Backend",
      image: "/placeholder.svg?height=150&width=300",
    },
  ]

  const upcomingEvents = [
    {
      id: 1,
      title: "Live Coding Session: Building a Chat App",
      date: "2023-07-15T18:00:00",
      host: "Alex Johnson",
      attendees: 42,
    },
    {
      id: 2,
      title: "Workshop: Mastering CSS Grid",
      date: "2023-07-18T15:30:00",
      host: "Sarah Miller",
      attendees: 28,
    },
  ]

  const recentActivity = [
    {
      id: 1,
      type: "course",
      title: "Completed lesson: React Hooks Introduction",
      time: "2 hours ago",
      icon: BookOpen,
    },
    {
      id: 2,
      type: "note",
      title: "Created note: JavaScript Promises",
      time: "Yesterday",
      icon: FileText,
    },
    {
      id: 3,
      type: "video",
      title: "Watched: Advanced TypeScript Techniques",
      time: "2 days ago",
      icon: Video,
    },
    {
      id: 4,
      type: "challenge",
      title: "Solved: Array Manipulation Challenge",
      time: "3 days ago",
      icon: Code,
    },
  ]

  const recommendedContent = [
    {
      id: 1,
      type: "video",
      title: "Understanding React Context API",
      description: "Learn how to use Context API for state management",
      duration: "32 min",
      icon: Video,
    },
    {
      id: 2,
      type: "note",
      title: "CSS Flexbox Cheatsheet",
      description: "Quick reference guide for CSS Flexbox properties",
      author: "David Chen",
      icon: FileText,
    },
    {
      id: 3,
      type: "roadmap",
      title: "Full-Stack Developer Path",
      description: "Comprehensive roadmap to becoming a full-stack developer",
      steps: 24,
      icon: Map,
    },
  ]

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
    })
  }

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/20 p-4">
      <div className="container mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Welcome back, {user.name}!</h1>
          <Button onClick={handleSignOut} variant="outline">
            Sign Out
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Learning Progress</CardTitle>
              <CardDescription>Your coding journey so far</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">75%</p>
              <p className="text-sm text-muted-foreground">JavaScript Fundamentals</p>
              <Progress value={75} className="mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Streak</CardTitle>
              <CardDescription>Days of continuous learning</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">7 days</p>
              <p className="text-sm text-muted-foreground">Keep it up!</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>XP Points</CardTitle>
              <CardDescription>Experience points earned</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">1,250 XP</p>
              <p className="text-sm text-muted-foreground">Level 5</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Quick Access</CardTitle>
              <CardDescription>Frequently used features</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" className="w-full justify-start" asChild>
                <Link href="/notes">
                  <BookOpen className="mr-2 h-4 w-4" />
                  Notes
                </Link>
              </Button>
              <Button variant="outline" className="w-full justify-start" asChild>
                <Link href="/videos">
                  <Video className="mr-2 h-4 w-4" />
                  Videos
                </Link>
              </Button>
              <Button variant="outline" className="w-full justify-start" asChild>
                <Link href="/challenges">
                  <Code className="mr-2 h-4 w-4" />
                  Coding Challenges
                </Link>
              </Button>
              <Button variant="outline" className="w-full justify-start" asChild>
                <Link href="/community">
                  <Users className="mr-2 h-4 w-4" />
                  Community
                </Link>
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Your latest learning activities</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="rounded-md p-2 bg-primary/10 text-primary">
                  <BookOpen className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm">Completed lesson: React Hooks Introduction</p>
                  <p className="text-xs text-muted-foreground">2 hours ago</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="rounded-md p-2 bg-primary/10 text-primary">
                  <Video className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm">Watched: Advanced TypeScript Techniques</p>
                  <p className="text-xs text-muted-foreground">Yesterday</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="rounded-md p-2 bg-primary/10 text-primary">
                  <Code className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm">Solved: Array Manipulation Challenge</p>
                  <p className="text-xs text-muted-foreground">2 days ago</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Achievements</CardTitle>
              <CardDescription>Your recent accomplishments</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="rounded-lg p-2 text-amber-500 bg-amber-500/10">
                  <Trophy className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-medium">React Rookie</p>
                  <p className="text-xs text-muted-foreground">Completed your first React component</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="rounded-lg p-2 text-blue-500 bg-blue-500/10">
                  <Calendar className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-medium">Consistent Learner</p>
                  <p className="text-xs text-muted-foreground">Maintained a 7-day learning streak</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="rounded-lg p-2 text-green-500 bg-green-500/10">
                  <Code className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-medium">Quiz Master</p>
                  <p className="text-xs text-muted-foreground">Scored 100% on JavaScript quiz</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" className="w-full">
                View All Achievements
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground">Here's an overview of your learning journey</p>
          </div>
          <div className="mt-4 md:mt-0 flex gap-2">
            <Button variant="outline">
              <Calendar className="mr-2 h-4 w-4" />
              My Schedule
            </Button>
            <Button>
              Continue Learning
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="courses">My Courses</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Learning Progress</CardTitle>
                <CardDescription>Your current learning status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>React Fundamentals</span>
                      <span>65%</span>
                    </div>
                    <Progress value={65} className="h-2" />
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <p className="text-2xl font-bold">7</p>
                      <p className="text-sm text-muted-foreground">Day Streak</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold">4,250</p>
                      <p className="text-sm text-muted-foreground">Total XP</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-medium">Recent Achievements</h4>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-sm">
                        <Trophy className="h-4 w-4 text-amber-500" />
                        <span>React Rookie</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar className="h-4 w-4 text-blue-500" />
                        <span>Consistent Learner</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Continue Learning</CardTitle>
                  <CardDescription>Pick up where you left off</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {featuredCourses.slice(0, 1).map((course) => (
                    <div key={course.id} className="space-y-2">
                      <div className="relative rounded-lg overflow-hidden aspect-video">
                        <img
                          src={course.image || "/placeholder.svg"}
                          alt={course.title}
                          className="object-cover w-full h-full"
                        />
                        <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                          <Button variant="secondary" size="sm">
                            Continue
                          </Button>
                        </div>
                        <Badge className="absolute top-2 right-2">{course.category}</Badge>
                      </div>
                      <h3 className="font-medium">{course.title}</h3>
                      <div className="flex justify-between text-xs text-muted-foreground mb-1">
                        <span>Progress</span>
                        <span>{course.progress}%</span>
                      </div>
                      <Progress value={course.progress} className="h-1" />
                    </div>
                  ))}
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" className="w-full" asChild>
                    <Link href="/courses">
                      View All Courses
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Upcoming Events</CardTitle>
                  <CardDescription>Live sessions and workshops</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {upcomingEvents.map((event) => (
                    <div key={event.id} className="p-3 rounded-lg border">
                      <h3 className="font-medium">{event.title}</h3>
                      <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4" />
                        <span>{formatDate(event.date)}</span>
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                        <Users className="h-4 w-4" />
                        <span>
                          Hosted by {event.host} • {event.attendees} attending
                        </span>
                      </div>
                      <Button variant="outline" size="sm" className="mt-2 w-full">
                        Add to Calendar
                      </Button>
                    </div>
                  ))}
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" className="w-full">
                    View All Events
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Your latest learning activities</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {recentActivity.map((activity) => (
                    <div key={activity.id} className="flex items-start gap-3">
                      <div className="rounded-md p-2 bg-primary/10 text-primary">
                        <activity.icon className="h-4 w-4" />
                      </div>
                      <div>
                        <p className="text-sm">{activity.title}</p>
                        <p className="text-xs text-muted-foreground">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" className="w-full" onClick={() => setActiveTab("activity")}>
                    View All Activity
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold tracking-tight">Recommended for You</h2>
                <Button variant="ghost" size="sm">
                  View All
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {recommendedContent.map((content) => (
                  <Card key={content.id} className="hover:bg-secondary/50 transition-colors">
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-start">
                        <div className="rounded-lg p-2 bg-primary/10 text-primary">
                          <content.icon className="h-4 w-4" />
                        </div>
                        <Badge variant="outline">{content.type.charAt(0).toUpperCase() + content.type.slice(1)}</Badge>
                      </div>
                      <CardTitle className="mt-2">{content.title}</CardTitle>
                      <CardDescription>{content.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="pb-3">
                      {"duration" in content && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="h-4 w-4" />
                          <span>{content.duration}</span>
                        </div>
                      )}
                      {"author" in content && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Users className="h-4 w-4" />
                          <span>By {content.author}</span>
                        </div>
                      )}
                      {"steps" in content && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Map className="h-4 w-4" />
                          <span>{content.steps} steps</span>
                        </div>
                      )}
                    </CardContent>
                    <CardFooter>
                      <Button variant="ghost" size="sm" className="w-full">
                        {content.type === "video" ? "Watch Now" : content.type === "note" ? "Read Now" : "View Roadmap"}
                        <ArrowRight className="ml-2 h-3 w-3" />
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Community Highlights</CardTitle>
                  <CardDescription>Recent discussions and popular topics</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-4">
                    <div className="p-4 rounded-lg border">
                      <div className="flex items-start gap-3">
                        <Avatar>
                          <AvatarImage src="/placeholder.svg?height=40&width=40" alt="User" />
                          <AvatarFallback>U1</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">David Chen</span>
                            <Badge variant="outline">Jonin</Badge>
                          </div>
                          <p className="text-sm mt-1">
                            Just published a new article on React performance optimization techniques. Check it out!
                          </p>
                          <div className="flex items-center gap-4 mt-2">
                            <Button variant="outline" size="sm">
                              View Article
                            </Button>
                            <span className="text-xs text-muted-foreground">Posted 3 hours ago</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 rounded-lg border">
                      <div className="flex items-start gap-3">
                        <Avatar>
                          <AvatarImage src="/placeholder.svg?height=40&width=40" alt="User" />
                          <AvatarFallback>U2</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">Sarah Miller</span>
                            <Badge variant="outline">Chunin</Badge>
                          </div>
                          <p className="text-sm mt-1">
                            Looking for study partners for the upcoming JavaScript algorithms challenge. Anyone
                            interested?
                          </p>
                          <div className="flex items-center gap-4 mt-2">
                            <Button variant="outline" size="sm">
                              Join Discussion
                            </Button>
                            <span className="text-xs text-muted-foreground">Posted yesterday</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" className="w-full" asChild>
                    <Link href="/community">
                      Visit Community
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Quick Access</CardTitle>
                  <CardDescription>Frequently used features</CardDescription>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href="/ai-mentor">
                      <Bot className="mr-2 h-4 w-4" />
                      AI Mentor
                    </Link>
                  </Button>
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href="/spectate">
                      <Eye className="mr-2 h-4 w-4" />
                      Spectate Pro Coders
                    </Link>
                  </Button>
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href="/code-buddy">
                      <UserPlus className="mr-2 h-4 w-4" />
                      Find Code Buddy
                    </Link>
                  </Button>
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href="/challenges">
                      <Code className="mr-2 h-4 w-4" />
                      Coding Challenges
                    </Link>
                  </Button>
                  <Button variant="outline" className="w-full justify-start" asChild>
                    <Link href="/problems">
                      <FileCode className="mr-2 h-4 w-4" />
                      Problem Statements
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="courses">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold tracking-tight">My Courses</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {featuredCourses.map((course) => (
                  <motion.div
                    key={course.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card className="h-full hover:bg-secondary/50 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="relative rounded-lg overflow-hidden aspect-video mb-3">
                          <img
                            src={course.image || "/placeholder.svg"}
                            alt={course.title}
                            className="object-cover w-full h-full"
                          />
                          <Badge className="absolute top-2 right-2">{course.category}</Badge>
                        </div>
                        <CardTitle>{course.title}</CardTitle>
                        <CardDescription>{course.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="flex justify-between text-xs text-muted-foreground mb-1">
                          <span>Progress</span>
                          <span>{course.progress}%</span>
                        </div>
                        <Progress value={course.progress} className="h-1" />
                      </CardContent>
                      <CardFooter>
                        <Button className="w-full">Continue Learning</Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="activity">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold tracking-tight">Activity History</h2>
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <motion.div
                    key={activity.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className="rounded-md p-2 bg-primary/10 text-primary">
                            <activity.icon className="h-4 w-4" />
                          </div>
                          <div className="flex-1">
                            <p>{activity.title}</p>
                            <p className="text-sm text-muted-foreground">{activity.time}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="achievements">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold tracking-tight">Your Achievements</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  {
                    id: 1,
                    title: "React Rookie",
                    description: "Completed your first React component",
                    date: "2023-07-10",
                    icon: Trophy,
                    color: "text-amber-500",
                  },
                  {
                    id: 2,
                    title: "Consistent Learner",
                    description: "Maintained a 7-day learning streak",
                    date: "2023-07-12",
                    icon: Calendar,
                    color: "text-blue-500",
                  },
                  {
                    id: 3,
                    title: "Quiz Master",
                    description: "Scored 100% on JavaScript Fundamentals quiz",
                    date: "2023-07-08",
                    icon: Code,
                    color: "text-green-500",
                  },
                  {
                    id: 4,
                    title: "Code Contributor",
                    description: "Shared your first code snippet with the community",
                    date: "2023-07-05",
                    icon: Users,
                    color: "text-purple-500",
                  },
                  {
                    id: 5,
                    title: "Fast Learner",
                    description: "Completed 3 courses in the first month",
                    date: "2023-06-30",
                    icon: Clock,
                    color: "text-orange-500",
                  },
                  {
                    id: 6,
                    title: "Problem Solver",
                    description: "Solved 10 coding challenges",
                    date: "2023-06-25",
                    icon: FileCode,
                    color: "text-red-500",
                  },
                ].map((achievement) => (
                  <motion.div
                    key={achievement.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card className="h-full hover:bg-secondary/50 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div className={`rounded-lg p-2 ${achievement.color} bg-opacity-10`}>
                            <achievement.icon className={`h-5 w-5 ${achievement.color}`} />
                          </div>
                          <Badge variant="outline">{formatDate(achievement.date).split(",")[0]}</Badge>
                        </div>
                        <CardTitle className="mt-2">{achievement.title}</CardTitle>
                        <CardDescription>{achievement.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Trophy className="h-4 w-4" />
                          <span>+50 XP</span>
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button variant="ghost" size="sm" className="w-full">
                          Share Achievement
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
