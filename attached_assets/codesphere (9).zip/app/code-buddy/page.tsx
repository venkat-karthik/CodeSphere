"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  Search,
  Filter,
  ArrowRight,
  MessageSquare,
  UserPlus,
  Star,
  BookOpen,
  Clock,
  Calendar,
  CheckCircle,
  XCircle,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"

export default function CodeBuddy() {
  const [searchQuery, setSearchQuery] = useState("")
  const { toast } = useToast()

  const categories = ["All", "React", "JavaScript", "Python", "Node.js", "CSS", "TypeScript"]

  const buddies = [
    {
      id: 1,
      name: "Sarah Johnson",
      username: "sarahj",
      avatar: "/placeholder.svg?height=40&width=40",
      rank: "Chunin",
      xp: 4250,
      course: "React Fundamentals",
      progress: 65,
      interests: ["Frontend", "UI/UX", "React"],
      availability: "Evenings & Weekends",
      timezone: "GMT-5",
      bio: "Frontend developer passionate about creating beautiful user interfaces. Currently learning React and TypeScript.",
      compatibility: 92,
    },
    {
      id: 2,
      name: "David Chen",
      username: "dchen",
      avatar: "/placeholder.svg?height=40&width=40",
      rank: "Jonin",
      xp: 7850,
      course: "Advanced JavaScript",
      progress: 78,
      interests: ["JavaScript", "Node.js", "Algorithms"],
      availability: "Weekdays",
      timezone: "GMT+8",
      bio: "Full-stack developer with 3 years of experience. Love solving complex problems and mentoring beginners.",
      compatibility: 85,
    },
    {
      id: 3,
      name: "Emily Rodriguez",
      username: "emilyr",
      avatar: "/placeholder.svg?height=40&width=40",
      rank: "Genin",
      xp: 2150,
      course: "Python for Data Science",
      progress: 42,
      interests: ["Python", "Data Science", "Machine Learning"],
      availability: "Flexible",
      timezone: "GMT-7",
      bio: "Data scientist in training. Looking for study partners to practice Python and work on data projects together.",
      compatibility: 78,
    },
    {
      id: 4,
      name: "Michael Park",
      username: "mpark",
      avatar: "/placeholder.svg?height=40&width=40",
      rank: "ANBU",
      xp: 9950,
      course: "Full-Stack Web Development",
      progress: 85,
      interests: ["React", "Node.js", "MongoDB", "Express"],
      availability: "Evenings",
      timezone: "GMT+1",
      bio: "Experienced web developer specializing in the MERN stack. Happy to help others learn and grow.",
      compatibility: 88,
    },
    {
      id: 5,
      name: "Jessica Lee",
      username: "jlee",
      avatar: "/placeholder.svg?height=40&width=40",
      rank: "Chunin",
      xp: 5430,
      course: "CSS Mastery",
      progress: 92,
      interests: ["CSS", "Design", "Animation", "Responsive Design"],
      availability: "Weekends",
      timezone: "GMT+9",
      bio: "UI designer and frontend developer with a passion for creating beautiful, responsive websites.",
      compatibility: 75,
    },
    {
      id: 6,
      name: "Robert Kim",
      username: "rkim",
      avatar: "/placeholder.svg?height=40&width=40",
      rank: "Rookie Ninja",
      xp: 1250,
      course: "JavaScript Basics",
      progress: 35,
      interests: ["JavaScript", "Web Development", "Frontend"],
      availability: "Evenings & Weekends",
      timezone: "GMT-8",
      bio: "New to coding and excited to learn! Looking for study partners to practice JavaScript together.",
      compatibility: 82,
    },
  ]

  const filteredBuddies = buddies.filter(
    (buddy) =>
      buddy.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      buddy.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      buddy.course.toLowerCase().includes(searchQuery.toLowerCase()) ||
      buddy.interests.some((interest) => interest.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  const sendBuddyRequest = (buddyId: number) => {
    toast({
      title: "Buddy request sent",
      description: "Your request has been sent. You'll be notified when they respond.",
    })
  }

  const getCompatibilityColor = (compatibility: number) => {
    if (compatibility >= 90) return "text-green-500"
    if (compatibility >= 80) return "text-blue-500"
    if (compatibility >= 70) return "text-yellow-500"
    return "text-orange-500"
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Code Buddy System</h1>
          <p className="text-muted-foreground">Find study partners and learn together</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button>
            Your Buddy Requests
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>Your Learning Profile</CardTitle>
            <CardDescription>Manage your preferences to find better matches</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Current Course</h3>
              <Select defaultValue="react">
                <SelectTrigger>
                  <SelectValue placeholder="Select a course" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="react">React Fundamentals</SelectItem>
                  <SelectItem value="javascript">Advanced JavaScript</SelectItem>
                  <SelectItem value="python">Python for Data Science</SelectItem>
                  <SelectItem value="fullstack">Full-Stack Web Development</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">Your Interests</h3>
              <div className="flex flex-wrap gap-2">
                <Badge>React</Badge>
                <Badge>JavaScript</Badge>
                <Badge>Web Development</Badge>
                <Badge variant="outline">+ Add</Badge>
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">Availability</h3>
              <Select defaultValue="evenings">
                <SelectTrigger>
                  <SelectValue placeholder="Select availability" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="evenings">Evenings</SelectItem>
                  <SelectItem value="weekends">Weekends</SelectItem>
                  <SelectItem value="evenings-weekends">Evenings & Weekends</SelectItem>
                  <SelectItem value="weekdays">Weekdays</SelectItem>
                  <SelectItem value="flexible">Flexible</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">Timezone</h3>
              <Select defaultValue="gmt-5">
                <SelectTrigger>
                  <SelectValue placeholder="Select timezone" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gmt-8">GMT-8 (Pacific Time)</SelectItem>
                  <SelectItem value="gmt-5">GMT-5 (Eastern Time)</SelectItem>
                  <SelectItem value="gmt+0">GMT+0 (UTC)</SelectItem>
                  <SelectItem value="gmt+1">GMT+1 (Central European Time)</SelectItem>
                  <SelectItem value="gmt+8">GMT+8 (China Standard Time)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">Learning Goals</h3>
              <Input placeholder="What do you want to achieve?" />
            </div>

            <Button className="w-full">Update Profile</Button>
          </CardContent>
        </Card>

        <div className="md:col-span-2 space-y-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search for buddies..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Select defaultValue="compatibility">
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="compatibility">Highest Compatibility</SelectItem>
                  <SelectItem value="progress">Similar Progress</SelectItem>
                  <SelectItem value="rank">Rank</SelectItem>
                  <SelectItem value="availability">Availability</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <Tabs defaultValue="all">
            <TabsList className="mb-4">
              {categories.map((category) => (
                <TabsTrigger key={category} value={category === "All" ? "all" : category.toLowerCase()}>
                  {category}
                </TabsTrigger>
              ))}
            </TabsList>

            <TabsContent value="all">
              <div className="space-y-4">
                {filteredBuddies.map((buddy, index) => (
                  <motion.div
                    key={buddy.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card>
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-12 w-12">
                              <AvatarImage src={buddy.avatar || "/placeholder.svg"} alt={buddy.name} />
                              <AvatarFallback>{buddy.name[0]}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-medium">{buddy.name}</span>
                                <Badge variant="outline">{buddy.rank}</Badge>
                              </div>
                              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                <span>@{buddy.username}</span>
                                <span>•</span>
                                <span>{buddy.xp.toLocaleString()} XP</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex flex-col items-end">
                            <Badge
                              variant="outline"
                              className={`flex items-center gap-1 ${getCompatibilityColor(buddy.compatibility)}`}
                            >
                              <CheckCircle className="h-3 w-3" />
                              {buddy.compatibility}% Match
                            </Badge>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                          <div className="space-y-2">
                            <h3 className="text-sm font-medium flex items-center gap-2">
                              <BookOpen className="h-4 w-4 text-primary" />
                              Current Course
                            </h3>
                            <div className="flex flex-col">
                              <span className="text-sm">{buddy.course}</span>
                              <div className="flex justify-between text-xs text-muted-foreground mb-1">
                                <span>Progress</span>
                                <span>{buddy.progress}%</span>
                              </div>
                              <Progress value={buddy.progress} className="h-1" />
                            </div>
                          </div>
                          <div className="space-y-2">
                            <h3 className="text-sm font-medium flex items-center gap-2">
                              <Star className="h-4 w-4 text-primary" />
                              Interests
                            </h3>
                            <div className="flex flex-wrap gap-1">
                              {buddy.interests.map((interest) => (
                                <Badge key={interest} variant="secondary" className="text-xs">
                                  {interest}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                          <div className="space-y-1">
                            <h3 className="text-sm font-medium flex items-center gap-2">
                              <Clock className="h-4 w-4 text-primary" />
                              Availability
                            </h3>
                            <span className="text-sm">{buddy.availability}</span>
                          </div>
                          <div className="space-y-1">
                            <h3 className="text-sm font-medium flex items-center gap-2">
                              <Calendar className="h-4 w-4 text-primary" />
                              Timezone
                            </h3>
                            <span className="text-sm">{buddy.timezone}</span>
                          </div>
                        </div>
                        <p className="text-sm">{buddy.bio}</p>
                      </CardContent>
                      <CardFooter className="flex justify-between">
                        <Button variant="outline" size="sm" className="flex items-center gap-1">
                          <MessageSquare className="h-4 w-4" />
                          <span>Message</span>
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => sendBuddyRequest(buddy.id)}
                          className="flex items-center gap-1"
                        >
                          <UserPlus className="h-4 w-4" />
                          <span>Send Buddy Request</span>
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            {categories.slice(1).map((category) => (
              <TabsContent key={category} value={category.toLowerCase()}>
                <div className="space-y-4">
                  {filteredBuddies
                    .filter((buddy) => buddy.interests.includes(category))
                    .map((buddy, index) => (
                      <motion.div
                        key={buddy.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.05 }}
                      >
                        <Card>
                          <CardHeader className="pb-3">
                            <div className="flex justify-between items-start">
                              <div className="flex items-center gap-3">
                                <Avatar className="h-12 w-12">
                                  <AvatarImage src={buddy.avatar || "/placeholder.svg"} alt={buddy.name} />
                                  <AvatarFallback>{buddy.name[0]}</AvatarFallback>
                                </Avatar>
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-medium">{buddy.name}</span>
                                    <Badge variant="outline">{buddy.rank}</Badge>
                                  </div>
                                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                    <span>@{buddy.username}</span>
                                    <span>•</span>
                                    <span>{buddy.xp.toLocaleString()} XP</span>
                                  </div>
                                </div>
                              </div>
                              <div className="flex flex-col items-end">
                                <Badge
                                  variant="outline"
                                  className={`flex items-center gap-1 ${getCompatibilityColor(buddy.compatibility)}`}
                                >
                                  <CheckCircle className="h-3 w-3" />
                                  {buddy.compatibility}% Match
                                </Badge>
                              </div>
                            </div>
                          </CardHeader>
                          <CardContent className="pb-3">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                              <div className="space-y-2">
                                <h3 className="text-sm font-medium flex items-center gap-2">
                                  <BookOpen className="h-4 w-4 text-primary" />
                                  Current Course
                                </h3>
                                <div className="flex flex-col">
                                  <span className="text-sm">{buddy.course}</span>
                                  <div className="flex justify-between text-xs text-muted-foreground mb-1">
                                    <span>Progress</span>
                                    <span>{buddy.progress}%</span>
                                  </div>
                                  <Progress value={buddy.progress} className="h-1" />
                                </div>
                              </div>
                              <div className="space-y-2">
                                <h3 className="text-sm font-medium flex items-center gap-2">
                                  <Star className="h-4 w-4 text-primary" />
                                  Interests
                                </h3>
                                <div className="flex flex-wrap gap-1">
                                  {buddy.interests.map((interest) => (
                                    <Badge key={interest} variant="secondary" className="text-xs">
                                      {interest}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                              <div className="space-y-1">
                                <h3 className="text-sm font-medium flex items-center gap-2">
                                  <Clock className="h-4 w-4 text-primary" />
                                  Availability
                                </h3>
                                <span className="text-sm">{buddy.availability}</span>
                              </div>
                              <div className="space-y-1">
                                <h3 className="text-sm font-medium flex items-center gap-2">
                                  <Calendar className="h-4 w-4 text-primary" />
                                  Timezone
                                </h3>
                                <span className="text-sm">{buddy.timezone}</span>
                              </div>
                            </div>
                            <p className="text-sm">{buddy.bio}</p>
                          </CardContent>
                          <CardFooter className="flex justify-between">
                            <Button variant="outline" size="sm" className="flex items-center gap-1">
                              <MessageSquare className="h-4 w-4" />
                              <span>Message</span>
                            </Button>
                            <Button
                              size="sm"
                              onClick={() => sendBuddyRequest(buddy.id)}
                              className="flex items-center gap-1"
                            >
                              <UserPlus className="h-4 w-4" />
                              <span>Send Buddy Request</span>
                            </Button>
                          </CardFooter>
                        </Card>
                      </motion.div>
                    ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </div>

      <div className="mt-8">
        <h2 className="text-2xl font-bold tracking-tight mb-4">Your Buddy Network</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Active Buddies</CardTitle>
              <CardDescription>People you're currently studying with</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/placeholder.svg?height=32&width=32" alt="John Doe" />
                    <AvatarFallback>JD</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">John Doe</p>
                    <p className="text-xs text-muted-foreground">React Fundamentals</p>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  <MessageSquare className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Jane Smith" />
                    <AvatarFallback>JS</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">Jane Smith</p>
                    <p className="text-xs text-muted-foreground">JavaScript Basics</p>
                  </div>
                </div>
                <Button variant="outline" size="sm">
                  <MessageSquare className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" className="w-full">
                View All Buddies
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Pending Requests</CardTitle>
              <CardDescription>Buddy requests awaiting response</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Alex Johnson" />
                    <AvatarFallback>AJ</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">Alex Johnson</p>
                    <p className="text-xs text-muted-foreground">Sent 2 days ago</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="h-8 w-8 p-0">
                    <XCircle className="h-4 w-4" />
                  </Button>
                  <Button size="sm" className="h-8 w-8 p-0">
                    <CheckCircle className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" className="w-full">
                View All Requests
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Study Groups</CardTitle>
              <CardDescription>Join or create group study sessions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <h3 className="text-sm font-medium">React Study Group</h3>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>5 members</span>
                  <span>Meets Tuesdays, 7 PM</span>
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  Join Group
                </Button>
              </div>
              <div className="space-y-2">
                <h3 className="text-sm font-medium">JavaScript Algorithms</h3>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>8 members</span>
                  <span>Meets Thursdays, 6 PM</span>
                </div>
                <Button variant="outline" size="sm" className="w-full">
                  Join Group
                </Button>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Create Study Group</Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
