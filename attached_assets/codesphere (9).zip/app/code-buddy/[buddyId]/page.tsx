"use client"
import Link from "next/link"
import { motion } from "framer-motion"
import {
  ArrowLeft,
  MessageSquare,
  UserPlus,
  BookOpen,
  Clock,
  Calendar,
  CheckCircle,
  Award,
  Users,
  Github,
  Linkedin,
  Twitter,
  Globe,
  Code,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"

export default function BuddyDetail({ params }: { params: { buddyId: string } }) {
  const { toast } = useToast()

  // Mock buddy data - in a real app, fetch this from an API
  const buddy = {
    id: params.buddyId,
    name: "Sarah Johnson",
    username: "sarahj",
    avatar: "/placeholder.svg?height=100&width=100",
    rank: "Chunin",
    xp: 4250,
    course: "React Fundamentals",
    progress: 65,
    interests: ["Frontend", "UI/UX", "React", "JavaScript", "CSS", "Responsive Design"],
    availability: "Evenings & Weekends",
    timezone: "GMT-5",
    bio: "Frontend developer passionate about creating beautiful user interfaces. Currently learning React and TypeScript. Looking for study partners to practice and build projects together.",
    compatibility: 92,
    joinDate: "March 2023",
    completedCourses: [
      { name: "HTML & CSS Basics", date: "April 2023" },
      { name: "JavaScript Fundamentals", date: "May 2023" },
    ],
    currentProjects: [
      { name: "Personal Portfolio Website", tech: ["React", "Tailwind CSS"] },
      { name: "Weather App", tech: ["React", "API Integration"] },
    ],
    achievements: [
      { name: "Fast Learner", description: "Completed 3 courses in the first month", icon: Award },
      { name: "Helpful Peer", description: "Received 5 positive reviews from study partners", icon: Users },
    ],
    socialLinks: {
      github: "https://github.com/sarahj",
      linkedin: "https://linkedin.com/in/sarahj",
      twitter: "https://twitter.com/sarahj",
      website: "https://sarahjohnson.dev",
    },
    learningGoals:
      "Master React and TypeScript, build a portfolio of projects, and eventually learn Node.js for full-stack development.",
  }

  const sendBuddyRequest = () => {
    toast({
      title: "Buddy request sent",
      description: "Your request has been sent. You'll be notified when they respond.",
    })
  }

  const sendMessage = () => {
    toast({
      title: "Message sent",
      description: "Your message has been sent to Sarah.",
    })
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex items-center gap-2 mb-6">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/code-buddy">
            <ArrowLeft className="h-4 w-4" />
            <span className="sr-only">Back to buddies</span>
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Buddy Profile</h1>
          <p className="text-muted-foreground">View detailed information and connect</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
            <Card>
              <CardHeader className="text-center">
                <div className="flex justify-center mb-4">
                  <Avatar className="h-24 w-24">
                    <AvatarImage src={buddy.avatar || "/placeholder.svg"} alt={buddy.name} />
                    <AvatarFallback>{buddy.name[0]}</AvatarFallback>
                  </Avatar>
                </div>
                <CardTitle>{buddy.name}</CardTitle>
                <CardDescription className="flex flex-col items-center gap-2">
                  <span>@{buddy.username}</span>
                  <Badge variant="outline">{buddy.rank}</Badge>
                  <Badge variant="outline" className="flex items-center gap-1 text-green-500">
                    <CheckCircle className="h-3 w-3" />
                    {buddy.compatibility}% Match
                  </Badge>
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Award className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{buddy.xp.toLocaleString()} XP</span>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Joined {buddy.joinDate}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{buddy.availability}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Globe className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{buddy.timezone}</span>
                </div>

                <Separator />

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Interests</h3>
                  <div className="flex flex-wrap gap-2">
                    {buddy.interests.map((interest) => (
                      <Badge key={interest} variant="secondary">
                        {interest}
                      </Badge>
                    ))}
                  </div>
                </div>

                <Separator />

                <div className="flex justify-center gap-4">
                  {buddy.socialLinks.github && (
                    <Button variant="outline" size="icon" asChild>
                      <a href={buddy.socialLinks.github} target="_blank" rel="noopener noreferrer">
                        <Github className="h-4 w-4" />
                      </a>
                    </Button>
                  )}
                  {buddy.socialLinks.linkedin && (
                    <Button variant="outline" size="icon" asChild>
                      <a href={buddy.socialLinks.linkedin} target="_blank" rel="noopener noreferrer">
                        <Linkedin className="h-4 w-4" />
                      </a>
                    </Button>
                  )}
                  {buddy.socialLinks.twitter && (
                    <Button variant="outline" size="icon" asChild>
                      <a href={buddy.socialLinks.twitter} target="_blank" rel="noopener noreferrer">
                        <Twitter className="h-4 w-4" />
                      </a>
                    </Button>
                  )}
                  {buddy.socialLinks.website && (
                    <Button variant="outline" size="icon" asChild>
                      <a href={buddy.socialLinks.website} target="_blank" rel="noopener noreferrer">
                        <Globe className="h-4 w-4" />
                      </a>
                    </Button>
                  )}
                </div>
              </CardContent>
              <CardFooter className="flex flex-col gap-2">
                <Button className="w-full" onClick={sendBuddyRequest}>
                  <UserPlus className="mr-2 h-4 w-4" />
                  Send Buddy Request
                </Button>
                <Button variant="outline" className="w-full" onClick={sendMessage}>
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Send Message
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        </div>

        <div className="md:col-span-2">
          <Tabs defaultValue="about">
            <TabsList className="mb-4">
              <TabsTrigger value="about">About</TabsTrigger>
              <TabsTrigger value="courses">Courses & Projects</TabsTrigger>
              <TabsTrigger value="achievements">Achievements</TabsTrigger>
              <TabsTrigger value="compatibility">Compatibility</TabsTrigger>
            </TabsList>

            <TabsContent value="about">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
                <Card>
                  <CardHeader>
                    <CardTitle>About {buddy.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <h3 className="text-sm font-medium">Bio</h3>
                      <p>{buddy.bio}</p>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <h3 className="text-sm font-medium">Learning Goals</h3>
                      <p>{buddy.learningGoals}</p>
                    </div>

                    <Separator />

                    <div className="space-y-2">
                      <h3 className="text-sm font-medium">Current Course</h3>
                      <div className="flex flex-col">
                        <span className="text-sm">{buddy.course}</span>
                        <div className="flex justify-between text-xs text-muted-foreground mb-1">
                          <span>Progress</span>
                          <span>{buddy.progress}%</span>
                        </div>
                        <Progress value={buddy.progress} className="h-1" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            <TabsContent value="courses">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
                <Card>
                  <CardHeader>
                    <CardTitle>Courses & Projects</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-sm font-medium">Current Course</h3>
                      <div className="p-4 rounded-lg border">
                        <div className="flex items-start gap-3">
                          <div className="rounded-md bg-primary/10 p-2">
                            <BookOpen className="h-5 w-5 text-primary" />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-medium">{buddy.course}</h4>
                            <div className="flex justify-between text-xs text-muted-foreground mb-1 mt-2">
                              <span>Progress</span>
                              <span>{buddy.progress}%</span>
                            </div>
                            <Progress value={buddy.progress} className="h-1" />
                          </div>
                        </div>
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-4">
                      <h3 className="text-sm font-medium">Completed Courses</h3>
                      <div className="space-y-3">
                        {buddy.completedCourses.map((course, index) => (
                          <div key={index} className="flex items-start gap-3 p-3 rounded-lg border">
                            <div className="rounded-md bg-green-500/10 p-2">
                              <CheckCircle className="h-5 w-5 text-green-500" />
                            </div>
                            <div>
                              <h4 className="font-medium">{course.name}</h4>
                              <p className="text-xs text-muted-foreground">Completed {course.date}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-4">
                      <h3 className="text-sm font-medium">Current Projects</h3>
                      <div className="space-y-3">
                        {buddy.currentProjects.map((project, index) => (
                          <div key={index} className="flex items-start gap-3 p-3 rounded-lg border">
                            <div className="rounded-md bg-blue-500/10 p-2">
                              <Code className="h-5 w-5 text-blue-500" />
                            </div>
                            <div>
                              <h4 className="font-medium">{project.name}</h4>
                              <div className="flex flex-wrap gap-1 mt-1">
                                {project.tech.map((tech) => (
                                  <Badge key={tech} variant="secondary" className="text-xs">
                                    {tech}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            <TabsContent value="achievements">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
                <Card>
                  <CardHeader>
                    <CardTitle>Achievements</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {buddy.achievements.map((achievement, index) => (
                        <div key={index} className="flex items-start gap-4 p-4 rounded-lg bg-secondary/50">
                          <div className="rounded-full p-2 bg-amber-500/10 text-amber-500">
                            <achievement.icon className="h-5 w-5" />
                          </div>
                          <div>
                            <h3 className="font-medium">{achievement.name}</h3>
                            <p className="text-sm text-muted-foreground">{achievement.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </TabsContent>

            <TabsContent value="compatibility">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
                <Card>
                  <CardHeader>
                    <CardTitle>Compatibility Analysis</CardTitle>
                    <CardDescription>Why you and {buddy.name} are a good match</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-center justify-center">
                      <div className="relative w-32 h-32 flex items-center justify-center">
                        <svg className="w-full h-full" viewBox="0 0 100 100">
                          <circle
                            className="text-muted stroke-current"
                            strokeWidth="10"
                            fill="transparent"
                            r="40"
                            cx="50"
                            cy="50"
                          />
                          <circle
                            className="text-primary stroke-current"
                            strokeWidth="10"
                            strokeLinecap="round"
                            fill="transparent"
                            r="40"
                            cx="50"
                            cy="50"
                            strokeDasharray={`${buddy.compatibility * 2.51} 251.2`}
                            strokeDashoffset="0"
                            transform="rotate(-90 50 50)"
                          />
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="text-2xl font-bold">{buddy.compatibility}%</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="space-y-2">
                        <h3 className="text-sm font-medium">Common Interests</h3>
                        <div className="flex flex-wrap gap-2">
                          {buddy.interests
                            .filter((interest) => ["React", "JavaScript", "Frontend"].includes(interest))
                            .map((interest) => (
                              <Badge key={interest} variant="secondary" className="text-green-500 bg-green-500/10">
                                {interest}
                              </Badge>
                            ))}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <h3 className="text-sm font-medium">Learning Pace</h3>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span>You're both at a similar stage in your learning journey</span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <h3 className="text-sm font-medium">Availability</h3>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span>Your schedules align well for study sessions</span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <h3 className="text-sm font-medium">Learning Goals</h3>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span>You both want to master React and build portfolio projects</span>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 rounded-lg bg-primary/10">
                      <h3 className="text-sm font-medium mb-2">Suggested Study Plan</h3>
                      <ul className="space-y-2 text-sm">
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 text-primary mt-0.5" />
                          <span>Complete React Fundamentals course together</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 text-primary mt-0.5" />
                          <span>Build a collaborative portfolio project</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 text-primary mt-0.5" />
                          <span>Practice with coding challenges twice a week</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 text-primary mt-0.5" />
                          <span>Move on to Advanced React and TypeScript together</span>
                        </li>
                      </ul>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full" onClick={sendBuddyRequest}>
                      <UserPlus className="mr-2 h-4 w-4" />
                      Send Buddy Request
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
