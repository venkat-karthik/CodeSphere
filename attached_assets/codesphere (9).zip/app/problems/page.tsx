"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Search, Filter, FileCode, ArrowRight, Clock, Trophy, Star, BarChart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"

export default function Problems() {
  const [searchQuery, setSearchQuery] = useState("")

  const categories = ["All", "Algorithms", "Data Structures", "System Design", "Frontend", "Backend", "Database"]

  const problems = [
    {
      id: 1,
      title: "Two Sum",
      description: "Find two numbers in an array that add up to a target value",
      category: "Algorithms",
      difficulty: "Easy",
      estimatedTime: "30 mins",
      completionRate: 85,
      stars: 4.8,
      participants: 12450,
    },
    {
      id: 2,
      title: "Implement a Linked List",
      description: "Create a linked list data structure with basic operations",
      category: "Data Structures",
      difficulty: "Medium",
      estimatedTime: "1 hour",
      completionRate: 68,
      stars: 4.5,
      participants: 8765,
    },
    {
      id: 3,
      title: "Design a URL Shortener",
      description: "Create a system design for a URL shortening service",
      category: "System Design",
      difficulty: "Hard",
      estimatedTime: "2 hours",
      completionRate: 42,
      stars: 4.9,
      participants: 5432,
    },
    {
      id: 4,
      title: "Build a Responsive Navbar",
      description: "Create a responsive navigation bar with dropdown menus",
      category: "Frontend",
      difficulty: "Easy",
      estimatedTime: "45 mins",
      completionRate: 92,
      stars: 4.3,
      participants: 9876,
    },
    {
      id: 5,
      title: "Implement JWT Authentication",
      description: "Create a secure authentication system using JSON Web Tokens",
      category: "Backend",
      difficulty: "Medium",
      estimatedTime: "1.5 hours",
      completionRate: 65,
      stars: 4.7,
      participants: 7654,
    },
    {
      id: 6,
      title: "Optimize SQL Queries",
      description: "Improve the performance of complex SQL queries",
      category: "Database",
      difficulty: "Hard",
      estimatedTime: "1.5 hours",
      completionRate: 55,
      stars: 4.6,
      participants: 4321,
    },
  ]

  const filteredProblems = problems.filter(
    (problem) =>
      problem.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      problem.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy":
        return "bg-green-500/10 text-green-500"
      case "Medium":
        return "bg-yellow-500/10 text-yellow-500"
      case "Hard":
        return "bg-red-500/10 text-red-500"
      default:
        return "bg-primary/10 text-primary"
    }
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Problem Statements</h1>
          <p className="text-muted-foreground">Practice with real-world coding problems</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button>
            Random Problem
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search problems..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Select defaultValue="popular">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="popular">Most Popular</SelectItem>
              <SelectItem value="completion">Highest Completion</SelectItem>
              <SelectItem value="difficulty">Difficulty</SelectItem>
              <SelectItem value="newest">Newest First</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-4 flex flex-wrap h-auto">
          {categories.map((category) => (
            <TabsTrigger key={category} value={category === "All" ? "all" : category.toLowerCase()}>
              {category}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProblems.map((problem, index) => (
              <motion.div
                key={problem.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Card className="h-full hover:bg-secondary/50 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="rounded-lg p-2 bg-primary/10 text-primary">
                        <FileCode className="h-4 w-4" />
                      </div>
                      <Badge variant="outline">{problem.category}</Badge>
                    </div>
                    <CardTitle className="mt-2 text-lg">{problem.title}</CardTitle>
                    <CardDescription>{problem.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="flex flex-wrap gap-2 mb-3">
                      <Badge variant="secondary" className={getDifficultyColor(problem.difficulty)}>
                        {problem.difficulty}
                      </Badge>
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {problem.estimatedTime}
                      </Badge>
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <Trophy className="h-3 w-3" />
                        {problem.participants.toLocaleString()} solved
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs">
                        <span>Completion Rate</span>
                        <span>{problem.completionRate}%</span>
                      </div>
                      <Progress value={problem.completionRate} className="h-1" />
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between items-center">
                    <div className="flex items-center gap-1">
                      <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                      <span className="text-xs">{problem.stars} / 5</span>
                    </div>
                    <Button variant="ghost" size="sm">
                      Solve Problem
                      <ArrowRight className="ml-2 h-3 w-3" />
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {categories.slice(1).map((category) => (
          <TabsContent key={category} value={category.toLowerCase()}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProblems
                .filter((problem) => problem.category === category)
                .map((problem, index) => (
                  <motion.div
                    key={problem.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="h-full hover:bg-secondary/50 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div className="rounded-lg p-2 bg-primary/10 text-primary">
                            <FileCode className="h-4 w-4" />
                          </div>
                          <Badge variant="outline">{problem.category}</Badge>
                        </div>
                        <CardTitle className="mt-2 text-lg">{problem.title}</CardTitle>
                        <CardDescription>{problem.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="flex flex-wrap gap-2 mb-3">
                          <Badge variant="secondary" className={getDifficultyColor(problem.difficulty)}>
                            {problem.difficulty}
                          </Badge>
                          <Badge variant="secondary" className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {problem.estimatedTime}
                          </Badge>
                          <Badge variant="secondary" className="flex items-center gap-1">
                            <Trophy className="h-3 w-3" />
                            {problem.participants.toLocaleString()} solved
                          </Badge>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-xs">
                            <span>Completion Rate</span>
                            <span>{problem.completionRate}%</span>
                          </div>
                          <Progress value={problem.completionRate} className="h-1" />
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between items-center">
                        <div className="flex items-center gap-1">
                          <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                          <span className="text-xs">{problem.stars} / 5</span>
                        </div>
                        <Button variant="ghost" size="sm">
                          Solve Problem
                          <ArrowRight className="ml-2 h-3 w-3" />
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      <div className="mt-8">
        <h2 className="text-2xl font-bold tracking-tight mb-4">Problem Statistics</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Total Problems</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <FileCode className="h-5 w-5 text-primary" />
                <span className="text-3xl font-bold">248</span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Problems Solved</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-yellow-500" />
                <span className="text-3xl font-bold">42</span>
              </div>
              <Progress value={(42 / 248) * 100} className="h-1 mt-2" />
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Difficulty Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-green-500">Easy</span>
                  <span>35%</span>
                </div>
                <Progress value={35} className="h-1 bg-green-100 dark:bg-green-900" indicatorClassName="bg-green-500" />
                <div className="flex justify-between text-xs">
                  <span className="text-yellow-500">Medium</span>
                  <span>45%</span>
                </div>
                <Progress
                  value={45}
                  className="h-1 bg-yellow-100 dark:bg-yellow-900"
                  indicatorClassName="bg-yellow-500"
                />
                <div className="flex justify-between text-xs">
                  <span className="text-red-500">Hard</span>
                  <span>20%</span>
                </div>
                <Progress value={20} className="h-1 bg-red-100 dark:bg-red-900" indicatorClassName="bg-red-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Your Ranking</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <BarChart className="h-5 w-5 text-primary" />
                <span className="text-3xl font-bold">#1,245</span>
              </div>
              <p className="text-xs text-muted-foreground mt-2">Top 15% of all users</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
