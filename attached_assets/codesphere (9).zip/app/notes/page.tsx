"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Search, Filter, Plus, BookOpen, Clock, Calendar, Download } from "lucide-react"
import { useSession } from "next-auth/react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FileViewer } from "@/components/file-viewer"
import Link from "next/link"

export default function Notes() {
  const { data: session } = useSession()
  const [searchQuery, setSearchQuery] = useState("")

  const categories = ["All", "JavaScript", "React", "CSS", "HTML", "TypeScript", "Node.js", "Python"]

  const notes = [
    {
      id: 1,
      title: "JavaScript Fundamentals",
      description: "Core concepts of JavaScript including variables, functions, and objects",
      category: "JavaScript",
      date: "2023-05-15",
      lastUpdated: "2023-06-10",
      fileUrl: "/placeholder.svg?height=500&width=800",
      fileSize: "1.2 MB",
    },
    {
      id: 2,
      title: "React Hooks Deep Dive",
      description: "Comprehensive guide to React hooks with examples and best practices",
      category: "React",
      date: "2023-04-22",
      lastUpdated: "2023-06-15",
      fileUrl: "/placeholder.svg?height=500&width=800",
      fileSize: "2.5 MB",
    },
    {
      id: 3,
      title: "CSS Grid Layout",
      description: "How to create responsive layouts using CSS Grid with examples",
      category: "CSS",
      date: "2023-03-10",
      lastUpdated: "2023-05-20",
      fileUrl: "/placeholder.svg?height=500&width=800",
      fileSize: "1.8 MB",
    },
    {
      id: 4,
      title: "HTML5 Semantic Elements",
      description: "Guide to semantic HTML elements and their proper usage",
      category: "HTML",
      date: "2023-02-05",
      lastUpdated: "2023-04-12",
      fileUrl: "/placeholder.svg?height=500&width=800",
      fileSize: "1.0 MB",
    },
    {
      id: 5,
      title: "TypeScript Interfaces vs Types",
      description: "Comparison between TypeScript interfaces and type aliases",
      category: "TypeScript",
      date: "2023-01-20",
      lastUpdated: "2023-03-15",
      fileUrl: "/placeholder.svg?height=500&width=800",
      fileSize: "1.5 MB",
    },
    {
      id: 6,
      title: "Node.js Event Loop",
      description: "Understanding the Node.js event loop and asynchronous programming",
      category: "Node.js",
      date: "2022-12-10",
      lastUpdated: "2023-02-05",
      fileUrl: "/placeholder.svg?height=500&width=800",
      fileSize: "2.0 MB",
    },
  ]

  const filteredNotes = notes.filter(
    (note) =>
      note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })
  }

  // Check if user is an admin
  const isAdmin = session?.user?.role === "ADMIN"

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Notes</h1>
          <p className="text-muted-foreground">Your personal learning notes and summaries</p>
        </div>
        {isAdmin && (
          <div className="mt-4 md:mt-0">
            <Button asChild>
              <Link href="/notes/create">
                <Plus className="mr-2 h-4 w-4" />
                Create Note
              </Link>
            </Button>
          </div>
        )}
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search notes..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Select defaultValue="updated">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="updated">Last Updated</SelectItem>
              <SelectItem value="created">Date Created</SelectItem>
              <SelectItem value="az">A-Z</SelectItem>
              <SelectItem value="za">Z-A</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-4 flex flex-wrap h-auto">
          {categories.map((category) => (
            <TabsTrigger key={category} value={category === "All" ? "all" : category.toLowerCase()}>
              {category}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredNotes.map((note, index) => (
              <motion.div
                key={note.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Card className="h-full hover:bg-secondary/50 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="rounded-lg p-2 bg-primary/10 text-primary">
                        <BookOpen className="h-4 w-4" />
                      </div>
                      <Badge variant="outline">{note.category}</Badge>
                    </div>
                    <CardTitle className="mt-2">{note.title}</CardTitle>
                    <CardDescription>{note.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="flex flex-col gap-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span>Created: {formatDate(note.date)}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>Updated: {formatDate(note.lastUpdated)}</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <FileViewer fileUrl={note.fileUrl} fileName={note.title} fileType="note" fileSize={note.fileSize}>
                      <div className="prose dark:prose-invert max-w-none">
                        <h1>{note.title}</h1>
                        <p>
                          <em>Last updated: {formatDate(note.lastUpdated)}</em>
                        </p>
                        <h2>Introduction</h2>
                        <p>
                          This is a sample note content. In a real application, this would contain the actual note
                          content.
                        </p>
                        <h2>Key Points</h2>
                        <ul>
                          <li>First important point about {note.title}</li>
                          <li>Second important point with more details</li>
                          <li>Third point with examples and code snippets</li>
                        </ul>
                        <h2>Code Example</h2>
                        <pre>
                          <code>
                            {`// Sample code related to ${note.title}
function example() {
  console.log("This is a code example");
  return true;
}`}
                          </code>
                        </pre>
                        <h2>Summary</h2>
                        <p>
                          This concludes the notes on {note.title}. Remember to practice these concepts regularly to
                          reinforce your learning.
                        </p>
                      </div>
                    </FileViewer>
                    <Button variant="outline" size="sm" onClick={() => window.open(note.fileUrl, "_blank")}>
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {categories.slice(1).map((category) => (
          <TabsContent key={category} value={category.toLowerCase()}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredNotes
                .filter((note) => note.category === category)
                .map((note, index) => (
                  <motion.div
                    key={note.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="h-full hover:bg-secondary/50 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div className="rounded-lg p-2 bg-primary/10 text-primary">
                            <BookOpen className="h-4 w-4" />
                          </div>
                          <Badge variant="outline">{note.category}</Badge>
                        </div>
                        <CardTitle className="mt-2">{note.title}</CardTitle>
                        <CardDescription>{note.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="flex flex-col gap-2 text-sm">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span>Created: {formatDate(note.date)}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span>Updated: {formatDate(note.lastUpdated)}</span>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between">
                        <FileViewer
                          fileUrl={note.fileUrl}
                          fileName={note.title}
                          fileType="note"
                          fileSize={note.fileSize}
                        >
                          <div className="prose dark:prose-invert max-w-none">
                            <h1>{note.title}</h1>
                            <p>
                              <em>Last updated: {formatDate(note.lastUpdated)}</em>
                            </p>
                            <h2>Introduction</h2>
                            <p>
                              This is a sample note content. In a real application, this would contain the actual note
                              content.
                            </p>
                            <h2>Key Points</h2>
                            <ul>
                              <li>First important point about {note.title}</li>
                              <li>Second important point with more details</li>
                              <li>Third point with examples and code snippets</li>
                            </ul>
                            <h2>Code Example</h2>
                            <pre>
                              <code>
                                {`// Sample code related to ${note.title}
function example() {
  console.log("This is a code example");
  return true;
}`}
                              </code>
                            </pre>
                            <h2>Summary</h2>
                            <p>
                              This concludes the notes on {note.title}. Remember to practice these concepts regularly to
                              reinforce your learning.
                            </p>
                          </div>
                        </FileViewer>
                        <Button variant="outline" size="sm" onClick={() => window.open(note.fileUrl, "_blank")}>
                          <Download className="mr-2 h-4 w-4" />
                          Download
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
