"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  Search,
  Filter,
  Globe,
  Users,
  ArrowRight,
  MessageSquare,
  ThumbsUp,
  Award,
  BookOpen,
  Video,
  FileText,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"

export default function SphereMap() {
  const [searchQuery, setSearchQuery] = useState("")

  const categories = ["All", "Community", "Events", "Achievements", "Updates"]

  const activities = [
    {
      id: 1,
      user: {
        name: "Sarah Johnson",
        username: "sarahj",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      type: "achievement",
      content: "Completed the React Fundamentals course and earned the React Rookie badge!",
      time: "2 hours ago",
      likes: 24,
      comments: 5,
      icon: <Award className="h-4 w-4" />,
      iconColor: "text-yellow-500",
    },
    {
      id: 2,
      user: {
        name: "David Chen",
        username: "dchen",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      type: "course",
      content: "Just started the Advanced TypeScript course. Excited to learn more about generics and utility types!",
      time: "4 hours ago",
      likes: 18,
      comments: 3,
      icon: <BookOpen className="h-4 w-4" />,
      iconColor: "text-blue-500",
    },
    {
      id: 3,
      user: {
        name: "CodeSphere",
        username: "codesphere",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      type: "update",
      content: "We've just launched our new Interactive Coding Challenges feature! Try it out now.",
      time: "1 day ago",
      likes: 156,
      comments: 42,
      icon: <Globe className="h-4 w-4" />,
      iconColor: "text-green-500",
    },
    {
      id: 4,
      user: {
        name: "Emily Rodriguez",
        username: "emilyr",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      type: "video",
      content:
        "Just watched 'Building a Full-Stack App with Next.js' - highly recommend for anyone interested in modern web development!",
      time: "1 day ago",
      likes: 87,
      comments: 12,
      icon: <Video className="h-4 w-4" />,
      iconColor: "text-purple-500",
    },
    {
      id: 5,
      user: {
        name: "Tech Meetups",
        username: "techmeetups",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      type: "event",
      content: "Join us for the Virtual JavaScript Conference on June 15-16. Free registration for CodeSphere members!",
      time: "2 days ago",
      likes: 210,
      comments: 35,
      icon: <Users className="h-4 w-4" />,
      iconColor: "text-orange-500",
    },
    {
      id: 6,
      user: {
        name: "Michael Park",
        username: "mpark",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      type: "pdf",
      content:
        "Just uploaded my notes on 'Effective Database Design' - feel free to check them out and provide feedback!",
      time: "3 days ago",
      likes: 45,
      comments: 8,
      icon: <FileText className="h-4 w-4" />,
      iconColor: "text-red-500",
    },
  ]

  const filteredActivities = activities.filter(
    (activity) =>
      activity.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      activity.user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      activity.user.username.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "achievement":
        return "Achievement"
      case "course":
        return "Course Update"
      case "update":
        return "Platform Update"
      case "video":
        return "Video"
      case "event":
        return "Event"
      case "pdf":
        return "PDF"
      default:
        return type
    }
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Sphere Map</h1>
          <p className="text-muted-foreground">Stay connected with the global coding community</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button>
            Share Update
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-6">
        <div className="md:w-3/4 space-y-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search updates..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>

          <Tabs defaultValue="all">
            <TabsList className="mb-4">
              {categories.map((category) => (
                <TabsTrigger key={category} value={category === "All" ? "all" : category.toLowerCase()}>
                  {category}
                </TabsTrigger>
              ))}
            </TabsList>

            <TabsContent value="all">
              <div className="space-y-4">
                {filteredActivities.map((activity, index) => (
                  <motion.div
                    key={activity.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card>
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarImage src={activity.user.avatar || "/placeholder.svg"} alt={activity.user.name} />
                              <AvatarFallback>{activity.user.name[0]}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-medium">{activity.user.name}</span>
                                <span className="text-xs text-muted-foreground">@{activity.user.username}</span>
                              </div>
                              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                <span>{activity.time}</span>
                                <span>•</span>
                                <span className="flex items-center gap-1">
                                  <span className={activity.iconColor}>{activity.icon}</span>
                                  {getTypeLabel(activity.type)}
                                </span>
                              </div>
                            </div>
                          </div>
                          <Badge variant="outline">{activity.type}</Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p>{activity.content}</p>
                      </CardContent>
                      <CardFooter className="flex justify-between">
                        <div className="flex gap-4">
                          <Button variant="ghost" size="sm" className="flex items-center gap-1">
                            <ThumbsUp className="h-4 w-4" />
                            <span>{activity.likes}</span>
                          </Button>
                          <Button variant="ghost" size="sm" className="flex items-center gap-1">
                            <MessageSquare className="h-4 w-4" />
                            <span>{activity.comments}</span>
                          </Button>
                        </div>
                        <Button variant="ghost" size="sm">
                          Share
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            {categories.slice(1).map((category) => (
              <TabsContent key={category} value={category.toLowerCase()}>
                <div className="space-y-4">
                  {filteredActivities
                    .filter((activity) => {
                      if (category === "Community") return ["course", "pdf", "video"].includes(activity.type)
                      if (category === "Events") return activity.type === "event"
                      if (category === "Achievements") return activity.type === "achievement"
                      if (category === "Updates") return activity.type === "update"
                      return true
                    })
                    .map((activity, index) => (
                      <motion.div
                        key={activity.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.05 }}
                      >
                        <Card>
                          <CardHeader className="pb-3">
                            <div className="flex justify-between items-start">
                              <div className="flex items-center gap-3">
                                <Avatar>
                                  <AvatarImage
                                    src={activity.user.avatar || "/placeholder.svg"}
                                    alt={activity.user.name}
                                  />
                                  <AvatarFallback>{activity.user.name[0]}</AvatarFallback>
                                </Avatar>
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-medium">{activity.user.name}</span>
                                    <span className="text-xs text-muted-foreground">@{activity.user.username}</span>
                                  </div>
                                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                    <span>{activity.time}</span>
                                    <span>•</span>
                                    <span className="flex items-center gap-1">
                                      <span className={activity.iconColor}>{activity.icon}</span>
                                      {getTypeLabel(activity.type)}
                                    </span>
                                  </div>
                                </div>
                              </div>
                              <Badge variant="outline">{activity.type}</Badge>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <p>{activity.content}</p>
                          </CardContent>
                          <CardFooter className="flex justify-between">
                            <div className="flex gap-4">
                              <Button variant="ghost" size="sm" className="flex items-center gap-1">
                                <ThumbsUp className="h-4 w-4" />
                                <span>{activity.likes}</span>
                              </Button>
                              <Button variant="ghost" size="sm" className="flex items-center gap-1">
                                <MessageSquare className="h-4 w-4" />
                                <span>{activity.comments}</span>
                              </Button>
                            </div>
                            <Button variant="ghost" size="sm">
                              Share
                            </Button>
                          </CardFooter>
                        </Card>
                      </motion.div>
                    ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>

        <div className="md:w-1/4 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Trending Topics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="font-medium">#ReactJS</span>
                  <span className="text-xs text-muted-foreground">1.2K posts</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">#TypeScript</span>
                  <span className="text-xs text-muted-foreground">856 posts</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">#NextJS</span>
                  <span className="text-xs text-muted-foreground">743 posts</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">#WebDev</span>
                  <span className="text-xs text-muted-foreground">612 posts</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">#JavaScript</span>
                  <span className="text-xs text-muted-foreground">589 posts</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Upcoming Events</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div>
                  <h3 className="font-medium">Virtual JavaScript Conference</h3>
                  <p className="text-xs text-muted-foreground">June 15-16, 2023</p>
                </div>
                <Separator />
                <div>
                  <h3 className="font-medium">React Advanced Workshop</h3>
                  <p className="text-xs text-muted-foreground">July 8, 2023</p>
                </div>
                <Separator />
                <div>
                  <h3 className="font-medium">Web Performance Summit</h3>
                  <p className="text-xs text-muted-foreground">July 22, 2023</p>
                </div>
              </div>
              <Button variant="outline" className="w-full">
                View All Events
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Who to Follow</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Jane Smith" />
                      <AvatarFallback>JS</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">Jane Smith</p>
                      <p className="text-xs text-muted-foreground">@janesmith</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    Follow
                  </Button>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Alex Johnson" />
                      <AvatarFallback>AJ</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">Alex Johnson</p>
                      <p className="text-xs text-muted-foreground">@alexj</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    Follow
                  </Button>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Maria Garcia" />
                      <AvatarFallback>MG</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="text-sm font-medium">Maria Garcia</p>
                      <p className="text-xs text-muted-foreground">@mariagarcia</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    Follow
                  </Button>
                </div>
              </div>
              <Button variant="ghost" className="w-full">
                Show More
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
