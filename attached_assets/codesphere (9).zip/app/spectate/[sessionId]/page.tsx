"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  MessageSquare,
  Users,
  ThumbsUp,
  Send,
  Gift,
  Share2,
  Eye,
  Clock,
  Trophy,
  Code,
  Maximize,
  Minimize,
  Volume2,
  VolumeX,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useToast } from "@/hooks/use-toast"

export default function SpectateSession({ params }: { params: { sessionId: string } }) {
  const [message, setMessage] = useState("")
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [activeTab, setActiveTab] = useState("chat")
  const { toast } = useToast()

  // Mock session data - in a real app, fetch this from an API
  const session = {
    id: params.sessionId,
    title: "Building a Real-time Chat App with React and Firebase",
    description: "Watch as I build a complete chat application with authentication and real-time updates",
    category: "Frontend",
    user: {
      name: "Alex Johnson",
      username: "alexj",
      avatar: "/placeholder.svg?height=40&width=40",
      rank: "Kage",
      xp: 15420,
    },
    viewers: 124,
    duration: "1:45:22",
    status: "live",
    cost: 50,
    tags: ["React", "Firebase", "Real-time"],
    likes: 87,
    comments: [
      {
        id: 1,
        user: {
          name: "Sarah Miller",
          username: "sarahm",
          avatar: "/placeholder.svg?height=32&width=32",
          rank: "Jonin",
        },
        message: "This is exactly what I needed! Thanks for the clear explanation of Firebase authentication.",
        time: "5 minutes ago",
        likes: 12,
      },
      {
        id: 2,
        user: {
          name: "David Chen",
          username: "dchen",
          avatar: "/placeholder.svg?height=32&width=32",
          rank: "Chunin",
        },
        message: "Could you explain more about the real-time database structure?",
        time: "10 minutes ago",
        likes: 5,
      },
      {
        id: 3,
        user: {
          name: "Emily Rodriguez",
          username: "emilyr",
          avatar: "/placeholder.svg?height=32&width=32",
          rank: "Genin",
        },
        message: "I'm having trouble with the Firebase setup. Can you go over that part again?",
        time: "15 minutes ago",
        likes: 3,
      },
      {
        id: 4,
        user: {
          name: "Michael Park",
          username: "mpark",
          avatar: "/placeholder.svg?height=32&width=32",
          rank: "ANBU",
        },
        message: "Great explanation of the React hooks! Very clear and concise.",
        time: "20 minutes ago",
        likes: 8,
      },
      {
        id: 5,
        user: {
          name: "Jessica Lee",
          username: "jlee",
          avatar: "/placeholder.svg?height=32&width=32",
          rank: "Rookie Ninja",
        },
        message: "I'm new to React. Is there a good resource you recommend for beginners?",
        time: "25 minutes ago",
        likes: 4,
      },
    ],
    codeSnippets: [
      {
        id: 1,
        title: "Firebase Configuration",
        language: "javascript",
        code: `// Firebase configuration
const firebaseConfig = {
  apiKey: "your-api-key",
  authDomain: "your-auth-domain",
  projectId: "your-project-id",
  storageBucket: "your-storage-bucket",
  messagingSenderId: "your-messaging-sender-id",
  appId: "your-app-id"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);`,
        time: "10 minutes ago",
      },
      {
        id: 2,
        title: "Authentication Hook",
        language: "javascript",
        code: `// Custom authentication hook
function useAuth() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signIn = (email, password) => {
    return signInWithEmailAndPassword(auth, email, password);
  };

  const signUp = (email, password) => {
    return createUserWithEmailAndPassword(auth, email, password);
  };

  const signOut = () => {
    return auth.signOut();
  };

  return { user, loading, signIn, signUp, signOut };
}`,
        time: "25 minutes ago",
      },
    ],
  }

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!message.trim()) return

    // In a real app, this would send the message to a backend
    toast({
      title: "Message sent",
      description: "Your message has been sent to the chat",
    })
    setMessage("")
  }

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen)
  }

  const toggleMute = () => {
    setIsMuted(!isMuted)
  }

  const sendGift = () => {
    toast({
      title: "Gift sent",
      description: "You've sent a gift of 10 XP to the streamer",
    })
  }

  return (
    <div className={`container mx-auto py-8 px-4 ${isFullscreen ? "fixed inset-0 z-50 bg-background p-0" : ""}`}>
      {!isFullscreen && (
        <div className="flex items-center gap-2 mb-6">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/spectate">
              <ArrowLeft className="h-4 w-4" />
              <span className="sr-only">Back to sessions</span>
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{session.title}</h1>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Badge variant="outline">{session.category}</Badge>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Eye className="h-4 w-4" />
                {session.viewers} viewers
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                {session.duration}
              </span>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className={`${isFullscreen ? "fixed inset-0 z-50" : "lg:col-span-2"}`}>
          <Card className={`h-full ${isFullscreen ? "rounded-none border-0" : ""}`}>
            <CardContent className={`p-0 ${isFullscreen ? "h-screen" : ""}`}>
              <div className="relative bg-black aspect-video w-full h-full">
                {/* This would be a real video player in a production app */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-white text-lg">Live Coding Session</div>
                </div>

                {/* Video controls overlay */}
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="icon" className="text-white" onClick={toggleMute}>
                        {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                      </Button>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="icon" className="text-white" onClick={toggleFullscreen}>
                        {isFullscreen ? <Minimize className="h-5 w-5" /> : <Maximize className="h-5 w-5" />}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {!isFullscreen && (
          <div className="lg:col-span-1">
            <Card className="h-full">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-2">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={session.user.avatar || "/placeholder.svg"} alt={session.user.name} />
                      <AvatarFallback>{session.user.name[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{session.user.name}</span>
                        <Badge variant="secondary" className="flex items-center gap-1">
                          <Trophy className="h-3 w-3" />
                          {session.user.rank}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">@{session.user.username}</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    Follow
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="pb-3">
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="w-full">
                    <TabsTrigger value="chat" className="flex-1">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Chat
                    </TabsTrigger>
                    <TabsTrigger value="code" className="flex-1">
                      <Code className="h-4 w-4 mr-2" />
                      Code
                    </TabsTrigger>
                    <TabsTrigger value="viewers" className="flex-1">
                      <Users className="h-4 w-4 mr-2" />
                      Viewers
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="chat" className="mt-4">
                    <div className="flex flex-col h-[400px]">
                      <ScrollArea className="flex-1 pr-4">
                        <div className="space-y-4">
                          {session.comments.map((comment) => (
                            <div key={comment.id} className="flex gap-3">
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={comment.user.avatar || "/placeholder.svg"} alt={comment.user.name} />
                                <AvatarFallback>{comment.user.name[0]}</AvatarFallback>
                              </Avatar>
                              <div className="flex-1 space-y-1">
                                <div className="flex items-center gap-2">
                                  <span className="text-sm font-medium">{comment.user.name}</span>
                                  <Badge variant="outline" className="text-xs">
                                    {comment.user.rank}
                                  </Badge>
                                </div>
                                <p className="text-sm">{comment.message}</p>
                                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                                  <span>{comment.time}</span>
                                  <button className="flex items-center gap-1 hover:text-foreground">
                                    <ThumbsUp className="h-3 w-3" />
                                    {comment.likes}
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>

                      <Separator className="my-4" />

                      <form onSubmit={sendMessage} className="flex gap-2">
                        <Input
                          placeholder="Type a message..."
                          value={message}
                          onChange={(e) => setMessage(e.target.value)}
                        />
                        <Button type="submit" size="icon">
                          <Send className="h-4 w-4" />
                        </Button>
                      </form>
                    </div>
                  </TabsContent>

                  <TabsContent value="code" className="mt-4">
                    <div className="space-y-4">
                      {session.codeSnippets.map((snippet) => (
                        <div key={snippet.id} className="space-y-2">
                          <div className="flex justify-between items-center">
                            <h3 className="text-sm font-medium">{snippet.title}</h3>
                            <span className="text-xs text-muted-foreground">{snippet.time}</span>
                          </div>
                          <pre className="bg-secondary p-3 rounded-md text-xs overflow-x-auto">{snippet.code}</pre>
                          <div className="flex justify-end gap-2">
                            <Button variant="outline" size="sm">
                              Copy
                            </Button>
                            <Button variant="outline" size="sm">
                              Save
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="viewers" className="mt-4">
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <h3 className="text-sm font-medium">Current Viewers</h3>
                        <span className="text-xs text-muted-foreground">{session.viewers} watching</span>
                      </div>
                      <div className="space-y-2">
                        {[...Array(5)].map((_, index) => (
                          <div key={index} className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={`/placeholder.svg?height=32&width=32`} />
                                <AvatarFallback>U{index + 1}</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="text-sm font-medium">User {index + 1}</p>
                                <p className="text-xs text-muted-foreground">@user{index + 1}</p>
                              </div>
                            </div>
                            <Badge variant="outline">
                              {["Rookie Ninja", "Genin", "Chunin", "Jonin", "ANBU"][index]}
                            </Badge>
                          </div>
                        ))}
                      </div>
                      <Button variant="outline" className="w-full">
                        View All Viewers
                      </Button>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
              <CardFooter className="flex justify-between">
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex items-center gap-1">
                    <ThumbsUp className="h-4 w-4" />
                    <span>{session.likes}</span>
                  </Button>
                  <Button variant="outline" size="sm" className="flex items-center gap-1">
                    <Share2 className="h-4 w-4" />
                    <span>Share</span>
                  </Button>
                </div>
                <Button size="sm" onClick={sendGift} className="flex items-center gap-1">
                  <Gift className="h-4 w-4" />
                  <span>Send Gift</span>
                </Button>
              </CardFooter>
            </Card>
          </div>
        )}
      </div>

      {!isFullscreen && (
        <div className="mt-8">
          <h2 className="text-2xl font-bold tracking-tight mb-4">Session Details</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>About This Session</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4">{session.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {session.tags.map((tag) => (
                    <Badge key={tag} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">What You'll Learn</h3>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li>Setting up Firebase authentication</li>
                    <li>Creating a real-time database</li>
                    <li>Building a responsive chat UI with React</li>
                    <li>Implementing user presence indicators</li>
                    <li>Handling file uploads and media sharing</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Streamer Profile</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={session.user.avatar || "/placeholder.svg"} alt={session.user.name} />
                    <AvatarFallback>{session.user.name[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{session.user.name}</p>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <Trophy className="h-3 w-3" />
                        {session.user.rank}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{session.user.xp.toLocaleString()} XP</span>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Expertise</h3>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline">React</Badge>
                    <Badge variant="outline">Firebase</Badge>
                    <Badge variant="outline">JavaScript</Badge>
                    <Badge variant="outline">Node.js</Badge>
                    <Badge variant="outline">UI/UX</Badge>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Stats</h3>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div>
                      <p className="text-lg font-bold">42</p>
                      <p className="text-xs text-muted-foreground">Sessions</p>
                    </div>
                    <div>
                      <p className="text-lg font-bold">1.2K</p>
                      <p className="text-xs text-muted-foreground">Followers</p>
                    </div>
                    <div>
                      <p className="text-lg font-bold">4.9</p>
                      <p className="text-xs text-muted-foreground">Rating</p>
                    </div>
                  </div>
                </div>

                <Button className="w-full">View Full Profile</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  )
}
