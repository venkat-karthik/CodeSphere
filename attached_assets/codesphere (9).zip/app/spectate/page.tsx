"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Search, Filter, Eye, ArrowRight, Clock, Trophy, Star, Users, Play } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function Spectate() {
  const [searchQuery, setSearchQuery] = useState("")

  const categories = ["All", "Frontend", "Backend", "Mobile", "Data Science", "DevOps"]

  const sessions = [
    {
      id: 1,
      title: "Building a Real-time Chat App with React and Firebase",
      description: "Watch as I build a complete chat application with authentication and real-time updates",
      category: "Frontend",
      user: {
        name: "Alex Johnson",
        username: "alexj",
        avatar: "/placeholder.svg?height=40&width=40",
        rank: "Kage",
        xp: 15420,
      },
      viewers: 124,
      duration: "1:45:22",
      status: "live",
      cost: 50,
      tags: ["React", "Firebase", "Real-time"],
    },
    {
      id: 2,
      title: "Creating a RESTful API with Node.js and Express",
      description: "Learn how to design and implement a robust API with authentication and database integration",
      category: "Backend",
      user: {
        name: "Sarah Miller",
        username: "sarahm",
        avatar: "/placeholder.svg?height=40&width=40",
        rank: "Jonin",
        xp: 8750,
      },
      viewers: 87,
      duration: "2:12:05",
      status: "live",
      cost: 75,
      tags: ["Node.js", "Express", "MongoDB"],
    },
    {
      id: 3,
      title: "Flutter App Development: E-commerce Store",
      description: "Building a complete e-commerce mobile app with Flutter and Firebase",
      category: "Mobile",
      user: {
        name: "David Chen",
        username: "dchen",
        avatar: "/placeholder.svg?height=40&width=40",
        rank: "ANBU",
        xp: 12340,
      },
      viewers: 56,
      duration: "1:30:45",
      status: "scheduled",
      scheduledTime: "Tomorrow, 3:00 PM",
      cost: 60,
      tags: ["Flutter", "Firebase", "Mobile"],
    },
    {
      id: 4,
      title: "Data Analysis with Python and Pandas",
      description: "Analyzing real-world datasets and creating visualizations with Python",
      category: "Data Science",
      user: {
        name: "Emily Rodriguez",
        username: "emilyr",
        avatar: "/placeholder.svg?height=40&width=40",
        rank: "Chunin",
        xp: 6540,
      },
      viewers: 92,
      duration: "1:15:30",
      status: "live",
      cost: 40,
      tags: ["Python", "Pandas", "Data Analysis"],
    },
    {
      id: 5,
      title: "DevOps Pipeline with GitHub Actions and AWS",
      description: "Setting up a complete CI/CD pipeline for automated testing and deployment",
      category: "DevOps",
      user: {
        name: "Michael Park",
        username: "mpark",
        avatar: "/placeholder.svg?height=40&width=40",
        rank: "Jonin",
        xp: 9870,
      },
      viewers: 45,
      duration: "2:30:15",
      status: "scheduled",
      scheduledTime: "Today, 8:00 PM",
      cost: 80,
      tags: ["DevOps", "AWS", "GitHub Actions"],
    },
    {
      id: 6,
      title: "Building a Portfolio Website with Next.js",
      description: "Creating a modern, responsive portfolio website with Next.js and Tailwind CSS",
      category: "Frontend",
      user: {
        name: "Jessica Lee",
        username: "jlee",
        avatar: "/placeholder.svg?height=40&width=40",
        rank: "Chunin",
        xp: 5430,
      },
      viewers: 78,
      duration: "1:20:10",
      status: "live",
      cost: 35,
      tags: ["Next.js", "Tailwind CSS", "Portfolio"],
    },
  ]

  const filteredSessions = sessions.filter(
    (session) =>
      session.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      session.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      session.user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      session.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Spectate Pro Coders</h1>
          <p className="text-muted-foreground">Watch and learn from top-ranked developers in real-time</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button>
            Your XP Balance: 250
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search sessions..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Select defaultValue="live">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="live">Live Now</SelectItem>
              <SelectItem value="scheduled">Scheduled</SelectItem>
              <SelectItem value="all">All Sessions</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-4 flex flex-wrap h-auto">
          {categories.map((category) => (
            <TabsTrigger key={category} value={category === "All" ? "all" : category.toLowerCase()}>
              {category}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredSessions.map((session, index) => (
              <motion.div
                key={session.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Card className="h-full hover:bg-secondary/50 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="relative rounded-lg overflow-hidden mb-3 aspect-video bg-muted">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Play className="h-12 w-12 text-white opacity-80" />
                      </div>
                      <div className="absolute top-2 left-2">
                        {session.status === "live" ? (
                          <Badge variant="destructive" className="bg-red-500">
                            LIVE
                          </Badge>
                        ) : (
                          <Badge variant="outline">Scheduled</Badge>
                        )}
                      </div>
                      <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded flex items-center">
                        <Eye className="h-3 w-3 mr-1" />
                        {session.viewers}
                      </div>
                      {session.status === "scheduled" && (
                        <div className="absolute bottom-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                          {session.scheduledTime}
                        </div>
                      )}
                    </div>
                    <div className="flex justify-between items-start">
                      <Badge variant="outline">{session.category}</Badge>
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <Trophy className="h-3 w-3" />
                        {session.user.rank}
                      </Badge>
                    </div>
                    <CardTitle className="mt-2 text-lg">{session.title}</CardTitle>
                    <CardDescription>{session.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="flex items-center gap-2 mb-3">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={session.user.avatar || "/placeholder.svg"} alt={session.user.name} />
                        <AvatarFallback>{session.user.name[0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium">{session.user.name}</p>
                        <p className="text-xs text-muted-foreground">@{session.user.username}</p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 mb-3">
                      {session.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>{session.duration}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <span>{session.viewers} viewers</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between items-center">
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm">{session.cost} XP</span>
                    </div>
                    <Button variant="default" size="sm">
                      {session.status === "live" ? "Join Session" : "Remind Me"}
                      <ArrowRight className="ml-2 h-3 w-3" />
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {categories.slice(1).map((category) => (
          <TabsContent key={category} value={category.toLowerCase()}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredSessions
                .filter((session) => session.category === category)
                .map((session, index) => (
                  <motion.div
                    key={session.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="h-full hover:bg-secondary/50 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="relative rounded-lg overflow-hidden mb-3 aspect-video bg-muted">
                          <div className="absolute inset-0 flex items-center justify-center">
                            <Play className="h-12 w-12 text-white opacity-80" />
                          </div>
                          <div className="absolute top-2 left-2">
                            {session.status === "live" ? (
                              <Badge variant="destructive" className="bg-red-500">
                                LIVE
                              </Badge>
                            ) : (
                              <Badge variant="outline">Scheduled</Badge>
                            )}
                          </div>
                          <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded flex items-center">
                            <Eye className="h-3 w-3 mr-1" />
                            {session.viewers}
                          </div>
                          {session.status === "scheduled" && (
                            <div className="absolute bottom-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                              {session.scheduledTime}
                            </div>
                          )}
                        </div>
                        <div className="flex justify-between items-start">
                          <Badge variant="outline">{session.category}</Badge>
                          <Badge variant="secondary" className="flex items-center gap-1">
                            <Trophy className="h-3 w-3" />
                            {session.user.rank}
                          </Badge>
                        </div>
                        <CardTitle className="mt-2 text-lg">{session.title}</CardTitle>
                        <CardDescription>{session.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3">
                        <div className="flex items-center gap-2 mb-3">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={session.user.avatar || "/placeholder.svg"} alt={session.user.name} />
                            <AvatarFallback>{session.user.name[0]}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-sm font-medium">{session.user.name}</p>
                            <p className="text-xs text-muted-foreground">@{session.user.username}</p>
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-2 mb-3">
                          {session.tags.map((tag) => (
                            <Badge key={tag} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                        <div className="flex justify-between items-center text-sm">
                          <div className="flex items-center gap-1">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span>{session.duration}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="h-4 w-4 text-muted-foreground" />
                            <span>{session.viewers} viewers</span>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="flex justify-between items-center">
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-500" />
                          <span className="text-sm">{session.cost} XP</span>
                        </div>
                        <Button variant="default" size="sm">
                          {session.status === "live" ? "Join Session" : "Remind Me"}
                          <ArrowRight className="ml-2 h-3 w-3" />
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      <div className="mt-8">
        <h2 className="text-2xl font-bold tracking-tight mb-4">Featured Sessions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-blue-500 opacity-20" />
            <CardHeader>
              <div className="flex justify-between items-start">
                <Badge variant="outline" className="bg-white/10 text-white border-white/20">
                  Special Event
                </Badge>
                <Badge variant="secondary" className="flex items-center gap-1 bg-white/10 text-white border-white/20">
                  <Trophy className="h-3 w-3" />
                  Legendary Sannin
                </Badge>
              </div>
              <CardTitle className="text-xl mt-2">Advanced System Design Workshop</CardTitle>
              <CardDescription>
                Join our special workshop with a top industry expert on designing scalable systems
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 mb-3">
                <Avatar className="h-8 w-8 border-2 border-primary">
                  <AvatarImage src="/placeholder.svg?height=32&width=32" alt="John Doe" />
                  <AvatarFallback>JD</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium">John Doe</p>
                  <p className="text-xs text-muted-foreground">Senior Architect at TechCorp</p>
                </div>
              </div>
              <div className="flex justify-between items-center text-sm">
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>This Saturday, 10:00 AM</span>
                </div>
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 text-yellow-500" />
                  <span>100 XP</span>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Reserve Your Spot</Button>
            </CardFooter>
          </Card>

          <Card className="relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-amber-500 to-orange-500 opacity-20" />
            <CardHeader>
              <div className="flex justify-between items-start">
                <Badge variant="outline" className="bg-white/10 text-white border-white/20">
                  Weekly Challenge
                </Badge>
                <Badge variant="secondary" className="flex items-center gap-1 bg-white/10 text-white border-white/20">
                  <Users className="h-3 w-3" />
                  Team Event
                </Badge>
              </div>
              <CardTitle className="text-xl mt-2">Competitive Coding Tournament</CardTitle>
              <CardDescription>Participate in our weekly coding competition and win exclusive rewards</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 mb-3">
                <div className="flex -space-x-2">
                  <Avatar className="h-8 w-8 border-2 border-background">
                    <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User 1" />
                    <AvatarFallback>U1</AvatarFallback>
                  </Avatar>
                  <Avatar className="h-8 w-8 border-2 border-background">
                    <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User 2" />
                    <AvatarFallback>U2</AvatarFallback>
                  </Avatar>
                  <Avatar className="h-8 w-8 border-2 border-background">
                    <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User 3" />
                    <AvatarFallback>U3</AvatarFallback>
                  </Avatar>
                  <div className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-background bg-muted text-xs">
                    +42
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">45 participants registered</p>
              </div>
              <div className="flex justify-between items-center text-sm">
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>Every Sunday, 2:00 PM</span>
                </div>
                <div className="flex items-center gap-1">
                  <Trophy className="h-4 w-4 text-yellow-500" />
                  <span>500 XP Prize Pool</span>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Register Now</Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
