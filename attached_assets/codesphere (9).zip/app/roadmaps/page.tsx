"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Search, Map, ArrowRight, CheckCircle, Circle, ChevronRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function Roadmaps() {
  const [searchQuery, setSearchQuery] = useState("")

  const categories = ["All", "Frontend", "Backend", "Mobile", "DevOps", "Data Science"]

  const roadmaps = [
    {
      id: 1,
      title: "Frontend Developer",
      description: "Master HTML, CSS, JavaScript, and modern frontend frameworks",
      category: "Frontend",
      difficulty: "Beginner to Advanced",
      steps: 24,
      progress: 65,
      image: "/placeholder.svg?height=100&width=200",
    },
    {
      id: 2,
      title: "Backend Developer",
      description: "Learn server-side programming, databases, and API development",
      category: "Backend",
      difficulty: "Intermediate",
      steps: 18,
      progress: 30,
      image: "/placeholder.svg?height=100&width=200",
    },
    {
      id: 3,
      title: "Full Stack JavaScript",
      description: "Become proficient in both frontend and backend JavaScript technologies",
      category: "Frontend",
      difficulty: "Intermediate to Advanced",
      steps: 32,
      progress: 15,
      image: "/placeholder.svg?height=100&width=200",
    },
    {
      id: 4,
      title: "DevOps Engineer",
      description: "Master CI/CD, containerization, and cloud infrastructure",
      category: "DevOps",
      difficulty: "Advanced",
      steps: 28,
      progress: 0,
      image: "/placeholder.svg?height=100&width=200",
    },
    {
      id: 5,
      title: "React Developer",
      description: "Comprehensive guide to becoming a React professional",
      category: "Frontend",
      difficulty: "Intermediate",
      steps: 20,
      progress: 45,
      image: "/placeholder.svg?height=100&width=200",
    },
    {
      id: 6,
      title: "Mobile App Developer",
      description: "Learn to build cross-platform mobile applications",
      category: "Mobile",
      difficulty: "Intermediate",
      steps: 22,
      progress: 0,
      image: "/placeholder.svg?height=100&width=200",
    },
  ]

  const filteredRoadmaps = roadmaps.filter(
    (roadmap) =>
      roadmap.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      roadmap.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const featuredRoadmap = {
    title: "Frontend Developer",
    progress: 65,
    steps: [
      { title: "HTML Fundamentals", completed: true },
      { title: "CSS Basics", completed: true },
      { title: "JavaScript Essentials", completed: true },
      { title: "Responsive Design", completed: true },
      { title: "CSS Frameworks", completed: true },
      { title: "JavaScript DOM Manipulation", completed: true },
      { title: "ES6+ Features", completed: false },
      { title: "Frontend Build Tools", completed: false },
    ],
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Learning Roadmaps</h1>
          <p className="text-muted-foreground">Follow structured paths to master different technologies</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button>
            Continue Learning
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        <div className="lg:col-span-2">
          <Card className="border-none bg-card/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>Continue Your Journey</CardTitle>
              <CardDescription>Pick up where you left off on the Frontend Developer roadmap</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progress</span>
                  <span className="font-medium">{featuredRoadmap.progress}%</span>
                </div>
                <Progress value={featuredRoadmap.progress} className="h-2" />
              </div>

              <div className="space-y-2">
                {featuredRoadmap.steps.map((step, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                    className="flex items-center gap-3 p-2 rounded-md hover:bg-secondary/50 transition-colors"
                  >
                    {step.completed ? (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    ) : (
                      <Circle className="h-5 w-5 text-muted-foreground" />
                    )}
                    <span className={step.completed ? "line-through opacity-70" : ""}>{step.title}</span>
                    {!step.completed && index === featuredRoadmap.steps.findIndex((s) => !s.completed) && (
                      <Badge variant="secondary" className="ml-auto">
                        Current
                      </Badge>
                    )}
                  </motion.div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full" asChild>
                <a href="/roadmaps/frontend">
                  Continue Learning
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
            </CardFooter>
          </Card>
        </div>

        <div>
          <Card className="border-none bg-card/50 backdrop-blur-sm h-full">
            <CardHeader>
              <CardTitle>Roadmap Benefits</CardTitle>
              <CardDescription>Why follow a structured learning path?</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="rounded-full p-1.5 bg-primary/10 text-primary mt-0.5">
                  <ChevronRight className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm font-medium">Structured Learning</p>
                  <p className="text-xs text-muted-foreground">Follow a proven path to mastery</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="rounded-full p-1.5 bg-primary/10 text-primary mt-0.5">
                  <ChevronRight className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm font-medium">Track Progress</p>
                  <p className="text-xs text-muted-foreground">See how far you've come and what's next</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="rounded-full p-1.5 bg-primary/10 text-primary mt-0.5">
                  <ChevronRight className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm font-medium">Industry Relevance</p>
                  <p className="text-xs text-muted-foreground">Learn skills that employers are looking for</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="rounded-full p-1.5 bg-primary/10 text-primary mt-0.5">
                  <ChevronRight className="h-4 w-4" />
                </div>
                <div>
                  <p className="text-sm font-medium">Avoid Overwhelm</p>
                  <p className="text-xs text-muted-foreground">Focus on what matters without getting lost</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search roadmaps..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="mb-4">
          {categories.map((category) => (
            <TabsTrigger key={category} value={category === "All" ? "all" : category.toLowerCase()}>
              {category}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRoadmaps.map((roadmap, index) => (
              <motion.div
                key={roadmap.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Card className="h-full hover:bg-secondary/50 transition-colors">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="rounded-lg p-2 bg-primary/10 text-primary">
                        <Map className="h-4 w-4" />
                      </div>
                      <Badge variant="outline">{roadmap.category}</Badge>
                    </div>
                    <CardTitle className="mt-2 text-lg">{roadmap.title}</CardTitle>
                    <CardDescription>{roadmap.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3 space-y-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">{roadmap.difficulty}</span>
                      <span className="text-muted-foreground">{roadmap.steps} steps</span>
                    </div>
                    {roadmap.progress > 0 && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span>Progress</span>
                          <span>{roadmap.progress}%</span>
                        </div>
                        <Progress value={roadmap.progress} className="h-1.5" />
                      </div>
                    )}
                  </CardContent>
                  <CardFooter>
                    <Button variant="ghost" size="sm" className="w-full" asChild>
                      <a href={`/roadmaps/${roadmap.id}`}>
                        {roadmap.progress > 0 ? "Continue" : "Start"} Roadmap
                        <ArrowRight className="ml-2 h-3 w-3" />
                      </a>
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        {categories.slice(1).map((category) => (
          <TabsContent key={category} value={category.toLowerCase()}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredRoadmaps
                .filter((roadmap) => roadmap.category === category)
                .map((roadmap, index) => (
                  <motion.div
                    key={roadmap.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="h-full hover:bg-secondary/50 transition-colors">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div className="rounded-lg p-2 bg-primary/10 text-primary">
                            <Map className="h-4 w-4" />
                          </div>
                          <Badge variant="outline">{roadmap.category}</Badge>
                        </div>
                        <CardTitle className="mt-2 text-lg">{roadmap.title}</CardTitle>
                        <CardDescription>{roadmap.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="pb-3 space-y-4">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">{roadmap.difficulty}</span>
                          <span className="text-muted-foreground">{roadmap.steps} steps</span>
                        </div>
                        {roadmap.progress > 0 && (
                          <div className="space-y-1">
                            <div className="flex justify-between text-xs">
                              <span>Progress</span>
                              <span>{roadmap.progress}%</span>
                            </div>
                            <Progress value={roadmap.progress} className="h-1.5" />
                          </div>
                        )}
                      </CardContent>
                      <CardFooter>
                        <Button variant="ghost" size="sm" className="w-full" asChild>
                          <a href={`/roadmaps/${roadmap.id}`}>
                            {roadmap.progress > 0 ? "Continue" : "Start"} Roadmap
                            <ArrowRight className="ml-2 h-3 w-3" />
                          </a>
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
