import { PrismaClient } from "@prisma/client"
import { hash } from "bcrypt"

const prisma = new PrismaClient()

async function main() {
  try {
    // Create admin user
    const adminPassword = await hash("admin123", 10)
    const admin = await prisma.user.upsert({
      where: { email: "admin@codesphere.com" },
      update: {},
      create: {
        name: "Admin User",
        email: "admin@codesphere.com",
        hashedPassword: adminPassword,
        role: "ADMIN",
      },
    })

    console.log("Admin user created:", admin.email)

    // Create regular user
    const userPassword = await hash("user123", 10)
    const user = await prisma.user.upsert({
      where: { email: "user@codesphere.com" },
      update: {},
      create: {
        name: "Regular User",
        email: "user@codesphere.com",
        hashedPassword: userPassword,
        role: "USER",
      },
    })

    console.log("Regular user created:", user.email)

    // Create sample content
    // Notes
    const notes = [
      {
        title: "JavaScript Fundamentals",
        content:
          "# JavaScript Fundamentals\n\nThis note covers the core concepts of JavaScript including variables, functions, and objects...",
        description: "Core concepts of JavaScript including variables, functions, and objects",
        category: "JavaScript",
        tags: ["beginner", "fundamentals"],
      },
      {
        title: "React Hooks Deep Dive",
        content:
          "# React Hooks Deep Dive\n\nThis note explores React hooks like useState, useEffect, useContext and custom hooks...",
        description: "Understanding React hooks like useState, useEffect, useContext and custom hooks",
        category: "React",
        tags: ["intermediate", "hooks"],
      },
    ]

    for (const note of notes) {
      await prisma.note.create({
        data: note,
      })
    }

    console.log("Sample notes created")

    // PDFs
    const pdfs = [
      {
        title: "JavaScript Fundamentals Handbook",
        description: "A comprehensive guide to JavaScript basics including variables, functions, and objects",
        category: "JavaScript",
        tags: ["beginner", "fundamentals"],
        fileUrl: "https://example.com/javascript-handbook.pdf",
        fileSize: "2.4 MB",
        pages: 42,
      },
      {
        title: "React Hooks Explained",
        description: "Deep dive into React hooks with practical examples and best practices",
        category: "React",
        tags: ["intermediate", "hooks"],
        fileUrl: "https://example.com/react-hooks.pdf",
        fileSize: "1.8 MB",
        pages: 36,
      },
    ]

    for (const pdf of pdfs) {
      await prisma.pDF.create({
        data: pdf,
      })
    }

    console.log("Sample PDFs created")

    // Videos
    const videos = [
      {
        title: "JavaScript Crash Course for Beginners",
        description: "Learn JavaScript basics in this comprehensive crash course for beginners",
        category: "JavaScript",
        tags: ["beginner", "fundamentals"],
        videoUrl: "https://example.com/javascript-crash-course.mp4",
        thumbnailUrl: "/placeholder.svg?height=180&width=320",
        duration: "45:22",
      },
      {
        title: "React Hooks Deep Dive",
        description: "Master React hooks with practical examples and advanced patterns",
        category: "React",
        tags: ["intermediate", "hooks"],
        videoUrl: "https://example.com/react-hooks-deep-dive.mp4",
        thumbnailUrl: "/placeholder.svg?height=180&width=320",
        duration: "32:15",
      },
    ]

    for (const video of videos) {
      await prisma.video.create({
        data: video,
      })
    }

    console.log("Sample videos created")

    // Roadmaps
    const roadmap = await prisma.roadmap.create({
      data: {
        title: "Frontend Developer",
        description: "Master HTML, CSS, JavaScript, and modern frontend frameworks",
        category: "Frontend",
        difficulty: "Beginner to Advanced",
        steps: {
          create: [
            {
              title: "HTML Fundamentals",
              content: "Learn the basics of HTML markup and document structure",
              order: 1,
            },
            {
              title: "CSS Basics",
              content: "Master CSS styling, selectors, and layout techniques",
              order: 2,
            },
            {
              title: "JavaScript Essentials",
              content: "Understand core JavaScript concepts and DOM manipulation",
              order: 3,
            },
            {
              title: "Responsive Design",
              content: "Create websites that work well on all devices",
              order: 4,
            },
          ],
        },
      },
    })

    console.log("Sample roadmap created")

    console.log("Setup completed successfully!")
  } catch (error) {
    console.error("Error during setup:", error)
    process.exit(1)
  } finally {
    await prisma.$disconnect()
  }
}

main()
