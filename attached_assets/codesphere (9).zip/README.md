# CodeSphere - The Ultimate Coding Hub

A comprehensive, user-centric platform designed to revolutionize the way coders and developers learn, collaborate, and grow.

## Features

- **User Authentication**: Sign up, login, and profile management
- **Admin Dashboard**: Manage content, users, and view analytics
- **Learning Resources**: Notes, PDFs, Videos, and Roadmaps
- **Online Classes**: Live coding sessions with video, audio, and chat functionality
- **Bookmarks**: Save your favorite content for later
- **Streak System**: Track your learning consistency
- **XP System**: Earn experience points as you learn
- **AI Mentor**: Get help and guidance from an AI assistant
- **Community**: Connect with other developers
- **Code Buddy**: Find study partners for collaborative learning
- **Spectate**: Watch pro coders in action
- **Personalized Settings**: Customize notifications, appearance, and account settings

## Tech Stack

- **Frontend**: Next.js, React, Tailwind CSS, shadcn/ui
- **Backend**: Next.js API Routes, Prisma ORM
- **Database**: PostgreSQL (via Neon)
- **Authentication**: NextAuth.js
- **Animations**: Framer Motion
- **Video Conferencing**: WebRTC (for online classes)

## Getting Started

### Prerequisites

- Node.js 18+ and npm
- PostgreSQL database (or use Neon)

### Environment Variables

Create a `.env` file in the root directory with the following variables:

\`\`\`
# Database
DATABASE_URL="postgresql://username:password@localhost:5432/codesphere"

# NextAuth
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="your-secret-key"

# OAuth Providers
GOOGLE_CLIENT_ID="your-google-client-id"
GOOGLE_CLIENT_SECRET="your-google-client-secret"
GITHUB_CLIENT_ID="your-github-client-id"
GITHUB_CLIENT_SECRET="your-github-client-secret"
\`\`\`

### Installation

1. Clone the repository:
   \`\`\`bash
   git clone https://github.com/yourusername/codesphere.git
   cd codesphere
   \`\`\`

2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`

3. Set up the database:
   \`\`\`bash
   npx prisma migrate dev
   \`\`\`

4. Seed the database with initial data:
   \`\`\`bash
   npm run setup
   \`\`\`

5. Start the development server:
   \`\`\`bash
   npm run dev
   \`\`\`

6. Open [http://localhost:3000](http://localhost:3000) in your browser.

### Default Users

After running the setup script, you can log in with these credentials:

- **Admin User**:
  - Email: admin@codesphere.com
  - Password: admin123

- **Regular User**:
  - Email: user@codesphere.com
  - Password: user123

## Key Features

### Online Classes
- Live video conferencing with instructors
- Real-time chat during classes
- Screen sharing for demonstrations
- Class enrollment and management
- Scheduled sessions with reminders

### Personalized Settings
- Notification preferences (email and push)
- Theme customization (light/dark mode, accent colors)
- Account management
- Password security
- Accessibility options

### Note Creation (Admin Only)
- Create and manage learning materials
- Upload files in various formats
- Organize content by categories
- Provide detailed descriptions

## Deployment

The application can be easily deployed to Vercel:

1. Push your code to a GitHub repository
2. Import the repository in Vercel
3. Set up the environment variables
4. Deploy

## License

This project is licensed under the MIT License - see the LICENSE file for details.
