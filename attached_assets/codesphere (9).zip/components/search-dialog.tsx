"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, BookOpen, FileText, Video, Map, X } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"

type SearchResult = {
  id: string
  title: string
  description: string
  type: "note" | "pdf" | "video" | "roadmap"
  category: string
  url: string
}

export function SearchDialog() {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState("")
  const [activeTab, setActiveTab] = useState("all")
  const [results, setResults] = useState<SearchResult[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  // Mock search function - in a real app, this would call an API
  useEffect(() => {
    if (!query.trim() || query.length < 2) {
      setResults([])
      return
    }

    setIsLoading(true)

    // Simulate API call
    const timer = setTimeout(() => {
      // Mock data
      const allResults: SearchResult[] = [
        {
          id: "1",
          title: "JavaScript Fundamentals",
          description: "Learn the basics of JavaScript programming",
          type: "note",
          category: "JavaScript",
          url: "/notes/1",
        },
        {
          id: "2",
          title: "Advanced React Patterns",
          description: "Deep dive into advanced React patterns and techniques",
          type: "pdf",
          category: "React",
          url: "/pdfs/2",
        },
        {
          id: "3",
          title: "Building a REST API with Node.js",
          description: "Step-by-step guide to creating RESTful APIs",
          type: "video",
          category: "Node.js",
          url: "/videos/3",
        },
        {
          id: "4",
          title: "Full-Stack Developer Roadmap",
          description: "Complete guide to becoming a full-stack developer",
          type: "roadmap",
          category: "Career",
          url: "/roadmaps/4",
        },
      ]

      // Filter by search term
      const filtered = allResults.filter(
        (item) =>
          item.title.toLowerCase().includes(query.toLowerCase()) ||
          item.description.toLowerCase().includes(query.toLowerCase()) ||
          item.category.toLowerCase().includes(query.toLowerCase()),
      )

      // Filter by active tab
      const tabFiltered = activeTab === "all" ? filtered : filtered.filter((item) => item.type === activeTab)

      setResults(tabFiltered)
      setIsLoading(false)
    }, 500)

    return () => clearTimeout(timer)
  }, [query, activeTab])

  const handleSelect = (result: SearchResult) => {
    router.push(result.url)
    setOpen(false)
    setQuery("")
  }

  const getIcon = (type: string) => {
    switch (type) {
      case "note":
        return <BookOpen className="h-4 w-4" />
      case "pdf":
        return <FileText className="h-4 w-4" />
      case "video":
        return <Video className="h-4 w-4" />
      case "roadmap":
        return <Map className="h-4 w-4" />
      default:
        return <Search className="h-4 w-4" />
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="relative h-9 w-9 p-0 xl:h-10 xl:w-60 xl:justify-start xl:px-3 xl:py-2">
          <Search className="h-4 w-4 xl:mr-2" />
          <span className="hidden xl:inline-flex">Search...</span>
          <kbd className="pointer-events-none absolute right-1.5 top-1.5 hidden h-6 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium opacity-100 xl:flex">
            <span className="text-xs">⌘</span>K
          </kbd>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[550px]">
        <DialogHeader>
          <DialogTitle className="sr-only">Search</DialogTitle>
          <div className="flex items-center border-b pb-4">
            <Search className="mr-2 h-5 w-5 shrink-0 opacity-50" />
            <Input
              type="text"
              placeholder="Search for anything..."
              className="flex-1 border-0 bg-transparent p-0 text-sm focus-visible:outline-none focus-visible:ring-0"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              autoFocus
            />
            {query && (
              <Button variant="ghost" size="icon" className="h-5 w-5" onClick={() => setQuery("")}>
                <X className="h-4 w-4" />
                <span className="sr-only">Clear</span>
              </Button>
            )}
          </div>
        </DialogHeader>
        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="note">Notes</TabsTrigger>
            <TabsTrigger value="pdf">PDFs</TabsTrigger>
            <TabsTrigger value="video">Videos</TabsTrigger>
            <TabsTrigger value="roadmap">Roadmaps</TabsTrigger>
          </TabsList>
          <TabsContent value={activeTab} className="mt-0">
            {isLoading ? (
              <div className="flex h-40 items-center justify-center">
                <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
              </div>
            ) : results.length > 0 ? (
              <ScrollArea className="h-[300px]">
                <div className="space-y-2">
                  {results.map((result) => (
                    <button
                      key={result.id}
                      className="flex w-full items-start gap-2 rounded-lg border p-3 text-left hover:bg-accent"
                      onClick={() => handleSelect(result)}
                    >
                      <div className="rounded-md bg-primary/10 p-2 text-primary">{getIcon(result.type)}</div>
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">{result.title}</h4>
                          <Badge variant="outline">{result.category}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground line-clamp-1">{result.description}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </ScrollArea>
            ) : query.length > 1 ? (
              <div className="flex h-40 flex-col items-center justify-center gap-2">
                <Search className="h-8 w-8 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">No results found for "{query}"</p>
              </div>
            ) : (
              <div className="flex h-40 flex-col items-center justify-center gap-2">
                <Search className="h-8 w-8 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">Type at least 2 characters to search</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
