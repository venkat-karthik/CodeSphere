"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Star, Trophy, Award, Zap } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

type RankInfo = {
  name: string
  icon: React.ReactNode
  color: string
  minXP: number
  maxXP: number
  image: string
}

const animeRanks: RankInfo[] = [
  {
    name: "Rookie Ninja",
    icon: <Star className="h-4 w-4" />,
    color: "bg-blue-500 text-white",
    minXP: 0,
    maxXP: 1000,
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    name: "Genin",
    icon: <Star className="h-4 w-4" />,
    color: "bg-green-500 text-white",
    minXP: 1000,
    maxXP: 3000,
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    name: "Chunin",
    icon: <Star className="h-4 w-4" />,
    color: "bg-yellow-500 text-white",
    minXP: 3000,
    maxXP: 6000,
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    name: "Jonin",
    icon: <Trophy className="h-4 w-4" />,
    color: "bg-orange-500 text-white",
    minXP: 6000,
    maxXP: 10000,
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    name: "ANBU",
    icon: <Award className="h-4 w-4" />,
    color: "bg-purple-500 text-white",
    minXP: 10000,
    maxXP: 15000,
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    name: "Kage",
    icon: <Zap className="h-4 w-4" />,
    color: "bg-red-500 text-white",
    minXP: 15000,
    maxXP: 25000,
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    name: "Legendary Sannin",
    icon: <Zap className="h-4 w-4" />,
    color: "bg-indigo-500 text-white",
    minXP: 25000,
    maxXP: Number.POSITIVE_INFINITY,
    image: "/placeholder.svg?height=80&width=80",
  },
]

type AnimeRankProps = {
  xp: number
  showNextRank?: boolean
}

export function AnimeRank({ xp, showNextRank = true }: AnimeRankProps) {
  const [currentRank, setCurrentRank] = useState<RankInfo | null>(null)
  const [nextRank, setNextRank] = useState<RankInfo | null>(null)
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    // Find current rank
    const current = animeRanks.find((rank) => xp >= rank.minXP && xp < rank.maxXP)
    setCurrentRank(current || animeRanks[0])

    // Find next rank
    const currentIndex = animeRanks.findIndex((rank) => xp >= rank.minXP && xp < rank.maxXP)
    setNextRank(currentIndex < animeRanks.length - 1 ? animeRanks[currentIndex + 1] : null)

    // Calculate progress to next rank
    if (current && currentIndex < animeRanks.length - 1) {
      const progressValue = ((xp - current.minXP) / (current.maxXP - current.minXP)) * 100
      setProgress(progressValue)
    } else if (currentIndex === animeRanks.length - 1) {
      setProgress(100)
    }
  }, [xp])

  if (!currentRank) return null

  return (
    <Card>
      <CardHeader>
        <CardTitle>Your Ninja Rank</CardTitle>
        <CardDescription>Progress through the ninja ranks as you learn</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-4">
          <Avatar className="h-16 w-16 border-2 border-primary">
            <AvatarImage src={currentRank.image || "/placeholder.svg"} alt={currentRank.name} />
            <AvatarFallback>{currentRank.name[0]}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <Badge className={currentRank.color}>
                <span className="flex items-center gap-1">
                  {currentRank.icon}
                  {currentRank.name}
                </span>
              </Badge>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">{xp.toLocaleString()} XP</p>
            {nextRank && showNextRank && (
              <div className="mt-2">
                <div className="flex justify-between text-xs mb-1">
                  <span>{currentRank.name}</span>
                  <span>{nextRank.name}</span>
                </div>
                <Progress value={progress} className="h-2" />
                <p className="text-xs text-center mt-1 text-muted-foreground">
                  {nextRank.minXP - xp > 0
                    ? `${(nextRank.minXP - xp).toLocaleString()} XP to next rank`
                    : "Max rank achieved!"}
                </p>
              </div>
            )}
          </div>
        </div>

        {showNextRank && (
          <div className="space-y-2 mt-4">
            <h4 className="text-sm font-medium">Rank Progression</h4>
            <div className="grid grid-cols-7 gap-1">
              {animeRanks.map((rank, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  className={`h-1.5 rounded-full ${xp >= rank.minXP ? rank.color.split(" ")[0] : "bg-muted"}`}
                />
              ))}
            </div>
            <div className="grid grid-cols-7 gap-1 text-xs text-center">
              {animeRanks.map((rank, index) => (
                <div
                  key={index}
                  className={`truncate ${xp >= rank.minXP ? "text-foreground font-medium" : "text-muted-foreground"}`}
                >
                  {index === 0 ? "Start" : ""}
                  {index === animeRanks.length - 1 ? "Legend" : ""}
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
