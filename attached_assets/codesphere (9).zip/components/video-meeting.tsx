"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import { useSession } from "next-auth/react"
import {
  Mic,
  MicOff,
  VideoIcon,
  VideoOff,
  Monitor,
  MonitorOff,
  MessageSquare,
  Users,
  Send,
  X,
  MoreVertical,
  Phone,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface VideoMeetingProps {
  classId: string
  className: string
  instructor: {
    id: string
    name: string
    avatar: string
  }
  participants: Array<{
    id: string
    name: string
    avatar: string
    role: "instructor" | "student"
  }>
  onEndMeeting?: () => void
}

export function VideoMeeting({ classId, className, instructor, participants, onEndMeeting }: VideoMeetingProps) {
  const { data: session } = useSession()
  const router = useRouter()
  const { toast } = useToast()

  const [isAudioEnabled, setIsAudioEnabled] = useState(true)
  const [isVideoEnabled, setIsVideoEnabled] = useState(true)
  const [isScreenSharing, setIsScreenSharing] = useState(false)
  const [isChatOpen, setIsChatOpen] = useState(false)
  const [isParticipantsOpen, setIsParticipantsOpen] = useState(false)
  const [messages, setMessages] = useState<Array<{ id: string; sender: string; text: string; timestamp: Date }>>([])
  const [messageText, setMessageText] = useState("")

  const localVideoRef = useRef<HTMLVideoElement>(null)
  const chatScrollRef = useRef<HTMLDivElement>(null)

  // Mock video stream setup
  useEffect(() => {
    let stream: MediaStream | null = null

    const setupLocalVideo = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: isVideoEnabled,
          audio: isAudioEnabled,
        })

        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream
        }

        toast({
          title: "Connected to meeting",
          description: "Your audio and video are now live",
        })
      } catch (error) {
        console.error("Error accessing media devices:", error)
        toast({
          title: "Media access error",
          description: "Could not access camera or microphone",
          variant: "destructive",
        })
      }
    }

    setupLocalVideo()

    // Add some mock messages
    const mockMessages = [
      {
        id: "1",
        sender: "Sarah Johnson",
        text: "Welcome everyone to our JavaScript class!",
        timestamp: new Date(Date.now() - 300000),
      },
      {
        id: "2",
        sender: "John Smith",
        text: "Thanks for having us. Excited to learn!",
        timestamp: new Date(Date.now() - 240000),
      },
      {
        id: "3",
        sender: "Emily Brown",
        text: "Will this session be recorded?",
        timestamp: new Date(Date.now() - 180000),
      },
      {
        id: "4",
        sender: "Sarah Johnson",
        text: "Yes, I'll share the recording after class",
        timestamp: new Date(Date.now() - 120000),
      },
      {
        id: "5",
        sender: "Michael Lee",
        text: "Great! Looking forward to the exercises",
        timestamp: new Date(Date.now() - 60000),
      },
    ]

    setMessages(mockMessages)

    return () => {
      // Clean up
      if (stream) {
        stream.getTracks().forEach((track) => track.stop())
      }
    }
  }, [toast])

  // Scroll to bottom of chat when new messages arrive
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight
    }
  }, [messages, isChatOpen])

  const toggleAudio = () => {
    setIsAudioEnabled(!isAudioEnabled)

    // In a real implementation, we would toggle the audio track
    toast({
      title: isAudioEnabled ? "Microphone muted" : "Microphone unmuted",
      description: isAudioEnabled ? "Others can't hear you now" : "Others can hear you now",
    })
  }

  const toggleVideo = () => {
    setIsVideoEnabled(!isVideoEnabled)

    // In a real implementation, we would toggle the video track
    toast({
      title: isVideoEnabled ? "Camera turned off" : "Camera turned on",
      description: isVideoEnabled ? "Others can't see you now" : "Others can see you now",
    })
  }

  const toggleScreenShare = () => {
    setIsScreenSharing(!isScreenSharing)

    // In a real implementation, we would handle screen sharing
    toast({
      title: isScreenSharing ? "Screen sharing stopped" : "Screen sharing started",
      description: isScreenSharing ? "Others can no longer see your screen" : "Others can now see your screen",
    })
  }

  const sendMessage = () => {
    if (!messageText.trim()) return

    const newMessage = {
      id: Date.now().toString(),
      sender: session?.user?.name || "You",
      text: messageText,
      timestamp: new Date(),
    }

    setMessages([...messages, newMessage])
    setMessageText("")
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  const endMeeting = () => {
    toast({
      title: "Meeting ended",
      description: "You have left the meeting",
    })

    if (onEndMeeting) {
      onEndMeeting()
    } else {
      router.push(`/classes/${classId}`)
    }
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Main content area */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Video area */}
        <div className={`flex-1 p-4 ${isChatOpen || isParticipantsOpen ? "md:w-2/3" : "w-full"}`}>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 h-full">
            {/* Main instructor video */}
            <div className="col-span-1 md:col-span-2 lg:col-span-2 bg-black rounded-lg overflow-hidden relative">
              <video
                className="w-full h-full object-cover"
                src="/placeholder.svg"
                poster={instructor.avatar || "/placeholder.svg?height=400&width=600"}
                autoPlay
                muted
              />
              <div className="absolute bottom-4 left-4 bg-black/50 px-3 py-1 rounded-md text-white flex items-center gap-2">
                <div className={`h-2 w-2 rounded-full ${isAudioEnabled ? "bg-green-500" : "bg-red-500"}`}></div>
                {instructor.name} (Instructor)
              </div>
            </div>

            {/* Your video */}
            <div className="bg-black rounded-lg overflow-hidden relative">
              <video ref={localVideoRef} className="w-full h-full object-cover" autoPlay muted playsInline />
              {!isVideoEnabled && (
                <div className="absolute inset-0 flex items-center justify-center bg-muted">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src={session?.user?.image || "/placeholder.svg"} />
                    <AvatarFallback>{session?.user?.name?.charAt(0) || "U"}</AvatarFallback>
                  </Avatar>
                </div>
              )}
              <div className="absolute bottom-4 left-4 bg-black/50 px-3 py-1 rounded-md text-white flex items-center gap-2">
                <div className={`h-2 w-2 rounded-full ${isAudioEnabled ? "bg-green-500" : "bg-red-500"}`}></div>
                You
              </div>
            </div>

            {/* Other participants would be rendered here in a real implementation */}
          </div>
        </div>

        {/* Sidebar (chat or participants) */}
        {(isChatOpen || isParticipantsOpen) && (
          <div className="w-full md:w-1/3 border-l border-border h-full flex flex-col">
            <div className="p-4 border-b border-border flex justify-between items-center">
              <Tabs defaultValue={isChatOpen ? "chat" : "participants"} className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger
                    value="chat"
                    onClick={() => {
                      setIsChatOpen(true)
                      setIsParticipantsOpen(false)
                    }}
                  >
                    Chat
                  </TabsTrigger>
                  <TabsTrigger
                    value="participants"
                    onClick={() => {
                      setIsParticipantsOpen(true)
                      setIsChatOpen(false)
                    }}
                  >
                    Participants
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="chat" className="mt-0">
                  <div className="flex flex-col h-[calc(100vh-12rem)]">
                    <ScrollArea className="flex-1 p-4" ref={chatScrollRef}>
                      <div className="space-y-4">
                        {messages.map((message) => (
                          <div key={message.id} className="flex flex-col">
                            <div className="flex items-start gap-2">
                              <Avatar className="h-8 w-8">
                                <AvatarFallback>{message.sender.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <div className="flex flex-col">
                                <div className="flex items-center gap-2">
                                  <span className="font-medium text-sm">{message.sender}</span>
                                  <span className="text-xs text-muted-foreground">{formatTime(message.timestamp)}</span>
                                </div>
                                <p className="text-sm">{message.text}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>

                    <div className="p-4 border-t border-border">
                      <div className="flex gap-2">
                        <Input
                          placeholder="Type a message..."
                          value={messageText}
                          onChange={(e) => setMessageText(e.target.value)}
                          onKeyDown={handleKeyDown}
                        />
                        <Button size="icon" onClick={sendMessage}>
                          <Send className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="participants" className="mt-0">
                  <ScrollArea className="h-[calc(100vh-12rem)] p-4">
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-medium mb-2">Instructor</h3>
                        <div className="flex items-center gap-3 p-2 rounded-md hover:bg-muted">
                          <Avatar>
                            <AvatarImage src={instructor.avatar || "/placeholder.svg"} />
                            <AvatarFallback>{instructor.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <p className="font-medium">{instructor.name}</p>
                            <p className="text-xs text-muted-foreground">Instructor</p>
                          </div>
                          <div className="flex items-center gap-1">
                            <div className="h-2 w-2 rounded-full bg-green-500"></div>
                          </div>
                        </div>
                      </div>

                      <Separator />

                      <div>
                        <h3 className="font-medium mb-2">Students ({participants.length})</h3>
                        <div className="space-y-1">
                          {participants.map((participant) => (
                            <div key={participant.id} className="flex items-center gap-3 p-2 rounded-md hover:bg-muted">
                              <Avatar>
                                <AvatarImage src={participant.avatar || "/placeholder.svg"} />
                                <AvatarFallback>{participant.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <div className="flex-1">
                                <p className="font-medium">{participant.name}</p>
                                <p className="text-xs text-muted-foreground">Student</p>
                              </div>
                              <div className="flex items-center gap-1">
                                <div className="h-2 w-2 rounded-full bg-green-500"></div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </ScrollArea>
                </TabsContent>
              </Tabs>

              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  setIsChatOpen(false)
                  setIsParticipantsOpen(false)
                }}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="h-16 border-t border-border flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <Button variant={isAudioEnabled ? "default" : "destructive"} size="icon" onClick={toggleAudio}>
            {isAudioEnabled ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
          </Button>

          <Button variant={isVideoEnabled ? "default" : "destructive"} size="icon" onClick={toggleVideo}>
            {isVideoEnabled ? <VideoIcon className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
          </Button>

          <Button variant={isScreenSharing ? "destructive" : "default"} size="icon" onClick={toggleScreenShare}>
            {isScreenSharing ? <MonitorOff className="h-5 w-5" /> : <Monitor className="h-5 w-5" />}
          </Button>
        </div>

        <div className="flex items-center">
          <h2 className="font-medium">{className}</h2>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => {
              setIsChatOpen(!isChatOpen)
              if (isChatOpen) {
                setIsParticipantsOpen(false)
              }
            }}
            className={isChatOpen ? "bg-secondary" : ""}
          >
            <MessageSquare className="h-5 w-5" />
          </Button>

          <Button
            variant="outline"
            size="icon"
            onClick={() => {
              setIsParticipantsOpen(!isParticipantsOpen)
              if (isParticipantsOpen) {
                setIsChatOpen(false)
              }
            }}
            className={isParticipantsOpen ? "bg-secondary" : ""}
          >
            <Users className="h-5 w-5" />
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <MoreVertical className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Start Recording</DropdownMenuItem>
              <DropdownMenuItem>Share Meeting Link</DropdownMenuItem>
              <DropdownMenuItem>Meeting Settings</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button variant="destructive" size="icon" onClick={endMeeting}>
            <Phone className="h-5 w-5 rotate-135" />
          </Button>
        </div>
      </div>
    </div>
  )
}
