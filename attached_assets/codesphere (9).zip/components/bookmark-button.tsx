"use client"

import { useState, useEffect } from "react"
import { Bookmark, BookmarkCheck } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"

interface BookmarkButtonProps {
  itemId: string
  itemType: "video" | "note" | "pdf" | "challenge"
  className?: string
}

export function BookmarkButton({ itemId, itemType, className }: BookmarkButtonProps) {
  const [isBookmarked, setIsBookmarked] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    // Check if item is bookmarked from localStorage
    const bookmarks = JSON.parse(localStorage.getItem("bookmarks") || "[]")
    const isItemBookmarked = bookmarks.some((bookmark: any) => bookmark.id === itemId && bookmark.type === itemType)
    setIsBookmarked(isItemBookmarked)
  }, [itemId, itemType])

  const toggleBookmark = () => {
    const bookmarks = JSON.parse(localStorage.getItem("bookmarks") || "[]")

    if (isBookmarked) {
      // Remove bookmark
      const updatedBookmarks = bookmarks.filter(
        (bookmark: any) => !(bookmark.id === itemId && bookmark.type === itemType),
      )
      localStorage.setItem("bookmarks", JSON.stringify(updatedBookmarks))
      setIsBookmarked(false)
      toast({
        title: "Bookmark removed",
        description: `${itemType} removed from bookmarks`,
      })
    } else {
      // Add bookmark
      const newBookmark = {
        id: itemId,
        type: itemType,
        timestamp: new Date().toISOString(),
      }
      const updatedBookmarks = [...bookmarks, newBookmark]
      localStorage.setItem("bookmarks", JSON.stringify(updatedBookmarks))
      setIsBookmarked(true)
      toast({
        title: "Bookmark added",
        description: `${itemType} added to bookmarks`,
      })
    }
  }

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={toggleBookmark}
      className={className}
      aria-label={isBookmarked ? "Remove bookmark" : "Add bookmark"}
    >
      {isBookmarked ? <BookmarkCheck className="h-4 w-4 text-yellow-500" /> : <Bookmark className="h-4 w-4" />}
    </Button>
  )
}
