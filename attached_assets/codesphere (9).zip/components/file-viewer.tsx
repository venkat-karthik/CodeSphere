"use client"

import type React from "react"

import { useState } from "react"
import { Download, Eye, FileText, ExternalLink, Copy, Printer, Share2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { useToast } from "@/hooks/use-toast"

type FileViewerProps = {
  fileUrl: string
  fileName: string
  fileType: "pdf" | "note" | "video"
  fileSize?: string
  children?: React.ReactNode
  trigger?: React.ReactNode
}

export function FileViewer({ fileUrl, fileName, fileType, fileSize, children, trigger }: FileViewerProps) {
  const [isOpen, setIsOpen] = useState(false)
  const { toast } = useToast()

  const handleDownload = () => {
    // In a real app, this would trigger a download
    toast({
      title: "Download started",
      description: `${fileName} is being downloaded`,
    })
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(fileUrl)
    toast({
      title: "Link copied",
      description: "File link has been copied to clipboard",
    })
  }

  const handlePrint = () => {
    toast({
      title: "Print dialog opened",
      description: "Prepare to print the document",
    })
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: fileName,
        url: fileUrl,
      })
    } else {
      handleCopy()
    }
  }

  const getFileIcon = () => {
    switch (fileType) {
      case "pdf":
        return <FileText className="h-6 w-6 text-red-500" />
      case "note":
        return <FileText className="h-6 w-6 text-blue-500" />
      case "video":
        return <FileText className="h-6 w-6 text-purple-500" />
      default:
        return <FileText className="h-6 w-6" />
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" size="sm" className="flex items-center gap-1">
            <Eye className="h-4 w-4" />
            <span>View</span>
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] flex flex-col">
        <DialogHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center gap-2">
            {getFileIcon()}
            <DialogTitle className="text-lg">{fileName}</DialogTitle>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={handleCopy}>
              <Copy className="h-4 w-4" />
              <span className="sr-only">Copy link</span>
            </Button>
            <Button variant="outline" size="icon" onClick={handlePrint}>
              <Printer className="h-4 w-4" />
              <span className="sr-only">Print</span>
            </Button>
            <Button variant="outline" size="icon" onClick={handleShare}>
              <Share2 className="h-4 w-4" />
              <span className="sr-only">Share</span>
            </Button>
            <Button variant="outline" size="icon" onClick={handleDownload}>
              <Download className="h-4 w-4" />
              <span className="sr-only">Download</span>
            </Button>
            <Button variant="outline" size="icon" asChild>
              <a href={fileUrl} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="h-4 w-4" />
                <span className="sr-only">Open in new tab</span>
              </a>
            </Button>
          </div>
        </DialogHeader>
        <div className="flex-1 overflow-auto mt-4 rounded-md border">
          {fileType === "pdf" && (
            <div className="w-full h-full min-h-[500px] bg-muted flex items-center justify-center">
              <iframe src={fileUrl} className="w-full h-full" title={fileName} />
            </div>
          )}
          {fileType === "note" && (
            <div className="w-full h-full min-h-[500px] p-4 overflow-auto">
              {children || (
                <div className="flex items-center justify-center h-full text-muted-foreground">
                  Note content would be displayed here
                </div>
              )}
            </div>
          )}
          {fileType === "video" && (
            <div className="w-full h-full min-h-[500px]">
              <video src={fileUrl} controls className="w-full h-full" poster="/placeholder.svg?height=500&width=800">
                Your browser does not support the video tag.
              </video>
            </div>
          )}
        </div>
        <div className="flex justify-between items-center mt-4">
          <div className="text-sm text-muted-foreground">{fileSize || "Unknown size"}</div>
          <Button onClick={handleDownload} className="flex items-center gap-1">
            <Download className="h-4 w-4" />
            <span>Download</span>
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
