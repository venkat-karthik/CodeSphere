// Mock data service for CodeSphere
export interface User {
  id: string
  email: string
  name: string
  role: "user" | "admin"
  avatar?: string
  createdAt: Date
}

export interface Video {
  id: string
  title: string
  description: string
  url: string
  thumbnail: string
  duration: number
  category: string
  difficulty: "beginner" | "intermediate" | "advanced"
  views: number
  createdAt: Date
}

export interface Note {
  id: string
  title: string
  content: string
  category: string
  tags: string[]
  createdAt: Date
  updatedAt: Date
}

export interface Bookmark {
  id: string
  userId: string
  contentId: string
  contentType: "video" | "note" | "pdf"
  createdAt: Date
}

// Mock data
export const mockVideos: Video[] = [
  {
    id: "1",
    title: "Introduction to React",
    description: "Learn the basics of React development",
    url: "https://www.youtube.com/embed/dGcsHMXbSOA",
    thumbnail: "/placeholder.svg?height=200&width=300",
    duration: 1800,
    category: "React",
    difficulty: "beginner",
    views: 1250,
    createdAt: new Date("2024-01-15"),
  },
  {
    id: "2",
    title: "Advanced TypeScript",
    description: "Master advanced TypeScript concepts",
    url: "https://www.youtube.com/embed/BwuLxPH8IDs",
    thumbnail: "/placeholder.svg?height=200&width=300",
    duration: 2400,
    category: "TypeScript",
    difficulty: "advanced",
    views: 890,
    createdAt: new Date("2024-01-20"),
  },
  {
    id: "3",
    title: "Node.js Fundamentals",
    description: "Build backend applications with Node.js",
    url: "https://www.youtube.com/embed/TlB_eWDSMt4",
    thumbnail: "/placeholder.svg?height=200&width=300",
    duration: 2100,
    category: "Node.js",
    difficulty: "intermediate",
    views: 1100,
    createdAt: new Date("2024-01-25"),
  },
]

export const mockNotes: Note[] = [
  {
    id: "1",
    title: "JavaScript ES6 Features",
    content: "Comprehensive guide to ES6 features including arrow functions, destructuring, and more.",
    category: "JavaScript",
    tags: ["ES6", "JavaScript", "Modern JS"],
    createdAt: new Date("2024-01-10"),
    updatedAt: new Date("2024-01-15"),
  },
  {
    id: "2",
    title: "React Hooks Guide",
    content: "Complete guide to React Hooks including useState, useEffect, and custom hooks.",
    category: "React",
    tags: ["React", "Hooks", "Frontend"],
    createdAt: new Date("2024-01-12"),
    updatedAt: new Date("2024-01-18"),
  },
]

// Mock functions
export function getVideos(): Video[] {
  return mockVideos
}

export function getVideoById(id: string): Video | undefined {
  return mockVideos.find((video) => video.id === id)
}

export function getNotes(): Note[] {
  return mockNotes
}

export function getNoteById(id: string): Note | undefined {
  return mockNotes.find((note) => note.id === id)
}

export function getBookmarks(userId: string): Bookmark[] {
  // Mock bookmarks
  return [
    {
      id: "1",
      userId,
      contentId: "1",
      contentType: "video",
      createdAt: new Date(),
    },
  ]
}

export function isAdmin(email: string): boolean {
  // Mock admin check
  return email === "admin@codesphere.com"
}
